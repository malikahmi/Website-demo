export enum WebsiteDataStatus {
  noData = "No data",
  notLoaded = "Not loaded",
  inProgress = "In progress",
  loaded = "Loaded",
  error = "Error",
}
