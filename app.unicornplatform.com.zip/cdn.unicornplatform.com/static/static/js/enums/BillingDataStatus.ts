export enum BillingDataStatus {
  notLoaded = "Not loaded",
  inProgress = "In progress",
  loaded = "Loaded",
  error = "Error",
}
