export enum Oauth2Apps {
  Zapier = "zapier",
}
