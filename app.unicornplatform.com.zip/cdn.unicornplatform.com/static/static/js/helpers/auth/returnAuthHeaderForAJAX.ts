function returnAuthHeaderForAJAX(accessToken:string|undefined): object {
    // accessToken can be undefined because we retrieve it from a Cookie which can be expired or not set yet.
    return {headers: {"Authorization": "Token " + accessToken}};
}

export default returnAuthHeaderForAJAX;