export const getAllQueryParams = (): string => {
  const queryString = window.location.href.split("?")[1];
  if (!queryString) return "";
  return `?${queryString}`;
};
