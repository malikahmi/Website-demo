function generateRandomNumerousId(){
    return (Math.floor(1 + Math.random() * 90000))
}

export default generateRandomNumerousId;