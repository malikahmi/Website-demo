// Check if the given item is a set of key-value pairs, e.g. { key1: 1, key2: 2 }
export const isKeyValue = (item: unknown) => {
  return typeof item === "object" && !Array.isArray(item) && item !== null;
};
