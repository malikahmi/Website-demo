export const linkOrButtonOptions = {
    // <a> can be link only
    //<button> can also be 'submit' (for forms)

    'link': 'link',
    'submit': 'submit',
};