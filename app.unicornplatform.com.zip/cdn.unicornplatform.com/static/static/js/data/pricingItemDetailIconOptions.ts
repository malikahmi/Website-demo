export const pricingItemDetailIconOptions = {
    'greenTick': 'greenTick',
    'redCross': 'redCross',
    'none': 'none',
};