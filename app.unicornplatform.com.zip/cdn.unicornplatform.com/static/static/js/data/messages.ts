export const messages = {
    errors: {
        other: {
            serverUnavailable: 'Your browser failed to interact with our server. Please check your Internet connection, refresh your browser and try again. If the problem still appears, our service may be temporarily down and we are working on getting it well.'
        }
    }
};