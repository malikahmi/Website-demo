export const callToActionOptions = {
    'buttons': 'buttons',
    'form': 'form',
    'none': 'none',
};