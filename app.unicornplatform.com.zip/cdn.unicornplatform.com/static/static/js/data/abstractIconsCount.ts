export const abstractIconsCount = 12;
// We only need to know their total amount to iterate. We don't care about titles: these icons are designer universal.