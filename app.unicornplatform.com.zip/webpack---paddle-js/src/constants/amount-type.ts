export enum AMOUNT_TYPE {
  GROSS = 'gross',
  TAX = 'tax',
  NET = 'net',
  TAX_INCLUDED = 'tax_included',
}
