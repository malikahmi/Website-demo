export enum LOG_LEVEL {
  WARNING = 'warning',
  LOG = 'log',
  ERROR = 'error',
}
