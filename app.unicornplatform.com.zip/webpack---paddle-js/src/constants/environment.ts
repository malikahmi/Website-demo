export enum ENVIRONMENTS {
  PRODUCTION = 'production',
  STAGING = 'staging',
  SANDBOX = 'sandbox',
  DEVELOPMENT = 'dev',
  LOCAL = 'local',
}
