export enum ANALYTICS_EVENT {
  CHECKOUT_OPEN = 'Checkout.Open',
  AUDIENCE_SUBSCRIBE = 'Audience.Subscribe',
  CONVERSION = 'Conversion',
  DOWNLOAD = 'Download',
  VISIT = 'Visit',
}
