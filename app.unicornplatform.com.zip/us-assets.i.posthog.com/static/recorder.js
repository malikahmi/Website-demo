! function(e) {
    "use strict";

    function t(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
            var n = Object.getOwnPropertySymbols(e);
            t && (n = n.filter((function(t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable
            }))), r.push.apply(r, n)
        }
        return r
    }

    function r(e) {
        for (var r = 1; r < arguments.length; r++) {
            var n = null != arguments[r] ? arguments[r] : {};
            r % 2 ? t(Object(n), !0).forEach((function(t) {
                a(e, t, n[t])
            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : t(Object(n)).forEach((function(t) {
                Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
            }))
        }
        return e
    }

    function n(e, t, r, n, o, a, i) {
        try {
            var s = e[a](i),
                l = s.value
        } catch (e) {
            return void r(e)
        }
        s.done ? t(l) : Promise.resolve(l).then(n, o)
    }

    function o(e) {
        return function() {
            var t = this,
                r = arguments;
            return new Promise((function(o, a) {
                var i = e.apply(t, r);

                function s(e) {
                    n(i, o, a, s, l, "next", e)
                }

                function l(e) {
                    n(i, o, a, s, l, "throw", e)
                }
                s(void 0)
            }))
        }
    }

    function a(e, t, r) {
        return t in e ? Object.defineProperty(e, t, {
            value: r,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = r, e
    }

    function i(e, t) {
        if (null == e) return {};
        var r, n, o = function(e, t) {
            if (null == e) return {};
            var r, n, o = {},
                a = Object.keys(e);
            for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) >= 0 || (o[r] = e[r]);
            return o
        }(e, t);
        if (Object.getOwnPropertySymbols) {
            var a = Object.getOwnPropertySymbols(e);
            for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) >= 0 || Object.prototype.propertyIsEnumerable.call(e, r) && (o[r] = e[r])
        }
        return o
    }
    var s, l = ["type"],
        c = Object.defineProperty,
        d = (e, t, r) => ((e, t, r) => t in e ? c(e, t, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: r
        }) : e[t] = r)(e, "symbol" != typeof t ? t + "" : t, r),
        u = Object.defineProperty,
        h = (e, t, r) => ((e, t, r) => t in e ? u(e, t, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: r
        }) : e[t] = r)(e, "symbol" != typeof t ? t + "" : t, r),
        p = (e => (e[e.Document = 0] = "Document", e[e.DocumentType = 1] = "DocumentType", e[e.Element = 2] = "Element", e[e.Text = 3] = "Text", e[e.CDATA = 4] = "CDATA", e[e.Comment = 5] = "Comment", e))(p || {}),
        m = {
            Node: ["childNodes", "parentNode", "parentElement", "textContent"],
            ShadowRoot: ["host", "styleSheets"],
            Element: ["shadowRoot", "querySelector", "querySelectorAll"],
            MutationObserver: []
        },
        f = {
            Node: ["contains", "getRootNode"],
            ShadowRoot: ["getSelection"],
            Element: [],
            MutationObserver: ["constructor"]
        },
        g = {},
        v = () => !!globalThis.Zone;

    function y(e) {
        if (g[e]) return g[e];
        var t = globalThis[e],
            r = t.prototype,
            n = e in m ? m[e] : void 0,
            o = Boolean(n && n.every((e => {
                var t, n;
                return Boolean(null == (n = null == (t = Object.getOwnPropertyDescriptor(r, e)) ? void 0 : t.get) ? void 0 : n.toString().includes("[native code]"))
            }))),
            a = e in f ? f[e] : void 0,
            i = Boolean(a && a.every((e => {
                var t;
                return "function" == typeof r[e] && (null == (t = r[e]) ? void 0 : t.toString().includes("[native code]"))
            })));
        if (o && i && !v()) return g[e] = t.prototype, t.prototype;
        try {
            var s = document.createElement("iframe");
            document.body.appendChild(s);
            var l = s.contentWindow;
            if (!l) return t.prototype;
            var c = l[e].prototype;
            return document.body.removeChild(s), c ? g[e] = c : t.prototype
        } catch (e) {
            return t.prototype
        }
    }
    var I = {};

    function b(e, t, r) {
        var n, o = "".concat(e, ".").concat(String(r));
        if (I[o]) return I[o].call(t);
        var a = y(e),
            i = null == (n = Object.getOwnPropertyDescriptor(a, r)) ? void 0 : n.get;
        return i ? (I[o] = i, i.call(t)) : t[r]
    }
    var C = {};

    function S(e, t, r) {
        var n = "".concat(e, ".").concat(String(r));
        if (C[n]) return C[n].bind(t);
        var o = y(e)[r];
        return "function" != typeof o ? t[r] : (C[n] = o, o.bind(t))
    }
    var w = {
        childNodes: function(e) {
            return b("Node", e, "childNodes")
        },
        parentNode: function(e) {
            return b("Node", e, "parentNode")
        },
        parentElement: function(e) {
            return b("Node", e, "parentElement")
        },
        textContent: function(e) {
            return b("Node", e, "textContent")
        },
        contains: function(e, t) {
            return S("Node", e, "contains")(t)
        },
        getRootNode: function(e) {
            return S("Node", e, "getRootNode")()
        },
        host: function(e) {
            return e && "host" in e ? b("ShadowRoot", e, "host") : null
        },
        styleSheets: function(e) {
            return e.styleSheets
        },
        shadowRoot: function(e) {
            return e && "shadowRoot" in e ? b("Element", e, "shadowRoot") : null
        },
        querySelector: function(e, t) {
            return b("Element", e, "querySelector")(t)
        },
        querySelectorAll: function(e, t) {
            return b("Element", e, "querySelectorAll")(t)
        },
        mutationObserver: function() {
            return y("MutationObserver").constructor
        }
    };

    function N(e) {
        return e.nodeType === e.ELEMENT_NODE
    }

    function M(e) {
        var t = e && "host" in e && "mode" in e && w.host(e) || null;
        return Boolean(t && "shadowRoot" in t && w.shadowRoot(t) === e)
    }

    function A(e) {
        return "[object ShadowRoot]" === Object.prototype.toString.call(e)
    }

    function k(e) {
        try {
            var t = e.rules || e.cssRules;
            if (!t) return null;
            var r = e.href;
            !r && e.ownerNode && e.ownerNode.ownerDocument && (r = e.ownerNode.ownerDocument.location.href);
            var n = Array.from(t, (e => T(e, r))).join("");
            return (o = n).includes(" background-clip: text;") && !o.includes(" -webkit-background-clip: text;") && (o = o.replace(/\sbackground-clip:\s*text;/g, " -webkit-background-clip: text; background-clip: text;")), o
        } catch (e) {
            return null
        }
        var o
    }

    function T(e, t) {
        if (function(e) {
                return "styleSheet" in e
            }(e)) {
            var r;
            try {
                r = k(e.styleSheet) || function(e) {
                    var {
                        cssText: t
                    } = e;
                    if (t.split('"').length < 3) return t;
                    var r = ["@import", "url(".concat(JSON.stringify(e.href), ")")];
                    return "" === e.layerName ? r.push("layer") : e.layerName && r.push("layer(".concat(e.layerName, ")")), e.supportsText && r.push("supports(".concat(e.supportsText, ")")), e.media.length && r.push(e.media.mediaText), r.join(" ") + ";"
                }(e)
            } catch (t) {
                r = e.cssText
            }
            return e.styleSheet.href ? W(r, e.styleSheet.href) : r
        }
        var n, o = e.cssText;
        return function(e) {
            return "selectorText" in e
        }(e) && e.selectorText.includes(":") && (n = /(\[(?:[\w-]+)[^\\])(:(?:[\w-]+)\])/gm, o = o.replace(n, "$1\\$2")), t ? W(o, t) : o
    }

    function R(e, t) {
        return Array.from(e.styleSheets).find((e => e.href === t))
    }
    let E = class {
        constructor() {
            h(this, "idNodeMap", new Map), h(this, "nodeMetaMap", new WeakMap)
        }
        getId(e) {
            var t;
            if (!e) return -1;
            var r = null == (t = this.getMeta(e)) ? void 0 : t.id;
            return null != r ? r : -1
        }
        getNode(e) {
            return this.idNodeMap.get(e) || null
        }
        getIds() {
            return Array.from(this.idNodeMap.keys())
        }
        getMeta(e) {
            return this.nodeMetaMap.get(e) || null
        }
        removeNodeFromMap(e) {
            var t = this.getId(e);
            this.idNodeMap.delete(t), e.childNodes && e.childNodes.forEach((e => this.removeNodeFromMap(e)))
        }
        has(e) {
            return this.idNodeMap.has(e)
        }
        hasNode(e) {
            return this.nodeMetaMap.has(e)
        }
        add(e, t) {
            var r = t.id;
            this.idNodeMap.set(r, e), this.nodeMetaMap.set(e, t)
        }
        replace(e, t) {
            var r = this.getNode(e);
            if (r) {
                var n = this.nodeMetaMap.get(r);
                n && this.nodeMetaMap.set(t, n)
            }
            this.idNodeMap.set(e, t)
        }
        reset() {
            this.idNodeMap = new Map, this.nodeMetaMap = new WeakMap
        }
    };

    function O(e) {
        var {
            element: t,
            maskInputOptions: r,
            tagName: n,
            type: o,
            value: a,
            maskInputFn: i
        } = e, s = a || "", l = o && x(o);
        return (r[n.toLowerCase()] || l && r[l]) && (s = i ? i(s, t) : "*".repeat(s.length)), s
    }

    function x(e) {
        return e.toLowerCase()
    }
    var D = "__rrweb_original__";

    function L(e) {
        var t = e.type;
        return e.hasAttribute("data-rr-is-password") ? "password" : t ? x(t) : null
    }

    function F(e, t) {
        var r, n;
        try {
            n = new URL(e, null != t ? t : window.location.href)
        } catch (e) {
            return null
        }
        var o = n.pathname.match(/\.([0-9a-z]+)(?:$)/i);
        return null !== (r = null == o ? void 0 : o[1]) && void 0 !== r ? r : null
    }
    var B = /url\((?:(')([^']*)'|(")(.*?)"|([^)]*))\)/gm,
        Z = /^(?:[a-z+]+:)?\/\//i,
        _ = /^www\..*/i,
        Y = /^(data:)([^,]*),(.*)/i;

    function W(e, t) {
        return (e || "").replace(B, ((e, r, n, o, a, i) => {
            var s, l = n || a || i,
                c = r || o || "";
            if (!l) return e;
            if (Z.test(l) || _.test(l)) return "url(".concat(c).concat(l).concat(c, ")");
            if (Y.test(l)) return "url(".concat(c).concat(l).concat(c, ")");
            if ("/" === l[0]) return "url(".concat(c).concat((s = t, (s.indexOf("//") > -1 ? s.split("/").slice(0, 3).join("/") : s.split("/")[0]).split("?")[0] + l)).concat(c, ")");
            var d = t.split("/"),
                u = l.split("/");
            for (var h of (d.pop(), u)) "." !== h && (".." === h ? d.pop() : d.push(h));
            return "url(".concat(c).concat(d.join("/")).concat(c, ")")
        }))
    }
    var G = new Map,
        V = new Map;

    function H(e) {
        if (!G.has(e)) {
            var t = e.replace(/(\/\*[^*]*\*\/)|[\s;]/g, "");
            G.set(e, t)
        }
        return G.get(e)
    }

    function P(e, t) {
        return function(e, t) {
            var r = Array.from(t.childNodes),
                n = [],
                o = 0;
            if (r.length > 1 && e && "string" == typeof e) {
                if (V.has(e)) return V.get(e);
                for (var a = H(e), i = a.length / e.length, s = 1; s < r.length; s++)
                    if (r[s].textContent && "string" == typeof r[s].textContent) {
                        for (var l = H(r[s].textContent), c = 3; c < l.length && (l[c].match(/[a-zA-Z0-9]/) || -1 !== l.indexOf(l.substring(0, c), 1)); c++);
                        for (; c < l.length; c++) {
                            var d = l.substring(0, c),
                                u = a.split(d),
                                h = -1;
                            if (2 === u.length ? h = a.indexOf(d) : u.length > 2 && "" === u[0] && "" !== r[s - 1].textContent && (h = a.indexOf(d, 1)), -1 !== h) {
                                for (var p = Math.floor(h / i); p > 0 && p < e.length;) {
                                    if ((o += 1) > 50 * r.length) return n.push(e), n;
                                    var m = H(e.substring(0, p));
                                    if (m.length === h) {
                                        n.push(e.substring(0, p)), e = e.substring(p), a = a.substring(h);
                                        break
                                    }
                                    m.length < h ? p += Math.max(1, Math.floor((h - m.length) / i)) : p -= Math.max(1, Math.floor((m.length - h) * i))
                                }
                                break
                            }
                        }
                    }
            }
            return n.push(e), V.set(e, n), n
        }(e, t).join("/* rr_split */")
    }
    var X, j, z = 1,
        K = new RegExp("[^a-z0-9-_:]"),
        J = -2;

    function U() {
        return z++
    }
    var q = /^[^ \t\n\r\u000c]+/,
        Q = /^[, \t\n\r\u000c]+/;
    var $ = new WeakMap;

    function ee(e, t) {
        return t && "" !== t.trim() ? re(e, t) : t
    }

    function te(e) {
        return Boolean("svg" === e.tagName || e.ownerSVGElement)
    }

    function re(e, t) {
        var r = $.get(e);
        if (r || (r = e.createElement("a"), $.set(e, r)), t) {
            if (t.startsWith("blob:") || t.startsWith("data:")) return t
        } else t = "";
        return r.setAttribute("href", t), r.href
    }

    function ne(e, t, r, n) {
        return n ? "src" === r || "href" === r && ("use" !== t || "#" !== n[0]) || "xlink:href" === r && "#" !== n[0] ? ee(e, n) : "background" !== r || "table" !== t && "td" !== t && "th" !== t ? "srcset" === r ? function(e, t) {
            if ("" === t.trim()) return t;
            var r = 0;

            function n(e) {
                var n, o = e.exec(t.substring(r));
                return o ? (n = o[0], r += n.length, n) : ""
            }
            for (var o = []; n(Q), !(r >= t.length);) {
                var a = n(q);
                if ("," === a.slice(-1)) a = ee(e, a.substring(0, a.length - 1)), o.push(a);
                else {
                    var i = "";
                    a = ee(e, a);
                    for (var s = !1;;) {
                        var l = t.charAt(r);
                        if ("" === l) {
                            o.push((a + i).trim());
                            break
                        }
                        if (s) ")" === l && (s = !1);
                        else {
                            if ("," === l) {
                                r += 1, o.push((a + i).trim());
                                break
                            }
                            "(" === l && (s = !0)
                        }
                        i += l, r += 1
                    }
                }
            }
            return o.join(", ")
        }(e, n) : "style" === r ? W(n, re(e)) : "object" === t && "data" === r ? ee(e, n) : n : ee(e, n) : n
    }

    function oe(e, t, r) {
        return ("video" === e || "audio" === e) && "autoplay" === t
    }

    function ae(e, t, r) {
        if (!e) return !1;
        if (e.nodeType !== e.ELEMENT_NODE) return !!r && ae(w.parentNode(e), t, r);
        for (var n = e.classList.length; n--;) {
            var o = e.classList[n];
            if (t.test(o)) return !0
        }
        return !!r && ae(w.parentNode(e), t, r)
    }

    function ie(e, t, r, n) {
        var o;
        if (N(e)) {
            if (o = e, !w.childNodes(o).length) return !1
        } else {
            if (null === w.parentElement(e)) return !1;
            o = w.parentElement(e)
        }
        try {
            if ("string" == typeof t) {
                if (n) {
                    if (o.closest(".".concat(t))) return !0
                } else if (o.classList.contains(t)) return !0
            } else if (ae(o, t, n)) return !0;
            if (r)
                if (n) {
                    if (o.closest(r)) return !0
                } else if (o.matches(r)) return !0
        } catch (e) {}
        return !1
    }

    function se(e, t) {
        var {
            doc: r,
            mirror: n,
            blockClass: o,
            blockSelector: a,
            needsMask: i,
            inlineStylesheet: s,
            maskInputOptions: l = {},
            maskTextFn: c,
            maskInputFn: d,
            dataURLOptions: u = {},
            inlineImages: h,
            recordCanvas: m,
            keepIframeSrcFn: f,
            newlyAddedElement: g = !1,
            cssCaptured: v = !1
        } = t, y = function(e, t) {
            if (!t.hasNode(e)) return;
            var r = t.getId(e);
            return 1 === r ? void 0 : r
        }(r, n);
        switch (e.nodeType) {
            case e.DOCUMENT_NODE:
                return "CSS1Compat" !== e.compatMode ? {
                    type: p.Document,
                    childNodes: [],
                    compatMode: e.compatMode
                } : {
                    type: p.Document,
                    childNodes: []
                };
            case e.DOCUMENT_TYPE_NODE:
                return {
                    type: p.DocumentType,
                    name: e.name,
                    publicId: e.publicId,
                    systemId: e.systemId,
                    rootId: y
                };
            case e.ELEMENT_NODE:
                return function(e, t) {
                    for (var r, {
                            doc: n,
                            blockClass: o,
                            blockSelector: a,
                            inlineStylesheet: i,
                            maskInputOptions: s = {},
                            maskInputFn: l,
                            dataURLOptions: c = {},
                            inlineImages: d,
                            recordCanvas: u,
                            keepIframeSrcFn: h,
                            newlyAddedElement: m = !1,
                            rootId: f
                        } = t, g = function(e, t, r) {
                            try {
                                if ("string" == typeof t) {
                                    if (e.classList.contains(t)) return !0
                                } else
                                    for (var n = e.classList.length; n--;) {
                                        var o = e.classList[n];
                                        if (t.test(o)) return !0
                                    }
                                if (r) return e.matches(r)
                            } catch (e) {}
                            return !1
                        }(e, o, a), v = function(e) {
                            if (e instanceof HTMLFormElement) return "form";
                            var t = x(e.tagName);
                            return K.test(t) ? "div" : t
                        }(e), y = {}, I = e.attributes.length, b = 0; b < I; b++) {
                        var C = e.attributes[b];
                        oe(v, C.name, C.value) || (y[C.name] = ne(n, v, x(C.name), C.value))
                    }
                    if ("link" === v && i) {
                        var S = e.href;
                        if (S) {
                            var w = R(n, S);
                            if (!w && S.includes(".css")) w = R(n, window.location.origin + "/" + S.replace(window.location.href, ""));
                            var N = null;
                            w && (N = k(w)), N && (delete y.rel, delete y.href, y._cssText = N)
                        }
                    }
                    if ("style" === v && e.sheet) {
                        var M = k(e.sheet);
                        M && (e.childNodes.length > 1 && (M = P(M, e)), y._cssText = M)
                    }
                    if ("input" === v || "textarea" === v || "select" === v) {
                        var A = e.value,
                            T = e.checked;
                        "radio" !== y.type && "checkbox" !== y.type && "submit" !== y.type && "button" !== y.type && A ? y.value = O({
                            element: e,
                            type: L(e),
                            tagName: v,
                            value: A,
                            maskInputOptions: s,
                            maskInputFn: l
                        }) : T && (y.checked = T)
                    }
                    "option" === v && (e.selected && !s.select ? y.selected = !0 : delete y.selected);
                    if ("dialog" === v && e.open) try {
                        y.rr_open_mode = e.matches("dialog:modal") ? "modal" : "non-modal"
                    } catch (e) {
                        y.rr_open_mode = "modal", y.ph_rr_could_not_detect_modal = !0
                    }
                    if ("canvas" === v && u)
                        if ("2d" === e.__context)(function(e) {
                            var t = e.getContext("2d");
                            if (!t) return !0;
                            for (var r = 0; r < e.width; r += 50)
                                for (var n = 0; n < e.height; n += 50) {
                                    var o = t.getImageData,
                                        a = D in o ? o[D] : o;
                                    if (new Uint32Array(a.call(t, r, n, Math.min(50, e.width - r), Math.min(50, e.height - n)).data.buffer).some((e => 0 !== e))) return !1
                                }
                            return !0
                        })(e) || (y.rr_dataURL = e.toDataURL(c.type, c.quality));
                        else if (!("__context" in e)) {
                        var E = e.toDataURL(c.type, c.quality),
                            F = n.createElement("canvas");
                        F.width = e.width, F.height = e.height, E !== F.toDataURL(c.type, c.quality) && (y.rr_dataURL = E)
                    }
                    if ("img" === v && d) {
                        X || (X = n.createElement("canvas"), j = X.getContext("2d"));
                        var B = e,
                            Z = B.currentSrc || B.getAttribute("src") || "<unknown-src>",
                            _ = B.crossOrigin,
                            Y = () => {
                                B.removeEventListener("load", Y);
                                try {
                                    X.width = B.naturalWidth, X.height = B.naturalHeight, j.drawImage(B, 0, 0), y.rr_dataURL = X.toDataURL(c.type, c.quality)
                                } catch (e) {
                                    if ("anonymous" !== B.crossOrigin) return B.crossOrigin = "anonymous", void(B.complete && 0 !== B.naturalWidth ? Y() : B.addEventListener("load", Y));
                                    console.warn("Cannot inline img src=".concat(Z, "! Error: ").concat(e))
                                }
                                "anonymous" === B.crossOrigin && (_ ? y.crossOrigin = _ : B.removeAttribute("crossorigin"))
                            };
                        B.complete && 0 !== B.naturalWidth ? Y() : B.addEventListener("load", Y)
                    }
                    if ("audio" === v || "video" === v) {
                        var W = y;
                        W.rr_mediaState = e.paused ? "paused" : "played", W.rr_mediaCurrentTime = e.currentTime, W.rr_mediaPlaybackRate = e.playbackRate, W.rr_mediaMuted = e.muted, W.rr_mediaLoop = e.loop, W.rr_mediaVolume = e.volume
                    }
                    m || (e.scrollLeft && (y.rr_scrollLeft = e.scrollLeft), e.scrollTop && (y.rr_scrollTop = e.scrollTop));
                    if (g) {
                        var {
                            width: G,
                            height: V
                        } = e.getBoundingClientRect();
                        y = {
                            class: y.class,
                            rr_width: "".concat(G, "px"),
                            rr_height: "".concat(V, "px")
                        }
                    }
                    "iframe" !== v || h(y.src) || (e.contentDocument || (y.rr_src = y.src), delete y.src);
                    try {
                        customElements.get(v) && (r = !0)
                    } catch (e) {}
                    return {
                        type: p.Element,
                        tagName: v,
                        attributes: y,
                        childNodes: [],
                        isSVG: te(e) || void 0,
                        needBlock: g,
                        rootId: f,
                        isCustom: r
                    }
                }(e, {
                    doc: r,
                    blockClass: o,
                    blockSelector: a,
                    inlineStylesheet: s,
                    maskInputOptions: l,
                    maskInputFn: d,
                    dataURLOptions: u,
                    inlineImages: h,
                    recordCanvas: m,
                    keepIframeSrcFn: f,
                    newlyAddedElement: g,
                    rootId: y
                });
            case e.TEXT_NODE:
                return function(e, t) {
                    var {
                        needsMask: r,
                        maskTextFn: n,
                        rootId: o,
                        cssCaptured: a
                    } = t, i = w.parentNode(e), s = i && i.tagName, l = "", c = "STYLE" === s || void 0, d = "SCRIPT" === s || void 0;
                    d ? l = "SCRIPT_PLACEHOLDER" : a || (l = w.textContent(e), c && l && (l = W(l, re(t.doc))));
                    !c && !d && l && r && (l = n ? n(l, w.parentElement(e)) : l.replace(/[\S]/g, "*"));
                    return {
                        type: p.Text,
                        textContent: l || "",
                        rootId: o
                    }
                }(e, {
                    doc: r,
                    needsMask: i,
                    maskTextFn: c,
                    rootId: y,
                    cssCaptured: v
                });
            case e.CDATA_SECTION_NODE:
                return {
                    type: p.CDATA,
                    textContent: "",
                    rootId: y
                };
            case e.COMMENT_NODE:
                return {
                    type: p.Comment,
                    textContent: w.textContent(e) || "",
                    rootId: y
                };
            default:
                return !1
        }
    }

    function le(e) {
        return null == e ? "" : e.toLowerCase()
    }

    function ce(e, t) {
        var {
            doc: r,
            mirror: n,
            blockClass: o,
            blockSelector: a,
            maskTextClass: i,
            maskTextSelector: s,
            skipChild: l = !1,
            inlineStylesheet: c = !0,
            maskInputOptions: d = {},
            maskTextFn: u,
            maskInputFn: h,
            slimDOMOptions: m,
            dataURLOptions: f = {},
            inlineImages: g = !1,
            recordCanvas: v = !1,
            onSerialize: y,
            onIframeLoad: I,
            iframeLoadTimeout: b = 5e3,
            onStylesheetLoad: C,
            stylesheetLoadTimeout: S = 5e3,
            keepIframeSrcFn: k = (() => !1),
            newlyAddedElement: T = !1,
            cssCaptured: R = !1
        } = t, {
            needsMask: E
        } = t, {
            preserveWhiteSpace: O = !0
        } = t;
        E || (E = ie(e, i, s, void 0 === E));
        var x, D = se(e, {
            doc: r,
            mirror: n,
            blockClass: o,
            blockSelector: a,
            needsMask: E,
            inlineStylesheet: c,
            maskInputOptions: d,
            maskTextFn: u,
            maskInputFn: h,
            dataURLOptions: f,
            inlineImages: g,
            recordCanvas: v,
            keepIframeSrcFn: k,
            newlyAddedElement: T,
            cssCaptured: R
        });
        if (!D) return console.warn(e, "not serialized"), null;
        x = n.hasNode(e) ? n.getId(e) : function(e, t) {
            if (t.comment && e.type === p.Comment) return !0;
            if (e.type === p.Element) {
                if (t.script && ("script" === e.tagName || "link" === e.tagName && ("preload" === e.attributes.rel || "modulepreload" === e.attributes.rel) && "script" === e.attributes.as || "link" === e.tagName && "prefetch" === e.attributes.rel && "string" == typeof e.attributes.href && "js" === F(e.attributes.href))) return !0;
                if (t.headFavicon && ("link" === e.tagName && "shortcut icon" === e.attributes.rel || "meta" === e.tagName && (le(e.attributes.name).match(/^msapplication-tile(image|color)$/) || "application-name" === le(e.attributes.name) || "icon" === le(e.attributes.rel) || "apple-touch-icon" === le(e.attributes.rel) || "shortcut icon" === le(e.attributes.rel)))) return !0;
                if ("meta" === e.tagName) {
                    if (t.headMetaDescKeywords && le(e.attributes.name).match(/^description|keywords$/)) return !0;
                    if (t.headMetaSocial && (le(e.attributes.property).match(/^(og|twitter|fb):/) || le(e.attributes.name).match(/^(og|twitter):/) || "pinterest" === le(e.attributes.name))) return !0;
                    if (t.headMetaRobots && ("robots" === le(e.attributes.name) || "googlebot" === le(e.attributes.name) || "bingbot" === le(e.attributes.name))) return !0;
                    if (t.headMetaHttpEquiv && void 0 !== e.attributes["http-equiv"]) return !0;
                    if (t.headMetaAuthorship && ("author" === le(e.attributes.name) || "generator" === le(e.attributes.name) || "framework" === le(e.attributes.name) || "publisher" === le(e.attributes.name) || "progid" === le(e.attributes.name) || le(e.attributes.property).match(/^article:/) || le(e.attributes.property).match(/^product:/))) return !0;
                    if (t.headMetaVerification && ("google-site-verification" === le(e.attributes.name) || "yandex-verification" === le(e.attributes.name) || "csrf-token" === le(e.attributes.name) || "p:domain_verify" === le(e.attributes.name) || "verify-v1" === le(e.attributes.name) || "verification" === le(e.attributes.name) || "shopify-checkout-api-token" === le(e.attributes.name))) return !0
                }
            }
            return !1
        }(D, m) || !O && D.type === p.Text && !D.textContent.replace(/^\s+|\s+$/gm, "").length ? J : U();
        var L = Object.assign(D, {
            id: x
        });
        if (n.add(e, L), x === J) return null;
        y && y(e);
        var B = !l;
        if (L.type === p.Element) {
            B = B && !L.needBlock, delete L.needBlock;
            var Z = w.shadowRoot(e);
            Z && A(Z) && (L.isShadowHost = !0)
        }
        if ((L.type === p.Document || L.type === p.Element) && B) {
            m.headWhitespace && L.type === p.Element && "head" === L.tagName && (O = !1);
            var _ = {
                doc: r,
                mirror: n,
                blockClass: o,
                blockSelector: a,
                needsMask: E,
                maskTextClass: i,
                maskTextSelector: s,
                skipChild: l,
                inlineStylesheet: c,
                maskInputOptions: d,
                maskTextFn: u,
                maskInputFn: h,
                slimDOMOptions: m,
                dataURLOptions: f,
                inlineImages: g,
                recordCanvas: v,
                preserveWhiteSpace: O,
                onSerialize: y,
                onIframeLoad: I,
                iframeLoadTimeout: b,
                onStylesheetLoad: C,
                stylesheetLoadTimeout: S,
                keepIframeSrcFn: k,
                cssCaptured: !1
            };
            if (L.type === p.Element && "textarea" === L.tagName && void 0 !== L.attributes.value);
            else
                for (var Y of (L.type === p.Element && void 0 !== L.attributes._cssText && "string" == typeof L.attributes._cssText && (_.cssCaptured = !0), Array.from(w.childNodes(e)))) {
                    var W = ce(Y, _);
                    W && L.childNodes.push(W)
                }
            var G = null;
            if (N(e) && (G = w.shadowRoot(e)))
                for (var V of Array.from(w.childNodes(G))) {
                    var H = ce(V, _);
                    H && (A(G) && (H.isShadow = !0), L.childNodes.push(H))
                }
        }
        var P = w.parentNode(e);
        return P && M(P) && A(P) && (L.isShadow = !0), L.type === p.Element && "iframe" === L.tagName && function(e, t, r) {
            var n = e.contentWindow;
            if (n) {
                var o, a = !1;
                try {
                    o = n.document.readyState
                } catch (e) {
                    return
                }
                if ("complete" === o) {
                    var i = "about:blank";
                    if (n.location.href !== i || e.src === i || "" === e.src) return setTimeout(t, 0), e.addEventListener("load", t);
                    e.addEventListener("load", t)
                } else {
                    var s = setTimeout((() => {
                        a || (t(), a = !0)
                    }), r);
                    e.addEventListener("load", (() => {
                        clearTimeout(s), a = !0, t()
                    }))
                }
            }
        }(e, (() => {
            var t = e.contentDocument;
            if (t && I) {
                var r = ce(t, {
                    doc: t,
                    mirror: n,
                    blockClass: o,
                    blockSelector: a,
                    needsMask: E,
                    maskTextClass: i,
                    maskTextSelector: s,
                    skipChild: !1,
                    inlineStylesheet: c,
                    maskInputOptions: d,
                    maskTextFn: u,
                    maskInputFn: h,
                    slimDOMOptions: m,
                    dataURLOptions: f,
                    inlineImages: g,
                    recordCanvas: v,
                    preserveWhiteSpace: O,
                    onSerialize: y,
                    onIframeLoad: I,
                    iframeLoadTimeout: b,
                    onStylesheetLoad: C,
                    stylesheetLoadTimeout: S,
                    keepIframeSrcFn: k
                });
                r && I(e, r)
            }
        }), b), L.type === p.Element && "link" === L.tagName && "string" == typeof L.attributes.rel && ("stylesheet" === L.attributes.rel || "preload" === L.attributes.rel && "string" == typeof L.attributes.href && "css" === F(L.attributes.href)) && function(e, t, r) {
            var n, o = !1;
            try {
                n = e.sheet
            } catch (e) {
                return
            }
            if (!n) {
                var a = setTimeout((() => {
                    o || (t(), o = !0)
                }), r);
                e.addEventListener("load", (() => {
                    clearTimeout(a), o = !0, t()
                }))
            }
        }(e, (() => {
            if (C) {
                var t = ce(e, {
                    doc: r,
                    mirror: n,
                    blockClass: o,
                    blockSelector: a,
                    needsMask: E,
                    maskTextClass: i,
                    maskTextSelector: s,
                    skipChild: !1,
                    inlineStylesheet: c,
                    maskInputOptions: d,
                    maskTextFn: u,
                    maskInputFn: h,
                    slimDOMOptions: m,
                    dataURLOptions: f,
                    inlineImages: g,
                    recordCanvas: v,
                    preserveWhiteSpace: O,
                    onSerialize: y,
                    onIframeLoad: I,
                    iframeLoadTimeout: b,
                    onStylesheetLoad: C,
                    stylesheetLoadTimeout: S,
                    keepIframeSrcFn: k
                });
                t && C(e, t)
            }
        }), S), L
    }
    let de = class e {
        constructor() {
            __publicField2(this, "parentElement", null), __publicField2(this, "parentNode", null), __publicField2(this, "ownerDocument"), __publicField2(this, "firstChild", null), __publicField2(this, "lastChild", null), __publicField2(this, "previousSibling", null), __publicField2(this, "nextSibling", null), __publicField2(this, "ELEMENT_NODE", 1), __publicField2(this, "TEXT_NODE", 3), __publicField2(this, "nodeType"), __publicField2(this, "nodeName"), __publicField2(this, "RRNodeType")
        }
        get childNodes() {
            for (var e = [], t = this.firstChild; t;) e.push(t), t = t.nextSibling;
            return e
        }
        contains(t) {
            if (!(t instanceof e)) return !1;
            if (t.ownerDocument !== this.ownerDocument) return !1;
            if (t === this) return !0;
            for (; t.parentNode;) {
                if (t.parentNode === this) return !0;
                t = t.parentNode
            }
            return !1
        }
        appendChild(e) {
            throw new Error("RRDomException: Failed to execute 'appendChild' on 'RRNode': This RRNode type does not support this method.")
        }
        insertBefore(e, t) {
            throw new Error("RRDomException: Failed to execute 'insertBefore' on 'RRNode': This RRNode type does not support this method.")
        }
        removeChild(e) {
            throw new Error("RRDomException: Failed to execute 'removeChild' on 'RRNode': This RRNode type does not support this method.")
        }
        toString() {
            return "RRNode"
        }
    };
    var ue = {
            Node: ["childNodes", "parentNode", "parentElement", "textContent"],
            ShadowRoot: ["host", "styleSheets"],
            Element: ["shadowRoot", "querySelector", "querySelectorAll"],
            MutationObserver: []
        },
        he = {
            Node: ["contains", "getRootNode"],
            ShadowRoot: ["getSelection"],
            Element: [],
            MutationObserver: ["constructor"]
        },
        pe = {},
        me = () => !!globalThis.Zone;

    function fe(e) {
        if (pe[e]) return pe[e];
        var t = globalThis[e],
            r = t.prototype,
            n = e in ue ? ue[e] : void 0,
            o = Boolean(n && n.every((e => {
                var t, n;
                return Boolean(null == (n = null == (t = Object.getOwnPropertyDescriptor(r, e)) ? void 0 : t.get) ? void 0 : n.toString().includes("[native code]"))
            }))),
            a = e in he ? he[e] : void 0,
            i = Boolean(a && a.every((e => {
                var t;
                return "function" == typeof r[e] && (null == (t = r[e]) ? void 0 : t.toString().includes("[native code]"))
            })));
        if (o && i && !me()) return pe[e] = t.prototype, t.prototype;
        try {
            var s = document.createElement("iframe");
            document.body.appendChild(s);
            var l = s.contentWindow;
            if (!l) return t.prototype;
            var c = l[e].prototype;
            return document.body.removeChild(s), c ? pe[e] = c : r
        } catch (e) {
            return r
        }
    }
    var ge = {};

    function ve(e, t, r) {
        var n, o = "".concat(e, ".").concat(String(r));
        if (ge[o]) return ge[o].call(t);
        var a = fe(e),
            i = null == (n = Object.getOwnPropertyDescriptor(a, r)) ? void 0 : n.get;
        return i ? (ge[o] = i, i.call(t)) : t[r]
    }
    var ye = {};

    function Ie(e, t, r) {
        var n = "".concat(e, ".").concat(String(r));
        if (ye[n]) return ye[n].bind(t);
        var o = fe(e)[r];
        return "function" != typeof o ? t[r] : (ye[n] = o, o.bind(t))
    }

    function be() {
        return fe("MutationObserver").constructor
    }
    var Ce = {
        childNodes: function(e) {
            return ve("Node", e, "childNodes")
        },
        parentNode: function(e) {
            return ve("Node", e, "parentNode")
        },
        parentElement: function(e) {
            return ve("Node", e, "parentElement")
        },
        textContent: function(e) {
            return ve("Node", e, "textContent")
        },
        contains: function(e, t) {
            return Ie("Node", e, "contains")(t)
        },
        getRootNode: function(e) {
            return Ie("Node", e, "getRootNode")()
        },
        host: function(e) {
            return e && "host" in e ? ve("ShadowRoot", e, "host") : null
        },
        styleSheets: function(e) {
            return e.styleSheets
        },
        shadowRoot: function(e) {
            return e && "shadowRoot" in e ? ve("Element", e, "shadowRoot") : null
        },
        querySelector: function(e, t) {
            return ve("Element", e, "querySelector")(t)
        },
        querySelectorAll: function(e, t) {
            return ve("Element", e, "querySelectorAll")(t)
        },
        mutationObserver: be
    };

    function Se(e, t) {
        var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : document,
            n = {
                capture: !0,
                passive: !0
            };
        return r.addEventListener(e, t, n), () => r.removeEventListener(e, t, n)
    }
    var we = "Please stop import mirror directly. Instead of that,\r\nnow you can use replayer.getMirror() to access the mirror instance of a replayer,\r\nor you can use record.mirror to access the mirror instance during recording.",
        Ne = {
            map: {},
            getId: () => (console.error(we), -1),
            getNode: () => (console.error(we), null),
            removeNodeFromMap() {
                console.error(we)
            },
            has: () => (console.error(we), !1),
            reset() {
                console.error(we)
            }
        };

    function Me(e, t) {
        var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
            n = null,
            o = 0;
        return function() {
            for (var a = arguments.length, i = new Array(a), s = 0; s < a; s++) i[s] = arguments[s];
            var l = Date.now();
            o || !1 !== r.leading || (o = l);
            var c = t - (l - o),
                d = this;
            c <= 0 || c > t ? (n && (clearTimeout(n), n = null), o = l, e.apply(d, i)) : n || !1 === r.trailing || (n = setTimeout((() => {
                o = !1 === r.leading ? 0 : Date.now(), n = null, e.apply(d, i)
            }), c))
        }
    }

    function Ae(e, t, r, n) {
        var o = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : window,
            a = o.Object.getOwnPropertyDescriptor(e, t);
        return o.Object.defineProperty(e, t, n ? r : {
            set(e) {
                setTimeout((() => {
                    r.set.call(this, e)
                }), 0), a && a.set && a.set.call(this, e)
            }
        }), () => Ae(e, t, a || {}, !0)
    }

    function ke(e, t, r) {
        try {
            if (!(t in e)) return () => {};
            var n = e[t],
                o = r(n);
            return "function" == typeof o && (o.prototype = o.prototype || {}, Object.defineProperties(o, {
                __rrweb_original__: {
                    enumerable: !1,
                    value: n
                }
            })), e[t] = o, () => {
                e[t] = n
            }
        } catch (e) {
            return () => {}
        }
    }
    "undefined" != typeof window && window.Proxy && window.Reflect && (Ne = new Proxy(Ne, {
        get: (e, t, r) => ("map" === t && console.error(we), Reflect.get(e, t, r))
    }));
    var Te = Date.now;

    function Re(e) {
        var t, r, n, o, a = e.document;
        return {
            left: a.scrollingElement ? a.scrollingElement.scrollLeft : void 0 !== e.pageXOffset ? e.pageXOffset : a.documentElement.scrollLeft || (null == a ? void 0 : a.body) && (null == (t = Ce.parentElement(a.body)) ? void 0 : t.scrollLeft) || (null == (r = null == a ? void 0 : a.body) ? void 0 : r.scrollLeft) || 0,
            top: a.scrollingElement ? a.scrollingElement.scrollTop : void 0 !== e.pageYOffset ? e.pageYOffset : (null == a ? void 0 : a.documentElement.scrollTop) || (null == a ? void 0 : a.body) && (null == (n = Ce.parentElement(a.body)) ? void 0 : n.scrollTop) || (null == (o = null == a ? void 0 : a.body) ? void 0 : o.scrollTop) || 0
        }
    }

    function Ee() {
        return window.innerHeight || document.documentElement && document.documentElement.clientHeight || document.body && document.body.clientHeight
    }

    function Oe() {
        return window.innerWidth || document.documentElement && document.documentElement.clientWidth || document.body && document.body.clientWidth
    }

    function xe(e) {
        return e ? e.nodeType === e.ELEMENT_NODE ? e : Ce.parentElement(e) : null
    }

    function De(e, t, r, n) {
        if (!e) return !1;
        var o = xe(e);
        if (!o) return !1;
        try {
            if ("string" == typeof t) {
                if (o.classList.contains(t)) return !0;
                if (n && null !== o.closest("." + t)) return !0
            } else if (ae(o, t, n)) return !0
        } catch (e) {}
        if (r) {
            if (o.matches(r)) return !0;
            if (n && null !== o.closest(r)) return !0
        }
        return !1
    }

    function Le(e, t, r) {
        return !("TITLE" !== e.tagName || !r.headTitleMutations) || t.getId(e) === J
    }

    function Fe(e, t) {
        if (M(e)) return !1;
        var r = t.getId(e);
        if (!t.has(r)) return !0;
        var n = Ce.parentNode(e);
        return (!n || n.nodeType !== e.DOCUMENT_NODE) && (!n || Fe(n, t))
    }

    function Be(e) {
        return Boolean(e.changedTouches)
    }

    function Ze(e, t) {
        return Boolean("IFRAME" === e.nodeName && t.getMeta(e))
    }

    function _e(e, t) {
        return Boolean("LINK" === e.nodeName && e.nodeType === e.ELEMENT_NODE && e.getAttribute && "stylesheet" === e.getAttribute("rel") && t.getMeta(e))
    }

    function Ye(e) {
        return !!e && (e instanceof de && "shadowRoot" in e ? Boolean(e.shadowRoot) : Boolean(Ce.shadowRoot(e)))
    }
    /[1-9][0-9]{12}/.test(Date.now().toString()) || (Te = () => (new Date).getTime());
    let We = class {
        constructor() {
            d(this, "id", 1), d(this, "styleIDMap", new WeakMap), d(this, "idStyleMap", new Map)
        }
        getId(e) {
            var t;
            return null !== (t = this.styleIDMap.get(e)) && void 0 !== t ? t : -1
        }
        has(e) {
            return this.styleIDMap.has(e)
        }
        add(e, t) {
            return this.has(e) ? this.getId(e) : (r = void 0 === t ? this.id++ : t, this.styleIDMap.set(e, r), this.idStyleMap.set(r, e), r);
            var r
        }
        getStyle(e) {
            return this.idStyleMap.get(e) || null
        }
        reset() {
            this.styleIDMap = new WeakMap, this.idStyleMap = new Map, this.id = 1
        }
        generateId() {
            return this.id++
        }
    };

    function Ge(e) {
        var t, r = null;
        return "getRootNode" in e && (null == (t = Ce.getRootNode(e)) ? void 0 : t.nodeType) === Node.DOCUMENT_FRAGMENT_NODE && Ce.host(Ce.getRootNode(e)) && (r = Ce.host(Ce.getRootNode(e))), r
    }

    function Ve(e) {
        var t = e.ownerDocument;
        if (!t) return !1;
        var r = function(e) {
            for (var t, r = e; t = Ge(r);) r = t;
            return r
        }(e);
        return Ce.contains(t, r)
    }

    function He(e) {
        var t = e.ownerDocument;
        return !!t && (Ce.contains(t, e) || Ve(e))
    }
    var Pe = (e => (e[e.DomContentLoaded = 0] = "DomContentLoaded", e[e.Load = 1] = "Load", e[e.FullSnapshot = 2] = "FullSnapshot", e[e.IncrementalSnapshot = 3] = "IncrementalSnapshot", e[e.Meta = 4] = "Meta", e[e.Custom = 5] = "Custom", e[e.Plugin = 6] = "Plugin", e))(Pe || {}),
        Xe = (e => (e[e.Mutation = 0] = "Mutation", e[e.MouseMove = 1] = "MouseMove", e[e.MouseInteraction = 2] = "MouseInteraction", e[e.Scroll = 3] = "Scroll", e[e.ViewportResize = 4] = "ViewportResize", e[e.Input = 5] = "Input", e[e.TouchMove = 6] = "TouchMove", e[e.MediaInteraction = 7] = "MediaInteraction", e[e.StyleSheetRule = 8] = "StyleSheetRule", e[e.CanvasMutation = 9] = "CanvasMutation", e[e.Font = 10] = "Font", e[e.Log = 11] = "Log", e[e.Drag = 12] = "Drag", e[e.StyleDeclaration = 13] = "StyleDeclaration", e[e.Selection = 14] = "Selection", e[e.AdoptedStyleSheet = 15] = "AdoptedStyleSheet", e[e.CustomElement = 16] = "CustomElement", e))(Xe || {}),
        je = (e => (e[e.MouseUp = 0] = "MouseUp", e[e.MouseDown = 1] = "MouseDown", e[e.Click = 2] = "Click", e[e.ContextMenu = 3] = "ContextMenu", e[e.DblClick = 4] = "DblClick", e[e.Focus = 5] = "Focus", e[e.Blur = 6] = "Blur", e[e.TouchStart = 7] = "TouchStart", e[e.TouchMove_Departed = 8] = "TouchMove_Departed", e[e.TouchEnd = 9] = "TouchEnd", e[e.TouchCancel = 10] = "TouchCancel", e))(je || {}),
        ze = (e => (e[e.Mouse = 0] = "Mouse", e[e.Pen = 1] = "Pen", e[e.Touch = 2] = "Touch", e))(ze || {}),
        Ke = (e => (e[e["2D"] = 0] = "2D", e[e.WebGL = 1] = "WebGL", e[e.WebGL2 = 2] = "WebGL2", e))(Ke || {}),
        Je = (e => (e[e.Play = 0] = "Play", e[e.Pause = 1] = "Pause", e[e.Seeked = 2] = "Seeked", e[e.VolumeChange = 3] = "VolumeChange", e[e.RateChange = 4] = "RateChange", e))(Je || {}),
        Ue = (e => (e[e.Document = 0] = "Document", e[e.DocumentType = 1] = "DocumentType", e[e.Element = 2] = "Element", e[e.Text = 3] = "Text", e[e.CDATA = 4] = "CDATA", e[e.Comment = 5] = "Comment", e))(Ue || {});

    function qe(e) {
        return "__ln" in e
    }
    class Qe {
        constructor() {
            d(this, "length", 0), d(this, "head", null), d(this, "tail", null)
        }
        get(e) {
            if (e >= this.length) throw new Error("Position outside of list range");
            for (var t = this.head, r = 0; r < e; r++) t = (null == t ? void 0 : t.next) || null;
            return t
        }
        addNode(e) {
            var t = {
                value: e,
                previous: null,
                next: null
            };
            if (e.__ln = t, e.previousSibling && qe(e.previousSibling)) {
                var r = e.previousSibling.__ln.next;
                t.next = r, t.previous = e.previousSibling.__ln, e.previousSibling.__ln.next = t, r && (r.previous = t)
            } else if (e.nextSibling && qe(e.nextSibling) && e.nextSibling.__ln.previous) {
                var n = e.nextSibling.__ln.previous;
                t.previous = n, t.next = e.nextSibling.__ln, e.nextSibling.__ln.previous = t, n && (n.next = t)
            } else this.head && (this.head.previous = t), t.next = this.head, this.head = t;
            null === t.next && (this.tail = t), this.length++
        }
        removeNode(e) {
            var t = e.__ln;
            this.head && (t.previous ? (t.previous.next = t.next, t.next ? t.next.previous = t.previous : this.tail = t.previous) : (this.head = t.next, this.head ? this.head.previous = null : this.tail = null), e.__ln && delete e.__ln, this.length--)
        }
    }
    var $e, et = (e, t) => "".concat(e, "@").concat(t);
    class tt {
        constructor() {
            d(this, "frozen", !1), d(this, "locked", !1), d(this, "texts", []), d(this, "attributes", []), d(this, "attributeMap", new WeakMap), d(this, "removes", []), d(this, "mapRemoves", []), d(this, "movedMap", {}), d(this, "addedSet", new Set), d(this, "movedSet", new Set), d(this, "droppedSet", new Set), d(this, "removesSubTreeCache", new Set), d(this, "mutationCb"), d(this, "blockClass"), d(this, "blockSelector"), d(this, "maskTextClass"), d(this, "maskTextSelector"), d(this, "inlineStylesheet"), d(this, "maskInputOptions"), d(this, "maskTextFn"), d(this, "maskInputFn"), d(this, "keepIframeSrcFn"), d(this, "recordCanvas"), d(this, "inlineImages"), d(this, "slimDOMOptions"), d(this, "dataURLOptions"), d(this, "doc"), d(this, "mirror"), d(this, "iframeManager"), d(this, "stylesheetManager"), d(this, "shadowDomManager"), d(this, "canvasManager"), d(this, "processedNodeManager"), d(this, "unattachedDoc"), d(this, "processMutations", (e => {
                e.forEach(this.processMutation), this.emit()
            })), d(this, "emit", (() => {
                if (!this.frozen && !this.locked) {
                    for (var e = [], t = new Set, r = new Qe, n = e => {
                            for (var t = e, r = J; r === J;) r = (t = t && t.nextSibling) && this.mirror.getId(t);
                            return r
                        }, o = o => {
                            var a = Ce.parentNode(o);
                            if (a && He(o)) {
                                var i = !1;
                                if (o.nodeType === Node.TEXT_NODE) {
                                    var s = a.tagName;
                                    if ("TEXTAREA" === s) return;
                                    "STYLE" === s && this.addedSet.has(a) && (i = !0)
                                }
                                var l = M(a) ? this.mirror.getId(Ge(o)) : this.mirror.getId(a),
                                    c = n(o);
                                if (-1 === l || -1 === c) return r.addNode(o);
                                var d = ce(o, {
                                    doc: this.doc,
                                    mirror: this.mirror,
                                    blockClass: this.blockClass,
                                    blockSelector: this.blockSelector,
                                    maskTextClass: this.maskTextClass,
                                    maskTextSelector: this.maskTextSelector,
                                    skipChild: !0,
                                    newlyAddedElement: !0,
                                    inlineStylesheet: this.inlineStylesheet,
                                    maskInputOptions: this.maskInputOptions,
                                    maskTextFn: this.maskTextFn,
                                    maskInputFn: this.maskInputFn,
                                    slimDOMOptions: this.slimDOMOptions,
                                    dataURLOptions: this.dataURLOptions,
                                    recordCanvas: this.recordCanvas,
                                    inlineImages: this.inlineImages,
                                    onSerialize: e => {
                                        Ze(e, this.mirror) && this.iframeManager.addIframe(e), _e(e, this.mirror) && this.stylesheetManager.trackLinkElement(e), Ye(o) && this.shadowDomManager.addShadowRoot(Ce.shadowRoot(o), this.doc)
                                    },
                                    onIframeLoad: (e, t) => {
                                        this.iframeManager.attachIframe(e, t), this.shadowDomManager.observeAttachShadow(e)
                                    },
                                    onStylesheetLoad: (e, t) => {
                                        this.stylesheetManager.attachLinkElement(e, t)
                                    },
                                    cssCaptured: i
                                });
                                d && (e.push({
                                    parentId: l,
                                    nextId: c,
                                    node: d
                                }), t.add(d.id))
                            }
                        }; this.mapRemoves.length;) this.mirror.removeNodeFromMap(this.mapRemoves.shift());
                    for (var a of this.movedSet) nt(this.removesSubTreeCache, a, this.mirror) && !this.movedSet.has(Ce.parentNode(a)) || o(a);
                    for (var i of this.addedSet) ot(this.droppedSet, i) || nt(this.removesSubTreeCache, i, this.mirror) ? ot(this.movedSet, i) ? o(i) : this.droppedSet.add(i) : o(i);
                    for (var s = null; r.length;) {
                        var l = null;
                        if (s) {
                            var c = this.mirror.getId(Ce.parentNode(s.value)),
                                d = n(s.value); - 1 !== c && -1 !== d && (l = s)
                        }
                        if (!l)
                            for (var u = r.tail; u;) {
                                var h = u;
                                if (u = u.previous, h) {
                                    var p = this.mirror.getId(Ce.parentNode(h.value));
                                    if (-1 === n(h.value)) continue;
                                    if (-1 !== p) {
                                        l = h;
                                        break
                                    }
                                    var m = h.value,
                                        f = Ce.parentNode(m);
                                    if (f && f.nodeType === Node.DOCUMENT_FRAGMENT_NODE) {
                                        var g = Ce.host(f);
                                        if (-1 !== this.mirror.getId(g)) {
                                            l = h;
                                            break
                                        }
                                    }
                                }
                            }
                        if (!l) {
                            for (; r.head;) r.removeNode(r.head.value);
                            break
                        }
                        s = l.previous, r.removeNode(l.value), o(l.value)
                    }
                    var v = {
                        texts: this.texts.map((e => {
                            var t = e.node,
                                r = Ce.parentNode(t);
                            return r && "TEXTAREA" === r.tagName && this.genTextAreaValueMutation(r), {
                                id: this.mirror.getId(t),
                                value: e.value
                            }
                        })).filter((e => !t.has(e.id))).filter((e => this.mirror.has(e.id))),
                        attributes: this.attributes.map((e => {
                            var {
                                attributes: t
                            } = e;
                            if ("string" == typeof t.style) {
                                var r = JSON.stringify(e.styleDiff),
                                    n = JSON.stringify(e._unchangedStyles);
                                r.length < t.style.length && (r + n).split("var(").length === t.style.split("var(").length && (t.style = e.styleDiff)
                            }
                            return {
                                id: this.mirror.getId(e.node),
                                attributes: t
                            }
                        })).filter((e => !t.has(e.id))).filter((e => this.mirror.has(e.id))),
                        removes: this.removes,
                        adds: e
                    };
                    (v.texts.length || v.attributes.length || v.removes.length || v.adds.length) && (this.texts = [], this.attributes = [], this.attributeMap = new WeakMap, this.removes = [], this.addedSet = new Set, this.movedSet = new Set, this.droppedSet = new Set, this.removesSubTreeCache = new Set, this.movedMap = {}, this.mutationCb(v))
                }
            })), d(this, "genTextAreaValueMutation", (e => {
                var t = this.attributeMap.get(e);
                t || (t = {
                    node: e,
                    attributes: {},
                    styleDiff: {},
                    _unchangedStyles: {}
                }, this.attributes.push(t), this.attributeMap.set(e, t)), t.attributes.value = Array.from(Ce.childNodes(e), (e => Ce.textContent(e) || "")).join("")
            })), d(this, "processMutation", (e => {
                if (!Le(e.target, this.mirror, this.slimDOMOptions)) switch (e.type) {
                    case "characterData":
                        var t = Ce.textContent(e.target);
                        De(e.target, this.blockClass, this.blockSelector, !1) || t === e.oldValue || this.texts.push({
                            value: ie(e.target, this.maskTextClass, this.maskTextSelector, !0) && t ? this.maskTextFn ? this.maskTextFn(t, xe(e.target)) : t.replace(/[\S]/g, "*") : t,
                            node: e.target
                        });
                        break;
                    case "attributes":
                        var r = e.target,
                            n = e.attributeName,
                            o = e.target.getAttribute(n);
                        if ("value" === n) {
                            var a = L(r);
                            o = O({
                                element: r,
                                maskInputOptions: this.maskInputOptions,
                                tagName: r.tagName,
                                type: a,
                                value: o,
                                maskInputFn: this.maskInputFn
                            })
                        }
                        if (De(e.target, this.blockClass, this.blockSelector, !1) || o === e.oldValue) return;
                        var i = this.attributeMap.get(e.target);
                        if ("IFRAME" === r.tagName && "src" === n && !this.keepIframeSrcFn(o)) {
                            if (r.contentDocument) return;
                            n = "rr_src"
                        }
                        if (i || (i = {
                                node: e.target,
                                attributes: {},
                                styleDiff: {},
                                _unchangedStyles: {}
                            }, this.attributes.push(i), this.attributeMap.set(e.target, i)), "type" === n && "INPUT" === r.tagName && "password" === (e.oldValue || "").toLowerCase() && r.setAttribute("data-rr-is-password", "true"), !oe(r.tagName, n))
                            if (i.attributes[n] = ne(this.doc, x(r.tagName), x(n), o), "style" === n) {
                                if (!this.unattachedDoc) try {
                                    this.unattachedDoc = document.implementation.createHTMLDocument()
                                } catch (e) {
                                    this.unattachedDoc = this.doc
                                }
                                var s = this.unattachedDoc.createElement("span");
                                for (var l of (e.oldValue && s.setAttribute("style", e.oldValue), Array.from(r.style))) {
                                    var c = r.style.getPropertyValue(l),
                                        d = r.style.getPropertyPriority(l);
                                    c !== s.style.getPropertyValue(l) || d !== s.style.getPropertyPriority(l) ? i.styleDiff[l] = "" === d ? c : [c, d] : i._unchangedStyles[l] = [c, d]
                                }
                                for (var u of Array.from(s.style)) "" === r.style.getPropertyValue(u) && (i.styleDiff[u] = !1)
                            } else "open" === n && "DIALOG" === r.tagName && (r.matches("dialog:modal") ? i.attributes.rr_open_mode = "modal" : i.attributes.rr_open_mode = "non-modal");
                        break;
                    case "childList":
                        if (De(e.target, this.blockClass, this.blockSelector, !0)) return;
                        if ("TEXTAREA" === e.target.tagName) return void this.genTextAreaValueMutation(e.target);
                        e.addedNodes.forEach((t => this.genAdds(t, e.target))), e.removedNodes.forEach((t => {
                            var r = this.mirror.getId(t),
                                n = M(e.target) ? this.mirror.getId(Ce.host(e.target)) : this.mirror.getId(e.target);
                            De(e.target, this.blockClass, this.blockSelector, !1) || Le(t, this.mirror, this.slimDOMOptions) || ! function(e, t) {
                                return -1 !== t.getId(e)
                            }(t, this.mirror) || (this.addedSet.has(t) ? (rt(this.addedSet, t), this.droppedSet.add(t)) : this.addedSet.has(e.target) && -1 === r || Fe(e.target, this.mirror) || (this.movedSet.has(t) && this.movedMap[et(r, n)] ? rt(this.movedSet, t) : (this.removes.push({
                                parentId: n,
                                id: r,
                                isShadow: !(!M(e.target) || !A(e.target)) || void 0
                            }), function(e, t) {
                                var r = [e];
                                for (; r.length;) {
                                    var n = r.pop();
                                    t.has(n) || (t.add(n), Ce.childNodes(n).forEach((e => r.push(e))))
                                }
                            }(t, this.removesSubTreeCache))), this.mapRemoves.push(t))
                        }))
                }
            })), d(this, "genAdds", ((e, t) => {
                if (!this.processedNodeManager.inOtherBuffer(e, this) && !this.addedSet.has(e) && !this.movedSet.has(e)) {
                    if (this.mirror.hasNode(e)) {
                        if (Le(e, this.mirror, this.slimDOMOptions)) return;
                        this.movedSet.add(e);
                        var r = null;
                        t && this.mirror.hasNode(t) && (r = this.mirror.getId(t)), r && -1 !== r && (this.movedMap[et(this.mirror.getId(e), r)] = !0)
                    } else this.addedSet.add(e), this.droppedSet.delete(e);
                    De(e, this.blockClass, this.blockSelector, !1) || (Ce.childNodes(e).forEach((e => this.genAdds(e))), Ye(e) && Ce.childNodes(Ce.shadowRoot(e)).forEach((t => {
                        this.processedNodeManager.add(t, this), this.genAdds(t, e)
                    })))
                }
            }))
        }
        init(e) {
            ["mutationCb", "blockClass", "blockSelector", "maskTextClass", "maskTextSelector", "inlineStylesheet", "maskInputOptions", "maskTextFn", "maskInputFn", "keepIframeSrcFn", "recordCanvas", "inlineImages", "slimDOMOptions", "dataURLOptions", "doc", "mirror", "iframeManager", "stylesheetManager", "shadowDomManager", "canvasManager", "processedNodeManager"].forEach((t => {
                this[t] = e[t]
            }))
        }
        freeze() {
            this.frozen = !0, this.canvasManager.freeze()
        }
        unfreeze() {
            this.frozen = !1, this.canvasManager.unfreeze(), this.emit()
        }
        isFrozen() {
            return this.frozen
        }
        lock() {
            this.locked = !0, this.canvasManager.lock()
        }
        unlock() {
            this.locked = !1, this.canvasManager.unlock(), this.emit()
        }
        reset() {
            this.shadowDomManager.reset(), this.canvasManager.reset()
        }
    }

    function rt(e, t) {
        e.delete(t), Ce.childNodes(t).forEach((t => rt(e, t)))
    }

    function nt(e, t, r) {
        return 0 !== e.size && function(e, t, r) {
            var n = Ce.parentNode(t);
            return !!n && e.has(n)
        }(e, t)
    }

    function ot(e, t) {
        return 0 !== e.size && at(e, t)
    }

    function at(e, t) {
        var r = Ce.parentNode(t);
        return !!r && (!!e.has(r) || at(e, r))
    }
    var it = e => {
            if (!$e) return e;
            return function() {
                try {
                    return e(...arguments)
                } catch (e) {
                    if ($e && !0 === $e(e)) return;
                    throw e
                }
            }
        },
        st = [];

    function lt(e) {
        try {
            if ("composedPath" in e) {
                var t = e.composedPath();
                if (t.length) return t[0]
            } else if ("path" in e && e.path.length) return e.path[0]
        } catch (e) {}
        return e && e.target
    }

    function ct(e, t) {
        var r = new tt;
        st.push(r), r.init(e);
        var n = new(be())(it(r.processMutations.bind(r)));
        return n.observe(t, {
            attributes: !0,
            attributeOldValue: !0,
            characterData: !0,
            characterDataOldValue: !0,
            childList: !0,
            subtree: !0
        }), n
    }

    function dt(e) {
        var {
            mouseInteractionCb: t,
            doc: n,
            mirror: o,
            blockClass: a,
            blockSelector: i,
            sampling: s
        } = e;
        if (!1 === s.mouseInteraction) return () => {};
        var l = !0 === s.mouseInteraction || void 0 === s.mouseInteraction ? {} : s.mouseInteraction,
            c = [],
            d = null;
        return Object.keys(je).filter((e => Number.isNaN(Number(e)) && !e.endsWith("_Departed") && !1 !== l[e])).forEach((e => {
            var s = x(e),
                l = (e => n => {
                    var s = lt(n);
                    if (!De(s, a, i, !0)) {
                        var l = null,
                            c = e;
                        if ("pointerType" in n) {
                            switch (n.pointerType) {
                                case "mouse":
                                    l = ze.Mouse;
                                    break;
                                case "touch":
                                    l = ze.Touch;
                                    break;
                                case "pen":
                                    l = ze.Pen
                            }
                            l === ze.Touch ? je[e] === je.MouseDown ? c = "TouchStart" : je[e] === je.MouseUp && (c = "TouchEnd") : ze.Pen
                        } else Be(n) && (l = ze.Touch);
                        null !== l ? (d = l, (c.startsWith("Touch") && l === ze.Touch || c.startsWith("Mouse") && l === ze.Mouse) && (l = null)) : je[e] === je.Click && (l = d, d = null);
                        var u = Be(n) ? n.changedTouches[0] : n;
                        if (u) {
                            var h = o.getId(s),
                                {
                                    clientX: p,
                                    clientY: m
                                } = u;
                            it(t)(r({
                                type: je[c],
                                id: h,
                                x: p,
                                y: m
                            }, null !== l && {
                                pointerType: l
                            }))
                        }
                    }
                })(e);
            if (window.PointerEvent) switch (je[e]) {
                case je.MouseDown:
                case je.MouseUp:
                    s = s.replace("mouse", "pointer");
                    break;
                case je.TouchStart:
                case je.TouchEnd:
                    return
            }
            c.push(Se(s, l, n))
        })), it((() => {
            c.forEach((e => e()))
        }))
    }

    function ut(e) {
        var {
            scrollCb: t,
            doc: r,
            mirror: n,
            blockClass: o,
            blockSelector: a,
            sampling: i
        } = e;
        return Se("scroll", it(Me(it((e => {
            var i = lt(e);
            if (i && !De(i, o, a, !0)) {
                var s = n.getId(i);
                if (i === r && r.defaultView) {
                    var l = Re(r.defaultView);
                    t({
                        id: s,
                        x: l.left,
                        y: l.top
                    })
                } else t({
                    id: s,
                    x: i.scrollLeft,
                    y: i.scrollTop
                })
            }
        })), i.scroll || 100)), r)
    }
    var ht = ["INPUT", "TEXTAREA", "SELECT"],
        pt = new WeakMap;

    function mt(e) {
        return function(e, t) {
            if (yt("CSSGroupingRule") && e.parentRule instanceof CSSGroupingRule || yt("CSSMediaRule") && e.parentRule instanceof CSSMediaRule || yt("CSSSupportsRule") && e.parentRule instanceof CSSSupportsRule || yt("CSSConditionRule") && e.parentRule instanceof CSSConditionRule) {
                var r = Array.from(e.parentRule.cssRules).indexOf(e);
                t.unshift(r)
            } else if (e.parentStyleSheet) {
                var n = Array.from(e.parentStyleSheet.cssRules).indexOf(e);
                t.unshift(n)
            }
            return t
        }(e, [])
    }

    function ft(e, t, r) {
        var n, o;
        return e ? (e.ownerNode ? n = t.getId(e.ownerNode) : o = r.getId(e), {
            styleId: o,
            id: n
        }) : {}
    }

    function gt(e, t) {
        var r, n, o, {
                mirror: a,
                stylesheetManager: i
            } = e,
            s = null;
        s = "#document" === t.nodeName ? a.getId(t) : a.getId(Ce.host(t));
        var l = "#document" === t.nodeName ? null == (r = t.defaultView) ? void 0 : r.Document : null == (o = null == (n = t.ownerDocument) ? void 0 : n.defaultView) ? void 0 : o.ShadowRoot,
            c = (null == l ? void 0 : l.prototype) ? Object.getOwnPropertyDescriptor(null == l ? void 0 : l.prototype, "adoptedStyleSheets") : void 0;
        return null !== s && -1 !== s && l && c ? (Object.defineProperty(t, "adoptedStyleSheets", {
            configurable: c.configurable,
            enumerable: c.enumerable,
            get() {
                var e;
                return null == (e = c.get) ? void 0 : e.call(this)
            },
            set(e) {
                var t, r = null == (t = c.set) ? void 0 : t.call(this, e);
                if (null !== s && -1 !== s) try {
                    i.adoptStyleSheets(e, s)
                } catch (e) {}
                return r
            }
        }), it((() => {
            Object.defineProperty(t, "adoptedStyleSheets", {
                configurable: c.configurable,
                enumerable: c.enumerable,
                get: c.get,
                set: c.set
            })
        }))) : () => {}
    }

    function vt(e) {
        var t, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
            o = e.doc.defaultView;
        if (!o) return () => {};
        ! function(e, t) {
            var {
                mutationCb: r,
                mousemoveCb: n,
                mouseInteractionCb: o,
                scrollCb: a,
                viewportResizeCb: i,
                inputCb: s,
                mediaInteractionCb: l,
                styleSheetRuleCb: c,
                styleDeclarationCb: d,
                canvasMutationCb: u,
                fontCb: h,
                selectionCb: p,
                customElementCb: m
            } = e;
            e.mutationCb = function() {
                t.mutation && t.mutation(...arguments), r(...arguments)
            }, e.mousemoveCb = function() {
                t.mousemove && t.mousemove(...arguments), n(...arguments)
            }, e.mouseInteractionCb = function() {
                t.mouseInteraction && t.mouseInteraction(...arguments), o(...arguments)
            }, e.scrollCb = function() {
                t.scroll && t.scroll(...arguments), a(...arguments)
            }, e.viewportResizeCb = function() {
                t.viewportResize && t.viewportResize(...arguments), i(...arguments)
            }, e.inputCb = function() {
                t.input && t.input(...arguments), s(...arguments)
            }, e.mediaInteractionCb = function() {
                t.mediaInteaction && t.mediaInteaction(...arguments), l(...arguments)
            }, e.styleSheetRuleCb = function() {
                t.styleSheetRule && t.styleSheetRule(...arguments), c(...arguments)
            }, e.styleDeclarationCb = function() {
                t.styleDeclaration && t.styleDeclaration(...arguments), d(...arguments)
            }, e.canvasMutationCb = function() {
                t.canvasMutation && t.canvasMutation(...arguments), u(...arguments)
            }, e.fontCb = function() {
                t.font && t.font(...arguments), h(...arguments)
            }, e.selectionCb = function() {
                t.selection && t.selection(...arguments), p(...arguments)
            }, e.customElementCb = function() {
                t.customElement && t.customElement(...arguments), m(...arguments)
            }
        }(e, n), e.recordDOM && (t = ct(e, e.doc));
        var a = function(e) {
                var {
                    mousemoveCb: t,
                    sampling: r,
                    doc: n,
                    mirror: o
                } = e;
                if (!1 === r.mousemove) return () => {};
                var a, i = "number" == typeof r.mousemove ? r.mousemove : 50,
                    s = "number" == typeof r.mousemoveCallback ? r.mousemoveCallback : 500,
                    l = [],
                    c = Me(it((e => {
                        var r = Date.now() - a;
                        t(l.map((e => (e.timeOffset -= r, e))), e), l = [], a = null
                    })), s),
                    d = it(Me(it((e => {
                        var t = lt(e),
                            {
                                clientX: r,
                                clientY: n
                            } = Be(e) ? e.changedTouches[0] : e;
                        a || (a = Te()), l.push({
                            x: r,
                            y: n,
                            id: o.getId(t),
                            timeOffset: Te() - a
                        }), c("undefined" != typeof DragEvent && e instanceof DragEvent ? Xe.Drag : e instanceof MouseEvent ? Xe.MouseMove : Xe.TouchMove)
                    })), i, {
                        trailing: !1
                    })),
                    u = [Se("mousemove", d, n), Se("touchmove", d, n), Se("drag", d, n)];
                return it((() => {
                    u.forEach((e => e()))
                }))
            }(e),
            i = dt(e),
            s = ut(e),
            l = function(e, t) {
                var {
                    viewportResizeCb: r
                } = e, {
                    win: n
                } = t, o = -1, a = -1;
                return Se("resize", it(Me(it((() => {
                    var e = Ee(),
                        t = Oe();
                    o === e && a === t || (r({
                        width: Number(t),
                        height: Number(e)
                    }), o = e, a = t)
                })), 200)), n)
            }(e, {
                win: o
            }),
            c = function(e) {
                var {
                    inputCb: t,
                    doc: n,
                    mirror: o,
                    blockClass: a,
                    blockSelector: i,
                    ignoreClass: s,
                    ignoreSelector: l,
                    maskInputOptions: c,
                    maskInputFn: d,
                    sampling: u,
                    userTriggeredOnInput: h
                } = e;

                function p(e) {
                    var t = lt(e),
                        r = e.isTrusted,
                        o = t && t.tagName;
                    if (t && "OPTION" === o && (t = Ce.parentElement(t)), t && o && !(ht.indexOf(o) < 0) && !De(t, a, i, !0) && !(t.classList.contains(s) || l && t.matches(l))) {
                        var u = t.value,
                            p = !1,
                            f = L(t) || "";
                        "radio" === f || "checkbox" === f ? p = t.checked : (c[o.toLowerCase()] || c[f]) && (u = O({
                            element: t,
                            maskInputOptions: c,
                            tagName: o,
                            type: f,
                            value: u,
                            maskInputFn: d
                        })), m(t, h ? {
                            text: u,
                            isChecked: p,
                            userTriggered: r
                        } : {
                            text: u,
                            isChecked: p
                        });
                        var g = t.name;
                        "radio" === f && g && p && n.querySelectorAll('input[type="radio"][name="'.concat(g, '"]')).forEach((e => {
                            if (e !== t) {
                                var r = e.value;
                                m(e, h ? {
                                    text: r,
                                    isChecked: !p,
                                    userTriggered: !1
                                } : {
                                    text: r,
                                    isChecked: !p
                                })
                            }
                        }))
                    }
                }

                function m(e, n) {
                    var a = pt.get(e);
                    if (!a || a.text !== n.text || a.isChecked !== n.isChecked) {
                        pt.set(e, n);
                        var i = o.getId(e);
                        it(t)(r(r({}, n), {}, {
                            id: i
                        }))
                    }
                }
                var f = ("last" === u.input ? ["change"] : ["input", "change"]).map((e => Se(e, it(p), n))),
                    g = n.defaultView;
                if (!g) return () => {
                    f.forEach((e => e()))
                };
                var v = g.Object.getOwnPropertyDescriptor(g.HTMLInputElement.prototype, "value"),
                    y = [
                        [g.HTMLInputElement.prototype, "value"],
                        [g.HTMLInputElement.prototype, "checked"],
                        [g.HTMLSelectElement.prototype, "value"],
                        [g.HTMLTextAreaElement.prototype, "value"],
                        [g.HTMLSelectElement.prototype, "selectedIndex"],
                        [g.HTMLOptionElement.prototype, "selected"]
                    ];
                return v && v.set && f.push(...y.map((e => Ae(e[0], e[1], {
                    set() {
                        it(p)({
                            target: this,
                            isTrusted: !1
                        })
                    }
                }, !1, g)))), it((() => {
                    f.forEach((e => e()))
                }))
            }(e),
            d = function(e) {
                var {
                    mediaInteractionCb: t,
                    blockClass: r,
                    blockSelector: n,
                    mirror: o,
                    sampling: a,
                    doc: i
                } = e, s = it((e => Me(it((a => {
                    var i = lt(a);
                    if (i && !De(i, r, n, !0)) {
                        var {
                            currentTime: s,
                            volume: l,
                            muted: c,
                            playbackRate: d,
                            loop: u
                        } = i;
                        t({
                            type: e,
                            id: o.getId(i),
                            currentTime: s,
                            volume: l,
                            muted: c,
                            playbackRate: d,
                            loop: u
                        })
                    }
                })), a.media || 500))), l = [Se("play", s(Je.Play), i), Se("pause", s(Je.Pause), i), Se("seeked", s(Je.Seeked), i), Se("volumechange", s(Je.VolumeChange), i), Se("ratechange", s(Je.RateChange), i)];
                return it((() => {
                    l.forEach((e => e()))
                }))
            }(e),
            u = () => {},
            h = () => {},
            p = () => {},
            m = () => {};
        e.recordDOM && (u = function(e, t) {
            var {
                styleSheetRuleCb: r,
                mirror: n,
                stylesheetManager: o
            } = e, {
                win: a
            } = t;
            if (!a.CSSStyleSheet || !a.CSSStyleSheet.prototype) return () => {};
            var i = a.CSSStyleSheet.prototype.insertRule;
            a.CSSStyleSheet.prototype.insertRule = new Proxy(i, {
                apply: it(((e, t, a) => {
                    var [i, s] = a, {
                        id: l,
                        styleId: c
                    } = ft(t, n, o.styleMirror);
                    return (l && -1 !== l || c && -1 !== c) && r({
                        id: l,
                        styleId: c,
                        adds: [{
                            rule: i,
                            index: s
                        }]
                    }), e.apply(t, a)
                }))
            }), a.CSSStyleSheet.prototype.addRule = function(e, t) {
                var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : this.cssRules.length,
                    n = "".concat(e, " { ").concat(t, " }");
                return a.CSSStyleSheet.prototype.insertRule.apply(this, [n, r])
            };
            var s, l, c = a.CSSStyleSheet.prototype.deleteRule;
            a.CSSStyleSheet.prototype.deleteRule = new Proxy(c, {
                apply: it(((e, t, a) => {
                    var [i] = a, {
                        id: s,
                        styleId: l
                    } = ft(t, n, o.styleMirror);
                    return (s && -1 !== s || l && -1 !== l) && r({
                        id: s,
                        styleId: l,
                        removes: [{
                            index: i
                        }]
                    }), e.apply(t, a)
                }))
            }), a.CSSStyleSheet.prototype.removeRule = function(e) {
                return a.CSSStyleSheet.prototype.deleteRule.apply(this, [e])
            }, a.CSSStyleSheet.prototype.replace && (s = a.CSSStyleSheet.prototype.replace, a.CSSStyleSheet.prototype.replace = new Proxy(s, {
                apply: it(((e, t, a) => {
                    var [i] = a, {
                        id: s,
                        styleId: l
                    } = ft(t, n, o.styleMirror);
                    return (s && -1 !== s || l && -1 !== l) && r({
                        id: s,
                        styleId: l,
                        replace: i
                    }), e.apply(t, a)
                }))
            })), a.CSSStyleSheet.prototype.replaceSync && (l = a.CSSStyleSheet.prototype.replaceSync, a.CSSStyleSheet.prototype.replaceSync = new Proxy(l, {
                apply: it(((e, t, a) => {
                    var [i] = a, {
                        id: s,
                        styleId: l
                    } = ft(t, n, o.styleMirror);
                    return (s && -1 !== s || l && -1 !== l) && r({
                        id: s,
                        styleId: l,
                        replaceSync: i
                    }), e.apply(t, a)
                }))
            }));
            var d = {};
            It("CSSGroupingRule") ? d.CSSGroupingRule = a.CSSGroupingRule : (It("CSSMediaRule") && (d.CSSMediaRule = a.CSSMediaRule), It("CSSConditionRule") && (d.CSSConditionRule = a.CSSConditionRule), It("CSSSupportsRule") && (d.CSSSupportsRule = a.CSSSupportsRule));
            var u = {};
            return Object.entries(d).forEach((e => {
                var [t, a] = e;
                u[t] = {
                    insertRule: a.prototype.insertRule,
                    deleteRule: a.prototype.deleteRule
                }, a.prototype.insertRule = new Proxy(u[t].insertRule, {
                    apply: it(((e, t, a) => {
                        var [i, s] = a, {
                            id: l,
                            styleId: c
                        } = ft(t.parentStyleSheet, n, o.styleMirror);
                        return (l && -1 !== l || c && -1 !== c) && r({
                            id: l,
                            styleId: c,
                            adds: [{
                                rule: i,
                                index: [...mt(t), s || 0]
                            }]
                        }), e.apply(t, a)
                    }))
                }), a.prototype.deleteRule = new Proxy(u[t].deleteRule, {
                    apply: it(((e, t, a) => {
                        var [i] = a, {
                            id: s,
                            styleId: l
                        } = ft(t.parentStyleSheet, n, o.styleMirror);
                        return (s && -1 !== s || l && -1 !== l) && r({
                            id: s,
                            styleId: l,
                            removes: [{
                                index: [...mt(t), i]
                            }]
                        }), e.apply(t, a)
                    }))
                })
            })), it((() => {
                a.CSSStyleSheet.prototype.insertRule = i, a.CSSStyleSheet.prototype.deleteRule = c, s && (a.CSSStyleSheet.prototype.replace = s), l && (a.CSSStyleSheet.prototype.replaceSync = l), Object.entries(d).forEach((e => {
                    var [t, r] = e;
                    r.prototype.insertRule = u[t].insertRule, r.prototype.deleteRule = u[t].deleteRule
                }))
            }))
        }(e, {
            win: o
        }), h = gt(e, e.doc), p = function(e, t) {
            var {
                styleDeclarationCb: r,
                mirror: n,
                ignoreCSSAttributes: o,
                stylesheetManager: a
            } = e, {
                win: i
            } = t, s = i.CSSStyleDeclaration.prototype.setProperty;
            i.CSSStyleDeclaration.prototype.setProperty = new Proxy(s, {
                apply: it(((e, t, i) => {
                    var l, [c, d, u] = i;
                    if (o.has(c)) return s.apply(t, [c, d, u]);
                    var {
                        id: h,
                        styleId: p
                    } = ft(null == (l = t.parentRule) ? void 0 : l.parentStyleSheet, n, a.styleMirror);
                    return (h && -1 !== h || p && -1 !== p) && r({
                        id: h,
                        styleId: p,
                        set: {
                            property: c,
                            value: d,
                            priority: u
                        },
                        index: mt(t.parentRule)
                    }), e.apply(t, i)
                }))
            });
            var l = i.CSSStyleDeclaration.prototype.removeProperty;
            return i.CSSStyleDeclaration.prototype.removeProperty = new Proxy(l, {
                apply: it(((e, t, i) => {
                    var s, [c] = i;
                    if (o.has(c)) return l.apply(t, [c]);
                    var {
                        id: d,
                        styleId: u
                    } = ft(null == (s = t.parentRule) ? void 0 : s.parentStyleSheet, n, a.styleMirror);
                    return (d && -1 !== d || u && -1 !== u) && r({
                        id: d,
                        styleId: u,
                        remove: {
                            property: c
                        },
                        index: mt(t.parentRule)
                    }), e.apply(t, i)
                }))
            }), it((() => {
                i.CSSStyleDeclaration.prototype.setProperty = s, i.CSSStyleDeclaration.prototype.removeProperty = l
            }))
        }(e, {
            win: o
        }), e.collectFonts && (m = function(e) {
            var {
                fontCb: t,
                doc: r
            } = e, n = r.defaultView;
            if (!n) return () => {};
            var o = [],
                a = new WeakMap,
                i = n.FontFace;
            n.FontFace = function(e, t, r) {
                var n = new i(e, t, r);
                return a.set(n, {
                    family: e,
                    buffer: "string" != typeof t,
                    descriptors: r,
                    fontSource: "string" == typeof t ? t : JSON.stringify(Array.from(new Uint8Array(t)))
                }), n
            };
            var s = ke(r.fonts, "add", (function(e) {
                return function(r) {
                    return setTimeout(it((() => {
                        var e = a.get(r);
                        e && (t(e), a.delete(r))
                    })), 0), e.apply(this, [r])
                }
            }));
            return o.push((() => {
                n.FontFace = i
            })), o.push(s), it((() => {
                o.forEach((e => e()))
            }))
        }(e)));
        var f = function(e) {
                var {
                    doc: t,
                    mirror: r,
                    blockClass: n,
                    blockSelector: o,
                    selectionCb: a
                } = e, i = !0, s = it((() => {
                    var e = t.getSelection();
                    if (!(!e || i && (null == e ? void 0 : e.isCollapsed))) {
                        i = e.isCollapsed || !1;
                        for (var s = [], l = e.rangeCount || 0, c = 0; c < l; c++) {
                            var d = e.getRangeAt(c),
                                {
                                    startContainer: u,
                                    startOffset: h,
                                    endContainer: p,
                                    endOffset: m
                                } = d;
                            De(u, n, o, !0) || De(p, n, o, !0) || s.push({
                                start: r.getId(u),
                                startOffset: h,
                                end: r.getId(p),
                                endOffset: m
                            })
                        }
                        a({
                            ranges: s
                        })
                    }
                }));
                return s(), Se("selectionchange", s)
            }(e),
            g = function(e) {
                var {
                    doc: t,
                    customElementCb: r
                } = e, n = t.defaultView;
                return n && n.customElements ? ke(n.customElements, "define", (function(e) {
                    return function(t, n, o) {
                        try {
                            r({
                                define: {
                                    name: t
                                }
                            })
                        } catch (e) {
                            console.warn("Custom element callback failed for ".concat(t))
                        }
                        return e.apply(this, [t, n, o])
                    }
                })) : () => {}
            }(e),
            v = [];
        for (var y of e.plugins) v.push(y.observer(y.callback, o, y.options));
        return it((() => {
            st.forEach((e => e.reset())), null == t || t.disconnect(), a(), i(), s(), l(), c(), d(), u(), h(), p(), m(), f(), g(), v.forEach((e => e()))
        }))
    }

    function yt(e) {
        return void 0 !== window[e]
    }

    function It(e) {
        return Boolean(void 0 !== window[e] && window[e].prototype && "insertRule" in window[e].prototype && "deleteRule" in window[e].prototype)
    }
    class bt {
        constructor(e) {
            d(this, "iframeIdToRemoteIdMap", new WeakMap), d(this, "iframeRemoteIdToIdMap", new WeakMap), this.generateIdFn = e
        }
        getId(e, t, r, n) {
            var o = r || this.getIdToRemoteIdMap(e),
                a = n || this.getRemoteIdToIdMap(e),
                i = o.get(t);
            return i || (i = this.generateIdFn(), o.set(t, i), a.set(i, t)), i
        }
        getIds(e, t) {
            var r = this.getIdToRemoteIdMap(e),
                n = this.getRemoteIdToIdMap(e);
            return t.map((t => this.getId(e, t, r, n)))
        }
        getRemoteId(e, t, r) {
            var n = r || this.getRemoteIdToIdMap(e);
            if ("number" != typeof t) return t;
            var o = n.get(t);
            return o || -1
        }
        getRemoteIds(e, t) {
            var r = this.getRemoteIdToIdMap(e);
            return t.map((t => this.getRemoteId(e, t, r)))
        }
        reset(e) {
            if (!e) return this.iframeIdToRemoteIdMap = new WeakMap, void(this.iframeRemoteIdToIdMap = new WeakMap);
            this.iframeIdToRemoteIdMap.delete(e), this.iframeRemoteIdToIdMap.delete(e)
        }
        getIdToRemoteIdMap(e) {
            var t = this.iframeIdToRemoteIdMap.get(e);
            return t || (t = new Map, this.iframeIdToRemoteIdMap.set(e, t)), t
        }
        getRemoteIdToIdMap(e) {
            var t = this.iframeRemoteIdToIdMap.get(e);
            return t || (t = new Map, this.iframeRemoteIdToIdMap.set(e, t)), t
        }
    }
    class Ct {
        constructor(e) {
            d(this, "iframes", new WeakMap), d(this, "crossOriginIframeMap", new WeakMap), d(this, "crossOriginIframeMirror", new bt(U)), d(this, "crossOriginIframeStyleMirror"), d(this, "crossOriginIframeRootIdMap", new WeakMap), d(this, "mirror"), d(this, "mutationCb"), d(this, "wrappedEmit"), d(this, "loadListener"), d(this, "stylesheetManager"), d(this, "recordCrossOriginIframes"), this.mutationCb = e.mutationCb, this.wrappedEmit = e.wrappedEmit, this.stylesheetManager = e.stylesheetManager, this.recordCrossOriginIframes = e.recordCrossOriginIframes, this.crossOriginIframeStyleMirror = new bt(this.stylesheetManager.styleMirror.generateId.bind(this.stylesheetManager.styleMirror)), this.mirror = e.mirror, this.recordCrossOriginIframes && window.addEventListener("message", this.handleMessage.bind(this))
        }
        addIframe(e) {
            this.iframes.set(e, !0), e.contentWindow && this.crossOriginIframeMap.set(e.contentWindow, e)
        }
        addLoadListener(e) {
            this.loadListener = e
        }
        attachIframe(e, t) {
            var r, n;
            this.mutationCb({
                adds: [{
                    parentId: this.mirror.getId(e),
                    nextId: null,
                    node: t
                }],
                removes: [],
                texts: [],
                attributes: [],
                isAttachIframe: !0
            }), this.recordCrossOriginIframes && (null == (r = e.contentWindow) || r.addEventListener("message", this.handleMessage.bind(this))), null == (n = this.loadListener) || n.call(this, e), e.contentDocument && e.contentDocument.adoptedStyleSheets && e.contentDocument.adoptedStyleSheets.length > 0 && this.stylesheetManager.adoptStyleSheets(e.contentDocument.adoptedStyleSheets, this.mirror.getId(e.contentDocument))
        }
        handleMessage(e) {
            var t = e;
            if ("rrweb" === t.data.type && t.origin === t.data.origin && e.source) {
                var r = this.crossOriginIframeMap.get(e.source);
                if (r) {
                    var n = this.transformCrossOriginEvent(r, t.data.event);
                    n && this.wrappedEmit(n, t.data.isCheckout)
                }
            }
        }
        transformCrossOriginEvent(e, t) {
            var r;
            switch (t.type) {
                case Pe.FullSnapshot:
                    this.crossOriginIframeMirror.reset(e), this.crossOriginIframeStyleMirror.reset(e), this.replaceIdOnNode(t.data.node, e);
                    var n = t.data.node.id;
                    return this.crossOriginIframeRootIdMap.set(e, n), this.patchRootIdOnNode(t.data.node, n), {
                        timestamp: t.timestamp,
                        type: Pe.IncrementalSnapshot,
                        data: {
                            source: Xe.Mutation,
                            adds: [{
                                parentId: this.mirror.getId(e),
                                nextId: null,
                                node: t.data.node
                            }],
                            removes: [],
                            texts: [],
                            attributes: [],
                            isAttachIframe: !0
                        }
                    };
                case Pe.Meta:
                case Pe.Load:
                case Pe.DomContentLoaded:
                    return !1;
                case Pe.Plugin:
                    return t;
                case Pe.Custom:
                    return this.replaceIds(t.data.payload, e, ["id", "parentId", "previousId", "nextId"]), t;
                case Pe.IncrementalSnapshot:
                    switch (t.data.source) {
                        case Xe.Mutation:
                            return t.data.adds.forEach((t => {
                                this.replaceIds(t, e, ["parentId", "nextId", "previousId"]), this.replaceIdOnNode(t.node, e);
                                var r = this.crossOriginIframeRootIdMap.get(e);
                                r && this.patchRootIdOnNode(t.node, r)
                            })), t.data.removes.forEach((t => {
                                this.replaceIds(t, e, ["parentId", "id"])
                            })), t.data.attributes.forEach((t => {
                                this.replaceIds(t, e, ["id"])
                            })), t.data.texts.forEach((t => {
                                this.replaceIds(t, e, ["id"])
                            })), t;
                        case Xe.Drag:
                        case Xe.TouchMove:
                        case Xe.MouseMove:
                            return t.data.positions.forEach((t => {
                                this.replaceIds(t, e, ["id"])
                            })), t;
                        case Xe.ViewportResize:
                            return !1;
                        case Xe.MediaInteraction:
                        case Xe.MouseInteraction:
                        case Xe.Scroll:
                        case Xe.CanvasMutation:
                        case Xe.Input:
                            return this.replaceIds(t.data, e, ["id"]), t;
                        case Xe.StyleSheetRule:
                        case Xe.StyleDeclaration:
                            return this.replaceIds(t.data, e, ["id"]), this.replaceStyleIds(t.data, e, ["styleId"]), t;
                        case Xe.Font:
                            return t;
                        case Xe.Selection:
                            return t.data.ranges.forEach((t => {
                                this.replaceIds(t, e, ["start", "end"])
                            })), t;
                        case Xe.AdoptedStyleSheet:
                            return this.replaceIds(t.data, e, ["id"]), this.replaceStyleIds(t.data, e, ["styleIds"]), null == (r = t.data.styles) || r.forEach((t => {
                                this.replaceStyleIds(t, e, ["styleId"])
                            })), t
                    }
            }
            return !1
        }
        replace(e, t, r, n) {
            for (var o of n)(Array.isArray(t[o]) || "number" == typeof t[o]) && (Array.isArray(t[o]) ? t[o] = e.getIds(r, t[o]) : t[o] = e.getId(r, t[o]));
            return t
        }
        replaceIds(e, t, r) {
            return this.replace(this.crossOriginIframeMirror, e, t, r)
        }
        replaceStyleIds(e, t, r) {
            return this.replace(this.crossOriginIframeStyleMirror, e, t, r)
        }
        replaceIdOnNode(e, t) {
            this.replaceIds(e, t, ["id", "rootId"]), "childNodes" in e && e.childNodes.forEach((e => {
                this.replaceIdOnNode(e, t)
            }))
        }
        patchRootIdOnNode(e, t) {
            e.type === Ue.Document || e.rootId || (e.rootId = t), "childNodes" in e && e.childNodes.forEach((e => {
                this.patchRootIdOnNode(e, t)
            }))
        }
    }
    class St {
        constructor(e) {
            d(this, "shadowDoms", new WeakSet), d(this, "mutationCb"), d(this, "scrollCb"), d(this, "bypassOptions"), d(this, "mirror"), d(this, "restoreHandlers", []), this.mutationCb = e.mutationCb, this.scrollCb = e.scrollCb, this.bypassOptions = e.bypassOptions, this.mirror = e.mirror, this.init()
        }
        init() {
            this.reset(), this.patchAttachShadow(Element, document)
        }
        addShadowRoot(e, t) {
            if (A(e) && !this.shadowDoms.has(e)) {
                this.shadowDoms.add(e);
                var n = ct(r(r({}, this.bypassOptions), {}, {
                    doc: t,
                    mutationCb: this.mutationCb,
                    mirror: this.mirror,
                    shadowDomManager: this
                }), e);
                this.restoreHandlers.push((() => n.disconnect())), this.restoreHandlers.push(ut(r(r({}, this.bypassOptions), {}, {
                    scrollCb: this.scrollCb,
                    doc: e,
                    mirror: this.mirror
                }))), setTimeout((() => {
                    e.adoptedStyleSheets && e.adoptedStyleSheets.length > 0 && this.bypassOptions.stylesheetManager.adoptStyleSheets(e.adoptedStyleSheets, this.mirror.getId(Ce.host(e))), this.restoreHandlers.push(gt({
                        mirror: this.mirror,
                        stylesheetManager: this.bypassOptions.stylesheetManager
                    }, e))
                }), 0)
            }
        }
        observeAttachShadow(e) {
            e.contentWindow && e.contentDocument && this.patchAttachShadow(e.contentWindow.Element, e.contentDocument)
        }
        patchAttachShadow(e, t) {
            var r = this;
            this.restoreHandlers.push(ke(e.prototype, "attachShadow", (function(e) {
                return function(n) {
                    var o = e.call(this, n),
                        a = Ce.shadowRoot(this);
                    return a && He(this) && r.addShadowRoot(a, t), o
                }
            })))
        }
        reset() {
            this.restoreHandlers.forEach((e => {
                try {
                    e()
                } catch (e) {}
            })), this.restoreHandlers = [], this.shadowDoms = new WeakSet
        }
    }
    for (var wt = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", Nt = "undefined" == typeof Uint8Array ? [] : new Uint8Array(256), Mt = 0; Mt < 64; Mt++) Nt[wt.charCodeAt(Mt)] = Mt;
    var At = new Map;
    var kt = (e, t, r) => {
        if (e && (Et(e, t) || "object" == typeof e)) {
            var n = function(e, t) {
                    var r = At.get(e);
                    return r || (r = new Map, At.set(e, r)), r.has(t) || r.set(t, []), r.get(t)
                }(r, e.constructor.name),
                o = n.indexOf(e);
            return -1 === o && (o = n.length, n.push(e)), o
        }
    };

    function Tt(e, t, r) {
        if (e instanceof Array) return e.map((e => Tt(e, t, r)));
        if (null === e) return e;
        if (e instanceof Float32Array || e instanceof Float64Array || e instanceof Int32Array || e instanceof Uint32Array || e instanceof Uint8Array || e instanceof Uint16Array || e instanceof Int16Array || e instanceof Int8Array || e instanceof Uint8ClampedArray) return {
            rr_type: e.constructor.name,
            args: [Object.values(e)]
        };
        if (e instanceof ArrayBuffer) return {
            rr_type: e.constructor.name,
            base64: function(e) {
                var t, r = new Uint8Array(e),
                    n = r.length,
                    o = "";
                for (t = 0; t < n; t += 3) o += wt[r[t] >> 2], o += wt[(3 & r[t]) << 4 | r[t + 1] >> 4], o += wt[(15 & r[t + 1]) << 2 | r[t + 2] >> 6], o += wt[63 & r[t + 2]];
                return n % 3 == 2 ? o = o.substring(0, o.length - 1) + "=" : n % 3 == 1 && (o = o.substring(0, o.length - 2) + "=="), o
            }(e)
        };
        if (e instanceof DataView) return {
            rr_type: e.constructor.name,
            args: [Tt(e.buffer, t, r), e.byteOffset, e.byteLength]
        };
        if (e instanceof HTMLImageElement) {
            var n = e.constructor.name,
                {
                    src: o
                } = e;
            return {
                rr_type: n,
                src: o
            }
        }
        if (e instanceof HTMLCanvasElement) {
            return {
                rr_type: "HTMLImageElement",
                src: e.toDataURL()
            }
        }
        return e instanceof ImageData ? {
            rr_type: e.constructor.name,
            args: [Tt(e.data, t, r), e.width, e.height]
        } : Et(e, t) || "object" == typeof e ? {
            rr_type: e.constructor.name,
            index: kt(e, t, r)
        } : e
    }
    var Rt = (e, t, r) => e.map((e => Tt(e, t, r))),
        Et = (e, t) => {
            var r = ["WebGLActiveInfo", "WebGLBuffer", "WebGLFramebuffer", "WebGLProgram", "WebGLRenderbuffer", "WebGLShader", "WebGLShaderPrecisionFormat", "WebGLTexture", "WebGLUniformLocation", "WebGLVertexArrayObject", "WebGLVertexArrayObjectOES"].filter((e => "function" == typeof t[e]));
            return Boolean(r.find((r => e instanceof t[r])))
        };

    function Ot(e, t, r, n) {
        var o = [];
        try {
            var a = ke(e.HTMLCanvasElement.prototype, "getContext", (function(e) {
                return function(o) {
                    for (var a = arguments.length, i = new Array(a > 1 ? a - 1 : 0), s = 1; s < a; s++) i[s - 1] = arguments[s];
                    if (!De(this, t, r, !0)) {
                        var l = function(e) {
                            return "experimental-webgl" === e ? "webgl" : e
                        }(o);
                        if ("__context" in this || (this.__context = l), n && ["webgl", "webgl2"].includes(l))
                            if (i[0] && "object" == typeof i[0]) {
                                var c = i[0];
                                c.preserveDrawingBuffer || (c.preserveDrawingBuffer = !0)
                            } else i.splice(0, 1, {
                                preserveDrawingBuffer: !0
                            })
                    }
                    return e.apply(this, [o, ...i])
                }
            }));
            o.push(a)
        } catch (e) {
            console.error("failed to patch HTMLCanvasElement.prototype.getContext")
        }
        return () => {
            o.forEach((e => e()))
        }
    }

    function xt(e, t, r, n, o, a) {
        var i = [],
            s = Object.getOwnPropertyNames(e),
            l = function(s) {
                if (["isContextLost", "canvas", "drawingBufferWidth", "drawingBufferHeight"].includes(s)) return "continue";
                try {
                    if ("function" != typeof e[s]) return "continue";
                    var l = ke(e, s, (function(e) {
                        return function() {
                            for (var i = arguments.length, l = new Array(i), c = 0; c < i; c++) l[c] = arguments[c];
                            var d = e.apply(this, l);
                            if (kt(d, a, this), "tagName" in this.canvas && !De(this.canvas, n, o, !0)) {
                                var u = Rt(l, a, this),
                                    h = {
                                        type: t,
                                        property: s,
                                        args: u
                                    };
                                r(this.canvas, h)
                            }
                            return d
                        }
                    }));
                    i.push(l)
                } catch (n) {
                    var c = Ae(e, s, {
                        set(e) {
                            r(this.canvas, {
                                type: t,
                                property: s,
                                args: [e],
                                setter: !0
                            })
                        }
                    });
                    i.push(c)
                }
            };
        for (var c of s) l(c);
        return i
    }
    var Dt, Lt, Ft, Bt, Zt = "KGZ1bmN0aW9uKCkgewogICJ1c2Ugc3RyaWN0IjsKICB2YXIgY2hhcnMgPSAiQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODkrLyI7CiAgdmFyIGxvb2t1cCA9IHR5cGVvZiBVaW50OEFycmF5ID09PSAidW5kZWZpbmVkIiA/IFtdIDogbmV3IFVpbnQ4QXJyYXkoMjU2KTsKICBmb3IgKHZhciBpID0gMDsgaSA8IGNoYXJzLmxlbmd0aDsgaSsrKSB7CiAgICBsb29rdXBbY2hhcnMuY2hhckNvZGVBdChpKV0gPSBpOwogIH0KICB2YXIgZW5jb2RlID0gZnVuY3Rpb24oYXJyYXlidWZmZXIpIHsKICAgIHZhciBieXRlcyA9IG5ldyBVaW50OEFycmF5KGFycmF5YnVmZmVyKSwgaTIsIGxlbiA9IGJ5dGVzLmxlbmd0aCwgYmFzZTY0ID0gIiI7CiAgICBmb3IgKGkyID0gMDsgaTIgPCBsZW47IGkyICs9IDMpIHsKICAgICAgYmFzZTY0ICs9IGNoYXJzW2J5dGVzW2kyXSA+PiAyXTsKICAgICAgYmFzZTY0ICs9IGNoYXJzWyhieXRlc1tpMl0gJiAzKSA8PCA0IHwgYnl0ZXNbaTIgKyAxXSA+PiA0XTsKICAgICAgYmFzZTY0ICs9IGNoYXJzWyhieXRlc1tpMiArIDFdICYgMTUpIDw8IDIgfCBieXRlc1tpMiArIDJdID4+IDZdOwogICAgICBiYXNlNjQgKz0gY2hhcnNbYnl0ZXNbaTIgKyAyXSAmIDYzXTsKICAgIH0KICAgIGlmIChsZW4gJSAzID09PSAyKSB7CiAgICAgIGJhc2U2NCA9IGJhc2U2NC5zdWJzdHJpbmcoMCwgYmFzZTY0Lmxlbmd0aCAtIDEpICsgIj0iOwogICAgfSBlbHNlIGlmIChsZW4gJSAzID09PSAxKSB7CiAgICAgIGJhc2U2NCA9IGJhc2U2NC5zdWJzdHJpbmcoMCwgYmFzZTY0Lmxlbmd0aCAtIDIpICsgIj09IjsKICAgIH0KICAgIHJldHVybiBiYXNlNjQ7CiAgfTsKICBjb25zdCBsYXN0QmxvYk1hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7CiAgY29uc3QgdHJhbnNwYXJlbnRCbG9iTWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTsKICBhc3luYyBmdW5jdGlvbiBnZXRUcmFuc3BhcmVudEJsb2JGb3Iod2lkdGgsIGhlaWdodCwgZGF0YVVSTE9wdGlvbnMpIHsKICAgIGNvbnN0IGlkID0gYCR7d2lkdGh9LSR7aGVpZ2h0fWA7CiAgICBpZiAoIk9mZnNjcmVlbkNhbnZhcyIgaW4gZ2xvYmFsVGhpcykgewogICAgICBpZiAodHJhbnNwYXJlbnRCbG9iTWFwLmhhcyhpZCkpIHJldHVybiB0cmFuc3BhcmVudEJsb2JNYXAuZ2V0KGlkKTsKICAgICAgY29uc3Qgb2Zmc2NyZWVuID0gbmV3IE9mZnNjcmVlbkNhbnZhcyh3aWR0aCwgaGVpZ2h0KTsKICAgICAgb2Zmc2NyZWVuLmdldENvbnRleHQoIjJkIik7CiAgICAgIGNvbnN0IGJsb2IgPSBhd2FpdCBvZmZzY3JlZW4uY29udmVydFRvQmxvYihkYXRhVVJMT3B0aW9ucyk7CiAgICAgIGNvbnN0IGFycmF5QnVmZmVyID0gYXdhaXQgYmxvYi5hcnJheUJ1ZmZlcigpOwogICAgICBjb25zdCBiYXNlNjQgPSBlbmNvZGUoYXJyYXlCdWZmZXIpOwogICAgICB0cmFuc3BhcmVudEJsb2JNYXAuc2V0KGlkLCBiYXNlNjQpOwogICAgICByZXR1cm4gYmFzZTY0OwogICAgfSBlbHNlIHsKICAgICAgcmV0dXJuICIiOwogICAgfQogIH0KICBjb25zdCB3b3JrZXIgPSBzZWxmOwogIHdvcmtlci5vbm1lc3NhZ2UgPSBhc3luYyBmdW5jdGlvbihlKSB7CiAgICBpZiAoIk9mZnNjcmVlbkNhbnZhcyIgaW4gZ2xvYmFsVGhpcykgewogICAgICBjb25zdCB7IGlkLCBiaXRtYXAsIHdpZHRoLCBoZWlnaHQsIGRhdGFVUkxPcHRpb25zIH0gPSBlLmRhdGE7CiAgICAgIGNvbnN0IHRyYW5zcGFyZW50QmFzZTY0ID0gZ2V0VHJhbnNwYXJlbnRCbG9iRm9yKAogICAgICAgIHdpZHRoLAogICAgICAgIGhlaWdodCwKICAgICAgICBkYXRhVVJMT3B0aW9ucwogICAgICApOwogICAgICBjb25zdCBvZmZzY3JlZW4gPSBuZXcgT2Zmc2NyZWVuQ2FudmFzKHdpZHRoLCBoZWlnaHQpOwogICAgICBjb25zdCBjdHggPSBvZmZzY3JlZW4uZ2V0Q29udGV4dCgiMmQiKTsKICAgICAgY3R4LmRyYXdJbWFnZShiaXRtYXAsIDAsIDApOwogICAgICBiaXRtYXAuY2xvc2UoKTsKICAgICAgY29uc3QgYmxvYiA9IGF3YWl0IG9mZnNjcmVlbi5jb252ZXJ0VG9CbG9iKGRhdGFVUkxPcHRpb25zKTsKICAgICAgY29uc3QgdHlwZSA9IGJsb2IudHlwZTsKICAgICAgY29uc3QgYXJyYXlCdWZmZXIgPSBhd2FpdCBibG9iLmFycmF5QnVmZmVyKCk7CiAgICAgIGNvbnN0IGJhc2U2NCA9IGVuY29kZShhcnJheUJ1ZmZlcik7CiAgICAgIGlmICghbGFzdEJsb2JNYXAuaGFzKGlkKSAmJiBhd2FpdCB0cmFuc3BhcmVudEJhc2U2NCA9PT0gYmFzZTY0KSB7CiAgICAgICAgbGFzdEJsb2JNYXAuc2V0KGlkLCBiYXNlNjQpOwogICAgICAgIHJldHVybiB3b3JrZXIucG9zdE1lc3NhZ2UoeyBpZCB9KTsKICAgICAgfQogICAgICBpZiAobGFzdEJsb2JNYXAuZ2V0KGlkKSA9PT0gYmFzZTY0KSByZXR1cm4gd29ya2VyLnBvc3RNZXNzYWdlKHsgaWQgfSk7CiAgICAgIHdvcmtlci5wb3N0TWVzc2FnZSh7CiAgICAgICAgaWQsCiAgICAgICAgdHlwZSwKICAgICAgICBiYXNlNjQsCiAgICAgICAgd2lkdGgsCiAgICAgICAgaGVpZ2h0CiAgICAgIH0pOwogICAgICBsYXN0QmxvYk1hcC5zZXQoaWQsIGJhc2U2NCk7CiAgICB9IGVsc2UgewogICAgICByZXR1cm4gd29ya2VyLnBvc3RNZXNzYWdlKHsgaWQ6IGUuZGF0YS5pZCB9KTsKICAgIH0KICB9Owp9KSgpOwovLyMgc291cmNlTWFwcGluZ1VSTD1pbWFnZS1iaXRtYXAtZGF0YS11cmwtd29ya2VyLUlKcEM3Z19iLmpzLm1hcAo=",
        _t = "undefined" != typeof window && window.Blob && new Blob([(Dt = Zt, Uint8Array.from(atob(Dt), (e => e.charCodeAt(0))))], {
            type: "text/javascript;charset=utf-8"
        });

    function Yt(e) {
        var t;
        try {
            if (!(t = _t && (window.URL || window.webkitURL).createObjectURL(_t))) throw "";
            var r = new Worker(t, {
                name: null == e ? void 0 : e.name
            });
            return r.addEventListener("error", (() => {
                (window.URL || window.webkitURL).revokeObjectURL(t)
            })), r
        } catch (t) {
            return new Worker("data:text/javascript;base64," + Zt, {
                name: null == e ? void 0 : e.name
            })
        } finally {
            t && (window.URL || window.webkitURL).revokeObjectURL(t)
        }
    }
    class Wt {
        constructor(e) {
            d(this, "pendingCanvasMutations", new Map), d(this, "rafStamps", {
                latestId: 0,
                invokeId: null
            }), d(this, "mirror"), d(this, "mutationCb"), d(this, "resetObservers"), d(this, "frozen", !1), d(this, "locked", !1), d(this, "processMutation", ((e, t) => {
                !(this.rafStamps.invokeId && this.rafStamps.latestId !== this.rafStamps.invokeId) && this.rafStamps.invokeId || (this.rafStamps.invokeId = this.rafStamps.latestId), this.pendingCanvasMutations.has(e) || this.pendingCanvasMutations.set(e, []), this.pendingCanvasMutations.get(e).push(t)
            }));
            var {
                sampling: t = "all",
                win: r,
                blockClass: n,
                blockSelector: o,
                recordCanvas: a,
                dataURLOptions: i
            } = e;
            this.mutationCb = e.mutationCb, this.mirror = e.mirror, a && "all" === t && this.initCanvasMutationObserver(r, n, o), a && "number" == typeof t && this.initCanvasFPSObserver(t, r, n, o, {
                dataURLOptions: i
            })
        }
        reset() {
            this.pendingCanvasMutations.clear(), this.resetObservers && this.resetObservers()
        }
        freeze() {
            this.frozen = !0
        }
        unfreeze() {
            this.frozen = !1
        }
        lock() {
            this.locked = !0
        }
        unlock() {
            this.locked = !1
        }
        initCanvasFPSObserver(e, t, r, n, a) {
            var i = this,
                s = Ot(t, r, n, !0),
                l = new Map,
                c = new Yt;
            c.onmessage = e => {
                var {
                    id: t
                } = e.data;
                if (l.set(t, !1), "base64" in e.data) {
                    var {
                        base64: r,
                        type: n,
                        width: o,
                        height: a
                    } = e.data;
                    this.mutationCb({
                        id: t,
                        type: Ke["2D"],
                        commands: [{
                            property: "clearRect",
                            args: [0, 0, o, a]
                        }, {
                            property: "drawImage",
                            args: [{
                                rr_type: "ImageBitmap",
                                args: [{
                                    rr_type: "Blob",
                                    data: [{
                                        rr_type: "ArrayBuffer",
                                        base64: r
                                    }],
                                    type: n
                                }]
                            }, 0, 0]
                        }]
                    })
                }
            };
            var d, u = 1e3 / e,
                h = 0,
                p = e => {
                    var s, m;
                    h && e - h < u ? d = requestAnimationFrame(p) : (h = e, (s = [], m = e => {
                        e.querySelectorAll("canvas").forEach((e => {
                            De(e, r, n, !0) || s.push(e)
                        })), e.querySelectorAll("*").forEach((e => {
                            e.shadowRoot && m(e.shadowRoot)
                        }))
                    }, m(t.document), s).forEach(function() {
                        var e = o((function*(e) {
                            var t, r = i.mirror.getId(e);
                            if (!l.get(r) && 0 !== e.width && 0 !== e.height) {
                                if (l.set(r, !0), ["webgl", "webgl2"].includes(e.__context)) {
                                    var n = e.getContext(e.__context);
                                    !1 === (null == (t = null == n ? void 0 : n.getContextAttributes()) ? void 0 : t.preserveDrawingBuffer) && n.clear(n.COLOR_BUFFER_BIT)
                                }
                                var o = e.clientWidth || e.width,
                                    s = e.clientHeight || e.height,
                                    d = yield createImageBitmap(e, {
                                        resizeWidth: o,
                                        resizeHeight: s
                                    });
                                c.postMessage({
                                    id: r,
                                    bitmap: d,
                                    width: o,
                                    height: s,
                                    dataURLOptions: a.dataURLOptions
                                }, [d])
                            }
                        }));
                        return function(t) {
                            return e.apply(this, arguments)
                        }
                    }()), d = requestAnimationFrame(p))
                };
            d = requestAnimationFrame(p), this.resetObservers = () => {
                s(), cancelAnimationFrame(d)
            }
        }
        initCanvasMutationObserver(e, t, r) {
            this.startRAFTimestamping(), this.startPendingCanvasMutationFlusher();
            var n = Ot(e, t, r, !1),
                o = function(e, t, r, n) {
                    var o = [],
                        a = Object.getOwnPropertyNames(t.CanvasRenderingContext2D.prototype),
                        i = function(a) {
                            try {
                                if ("function" != typeof t.CanvasRenderingContext2D.prototype[a]) return "continue";
                                var i = ke(t.CanvasRenderingContext2D.prototype, a, (function(o) {
                                    return function() {
                                        for (var i = arguments.length, s = new Array(i), l = 0; l < i; l++) s[l] = arguments[l];
                                        return De(this.canvas, r, n, !0) || setTimeout((() => {
                                            var r = Rt(s, t, this);
                                            e(this.canvas, {
                                                type: Ke["2D"],
                                                property: a,
                                                args: r
                                            })
                                        }), 0), o.apply(this, s)
                                    }
                                }));
                                o.push(i)
                            } catch (r) {
                                var s = Ae(t.CanvasRenderingContext2D.prototype, a, {
                                    set(t) {
                                        e(this.canvas, {
                                            type: Ke["2D"],
                                            property: a,
                                            args: [t],
                                            setter: !0
                                        })
                                    }
                                });
                                o.push(s)
                            }
                        };
                    for (var s of a) i(s);
                    return () => {
                        o.forEach((e => e()))
                    }
                }(this.processMutation.bind(this), e, t, r),
                a = function(e, t, r, n) {
                    var o = [];
                    return o.push(...xt(t.WebGLRenderingContext.prototype, Ke.WebGL, e, r, n, t)), void 0 !== t.WebGL2RenderingContext && o.push(...xt(t.WebGL2RenderingContext.prototype, Ke.WebGL2, e, r, n, t)), () => {
                        o.forEach((e => e()))
                    }
                }(this.processMutation.bind(this), e, t, r);
            this.resetObservers = () => {
                n(), o(), a()
            }
        }
        startPendingCanvasMutationFlusher() {
            requestAnimationFrame((() => this.flushPendingCanvasMutations()))
        }
        startRAFTimestamping() {
            var e = t => {
                this.rafStamps.latestId = t, requestAnimationFrame(e)
            };
            requestAnimationFrame(e)
        }
        flushPendingCanvasMutations() {
            this.pendingCanvasMutations.forEach(((e, t) => {
                var r = this.mirror.getId(t);
                this.flushPendingCanvasMutationFor(t, r)
            })), requestAnimationFrame((() => this.flushPendingCanvasMutations()))
        }
        flushPendingCanvasMutationFor(e, t) {
            if (!this.frozen && !this.locked) {
                var r = this.pendingCanvasMutations.get(e);
                if (r && -1 !== t) {
                    var n = r.map((e => i(e, l))),
                        {
                            type: o
                        } = r[0];
                    this.mutationCb({
                        id: t,
                        type: o,
                        commands: n
                    }), this.pendingCanvasMutations.delete(e)
                }
            }
        }
    }
    class Gt {
        constructor(e) {
            d(this, "trackedLinkElements", new WeakSet), d(this, "mutationCb"), d(this, "adoptedStyleSheetCb"), d(this, "styleMirror", new We), this.mutationCb = e.mutationCb, this.adoptedStyleSheetCb = e.adoptedStyleSheetCb
        }
        attachLinkElement(e, t) {
            "_cssText" in t.attributes && this.mutationCb({
                adds: [],
                removes: [],
                texts: [],
                attributes: [{
                    id: t.id,
                    attributes: t.attributes
                }]
            }), this.trackLinkElement(e)
        }
        trackLinkElement(e) {
            this.trackedLinkElements.has(e) || (this.trackedLinkElements.add(e), this.trackStylesheetInLinkElement(e))
        }
        adoptStyleSheets(e, t) {
            var r = this;
            if (0 !== e.length) {
                var n = {
                        id: t,
                        styleIds: []
                    },
                    o = [],
                    a = function(e) {
                        var t = void 0;
                        r.styleMirror.has(e) ? t = r.styleMirror.getId(e) : (t = r.styleMirror.add(e), o.push({
                            styleId: t,
                            rules: Array.from(e.rules || CSSRule, ((t, r) => ({
                                rule: T(t, e.href),
                                index: r
                            })))
                        })), n.styleIds.push(t)
                    };
                for (var i of e) a(i);
                o.length > 0 && (n.styles = o), this.adoptedStyleSheetCb(n)
            }
        }
        reset() {
            this.styleMirror.reset(), this.trackedLinkElements = new WeakSet
        }
        trackStylesheetInLinkElement(e) {}
    }
    class Vt {
        constructor() {
            d(this, "nodeMap", new WeakMap), d(this, "active", !1)
        }
        inOtherBuffer(e, t) {
            var r = this.nodeMap.get(e);
            return r && Array.from(r).some((e => e !== t))
        }
        add(e, t) {
            this.active || (this.active = !0, requestAnimationFrame((() => {
                this.nodeMap = new WeakMap, this.active = !1
            }))), this.nodeMap.set(e, (this.nodeMap.get(e) || new Set).add(t))
        }
        destroy() {}
    }
    var Ht = !1;
    try {
        if (2 !== Array.from([1], (e => 2 * e))[0]) {
            var Pt = document.createElement("iframe");
            document.body.appendChild(Pt), Array.from = (null == (s = Pt.contentWindow) ? void 0 : s.Array.from) || Array.from, document.body.removeChild(Pt)
        }
    } catch (e) {
        console.debug("Unable to override Array.from", e)
    }
    var Xt, jt, zt = new E;

    function Kt() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
            {
                emit: t,
                checkoutEveryNms: n,
                checkoutEveryNth: o,
                blockClass: a = "rr-block",
                blockSelector: i = null,
                ignoreClass: s = "rr-ignore",
                ignoreSelector: l = null,
                maskTextClass: c = "rr-mask",
                maskTextSelector: d = null,
                inlineStylesheet: u = !0,
                maskAllInputs: h,
                maskInputOptions: p,
                slimDOMOptions: m,
                maskInputFn: f,
                maskTextFn: g,
                hooks: v,
                packFn: y,
                sampling: I = {},
                dataURLOptions: b = {},
                mousemoveWait: C,
                recordDOM: S = !0,
                recordCanvas: w = !1,
                recordCrossOriginIframes: N = !1,
                recordAfter: M = ("DOMContentLoaded" === e.recordAfter ? e.recordAfter : "load"),
                userTriggeredOnInput: A = !1,
                collectFonts: k = !1,
                inlineImages: T = !1,
                plugins: R,
                keepIframeSrcFn: O = (() => !1),
                ignoreCSSAttributes: x = new Set([]),
                errorHandler: D
            } = e;
        $e = D;
        var L = !N || window.parent === window,
            F = !1;
        if (!L) try {
            window.parent.document && (F = !1)
        } catch (e) {
            F = !0
        }
        if (L && !t) throw new Error("emit function is required");
        if (!L && !F) return () => {};
        void 0 !== C && void 0 === I.mousemove && (I.mousemove = C), zt.reset();
        var B, Z = !0 === h ? {
                color: !0,
                date: !0,
                "datetime-local": !0,
                email: !0,
                month: !0,
                number: !0,
                range: !0,
                search: !0,
                tel: !0,
                text: !0,
                time: !0,
                url: !0,
                week: !0,
                textarea: !0,
                select: !0,
                password: !0
            } : void 0 !== p ? p : {
                password: !0
            },
            _ = !0 === m || "all" === m ? {
                script: !0,
                comment: !0,
                headFavicon: !0,
                headWhitespace: !0,
                headMetaSocial: !0,
                headMetaRobots: !0,
                headMetaHttpEquiv: !0,
                headMetaVerification: !0,
                headMetaAuthorship: "all" === m,
                headMetaDescKeywords: "all" === m,
                headTitleMutations: "all" === m
            } : m || {};
        ! function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : window;
            "NodeList" in e && !e.NodeList.prototype.forEach && (e.NodeList.prototype.forEach = Array.prototype.forEach), "DOMTokenList" in e && !e.DOMTokenList.prototype.forEach && (e.DOMTokenList.prototype.forEach = Array.prototype.forEach)
        }();
        var Y = 0,
            W = e => {
                for (var t of R || []) t.eventProcessor && (e = t.eventProcessor(e));
                return y && !F && (e = y(e)), e
            };
        Lt = (e, r) => {
            var a, i = e;
            if (i.timestamp = Te(), !(null == (a = st[0]) ? void 0 : a.isFrozen()) || i.type === Pe.FullSnapshot || i.type === Pe.IncrementalSnapshot && i.data.source === Xe.Mutation || st.forEach((e => e.unfreeze())), L) null == t || t(W(i), r);
            else if (F) {
                var s = {
                    type: "rrweb",
                    event: W(i),
                    origin: window.location.origin,
                    isCheckout: r
                };
                window.parent.postMessage(s, "*")
            }
            if (i.type === Pe.FullSnapshot) B = i, Y = 0;
            else if (i.type === Pe.IncrementalSnapshot) {
                if (i.data.source === Xe.Mutation && i.data.isAttachIframe) return;
                Y++;
                var l = o && Y >= o,
                    c = n && i.timestamp - B.timestamp > n;
                (l || c) && Ft(!0)
            }
        };
        var G = e => {
                Lt({
                    type: Pe.IncrementalSnapshot,
                    data: r({
                        source: Xe.Mutation
                    }, e)
                })
            },
            V = e => Lt({
                type: Pe.IncrementalSnapshot,
                data: r({
                    source: Xe.Scroll
                }, e)
            }),
            H = e => Lt({
                type: Pe.IncrementalSnapshot,
                data: r({
                    source: Xe.CanvasMutation
                }, e)
            }),
            P = new Gt({
                mutationCb: G,
                adoptedStyleSheetCb: e => Lt({
                    type: Pe.IncrementalSnapshot,
                    data: r({
                        source: Xe.AdoptedStyleSheet
                    }, e)
                })
            }),
            X = new Ct({
                mirror: zt,
                mutationCb: G,
                stylesheetManager: P,
                recordCrossOriginIframes: N,
                wrappedEmit: Lt
            });
        for (var j of R || []) j.getMirror && j.getMirror({
            nodeMirror: zt,
            crossOriginIframeMirror: X.crossOriginIframeMirror,
            crossOriginIframeStyleMirror: X.crossOriginIframeStyleMirror
        });
        var z = new Vt;
        Bt = new Wt({
            recordCanvas: w,
            mutationCb: H,
            win: window,
            blockClass: a,
            blockSelector: i,
            mirror: zt,
            sampling: I.canvas,
            dataURLOptions: b
        });
        var K = new St({
            mutationCb: G,
            scrollCb: V,
            bypassOptions: {
                blockClass: a,
                blockSelector: i,
                maskTextClass: c,
                maskTextSelector: d,
                inlineStylesheet: u,
                maskInputOptions: Z,
                dataURLOptions: b,
                maskTextFn: g,
                maskInputFn: f,
                recordCanvas: w,
                inlineImages: T,
                sampling: I,
                slimDOMOptions: _,
                iframeManager: X,
                stylesheetManager: P,
                canvasManager: Bt,
                keepIframeSrcFn: O,
                processedNodeManager: z
            },
            mirror: zt
        });
        Ft = function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
            if (S) {
                Lt({
                    type: Pe.Meta,
                    data: {
                        href: window.location.href,
                        width: Oe(),
                        height: Ee()
                    }
                }, e), P.reset(), K.init(), st.forEach((e => e.lock()));
                var t = function(e, t) {
                    var {
                        mirror: r = new E,
                        blockClass: n = "rr-block",
                        blockSelector: o = null,
                        maskTextClass: a = "rr-mask",
                        maskTextSelector: i = null,
                        inlineStylesheet: s = !0,
                        inlineImages: l = !1,
                        recordCanvas: c = !1,
                        maskAllInputs: d = !1,
                        maskTextFn: u,
                        maskInputFn: h,
                        slimDOM: p = !1,
                        dataURLOptions: m,
                        preserveWhiteSpace: f,
                        onSerialize: g,
                        onIframeLoad: v,
                        iframeLoadTimeout: y,
                        onStylesheetLoad: I,
                        stylesheetLoadTimeout: b,
                        keepIframeSrcFn: C = (() => !1)
                    } = t || {};
                    return ce(e, {
                        doc: e,
                        mirror: r,
                        blockClass: n,
                        blockSelector: o,
                        maskTextClass: a,
                        maskTextSelector: i,
                        skipChild: !1,
                        inlineStylesheet: s,
                        maskInputOptions: !0 === d ? {
                            color: !0,
                            date: !0,
                            "datetime-local": !0,
                            email: !0,
                            month: !0,
                            number: !0,
                            range: !0,
                            search: !0,
                            tel: !0,
                            text: !0,
                            time: !0,
                            url: !0,
                            week: !0,
                            textarea: !0,
                            select: !0,
                            password: !0
                        } : !1 === d ? {
                            password: !0
                        } : d,
                        maskTextFn: u,
                        maskInputFn: h,
                        slimDOMOptions: !0 === p || "all" === p ? {
                            script: !0,
                            comment: !0,
                            headFavicon: !0,
                            headWhitespace: !0,
                            headMetaDescKeywords: "all" === p,
                            headMetaSocial: !0,
                            headMetaRobots: !0,
                            headMetaHttpEquiv: !0,
                            headMetaAuthorship: !0,
                            headMetaVerification: !0
                        } : !1 === p ? {} : p,
                        dataURLOptions: m,
                        inlineImages: l,
                        recordCanvas: c,
                        preserveWhiteSpace: f,
                        onSerialize: g,
                        onIframeLoad: v,
                        iframeLoadTimeout: y,
                        onStylesheetLoad: I,
                        stylesheetLoadTimeout: b,
                        keepIframeSrcFn: C,
                        newlyAddedElement: !1
                    })
                }(document, {
                    mirror: zt,
                    blockClass: a,
                    blockSelector: i,
                    maskTextClass: c,
                    maskTextSelector: d,
                    inlineStylesheet: u,
                    maskAllInputs: Z,
                    maskTextFn: g,
                    maskInputFn: f,
                    slimDOM: _,
                    dataURLOptions: b,
                    recordCanvas: w,
                    inlineImages: T,
                    onSerialize: e => {
                        Ze(e, zt) && X.addIframe(e), _e(e, zt) && P.trackLinkElement(e), Ye(e) && K.addShadowRoot(Ce.shadowRoot(e), document)
                    },
                    onIframeLoad: (e, t) => {
                        X.attachIframe(e, t), K.observeAttachShadow(e)
                    },
                    onStylesheetLoad: (e, t) => {
                        P.attachLinkElement(e, t)
                    },
                    keepIframeSrcFn: O
                });
                if (!t) return console.warn("Failed to snapshot the document");
                Lt({
                    type: Pe.FullSnapshot,
                    data: {
                        node: t,
                        initialOffset: Re(window)
                    }
                }, e), st.forEach((e => e.unlock())), document.adoptedStyleSheets && document.adoptedStyleSheets.length > 0 && P.adoptStyleSheets(document.adoptedStyleSheets, zt.getId(document))
            }
        };
        try {
            var J = [],
                U = e => {
                    var t;
                    return it(vt)({
                        mutationCb: G,
                        mousemoveCb: (e, t) => Lt({
                            type: Pe.IncrementalSnapshot,
                            data: {
                                source: t,
                                positions: e
                            }
                        }),
                        mouseInteractionCb: e => Lt({
                            type: Pe.IncrementalSnapshot,
                            data: r({
                                source: Xe.MouseInteraction
                            }, e)
                        }),
                        scrollCb: V,
                        viewportResizeCb: e => Lt({
                            type: Pe.IncrementalSnapshot,
                            data: r({
                                source: Xe.ViewportResize
                            }, e)
                        }),
                        inputCb: e => Lt({
                            type: Pe.IncrementalSnapshot,
                            data: r({
                                source: Xe.Input
                            }, e)
                        }),
                        mediaInteractionCb: e => Lt({
                            type: Pe.IncrementalSnapshot,
                            data: r({
                                source: Xe.MediaInteraction
                            }, e)
                        }),
                        styleSheetRuleCb: e => Lt({
                            type: Pe.IncrementalSnapshot,
                            data: r({
                                source: Xe.StyleSheetRule
                            }, e)
                        }),
                        styleDeclarationCb: e => Lt({
                            type: Pe.IncrementalSnapshot,
                            data: r({
                                source: Xe.StyleDeclaration
                            }, e)
                        }),
                        canvasMutationCb: H,
                        fontCb: e => Lt({
                            type: Pe.IncrementalSnapshot,
                            data: r({
                                source: Xe.Font
                            }, e)
                        }),
                        selectionCb: e => {
                            Lt({
                                type: Pe.IncrementalSnapshot,
                                data: r({
                                    source: Xe.Selection
                                }, e)
                            })
                        },
                        customElementCb: e => {
                            Lt({
                                type: Pe.IncrementalSnapshot,
                                data: r({
                                    source: Xe.CustomElement
                                }, e)
                            })
                        },
                        blockClass: a,
                        ignoreClass: s,
                        ignoreSelector: l,
                        maskTextClass: c,
                        maskTextSelector: d,
                        maskInputOptions: Z,
                        inlineStylesheet: u,
                        sampling: I,
                        recordDOM: S,
                        recordCanvas: w,
                        inlineImages: T,
                        userTriggeredOnInput: A,
                        collectFonts: k,
                        doc: e,
                        maskInputFn: f,
                        maskTextFn: g,
                        keepIframeSrcFn: O,
                        blockSelector: i,
                        slimDOMOptions: _,
                        dataURLOptions: b,
                        mirror: zt,
                        iframeManager: X,
                        stylesheetManager: P,
                        shadowDomManager: K,
                        processedNodeManager: z,
                        canvasManager: Bt,
                        ignoreCSSAttributes: x,
                        plugins: (null == (t = null == R ? void 0 : R.filter((e => e.observer))) ? void 0 : t.map((e => ({
                            observer: e.observer,
                            options: e.options,
                            callback: t => Lt({
                                type: Pe.Plugin,
                                data: {
                                    plugin: e.name,
                                    payload: t
                                }
                            })
                        })))) || []
                    }, v)
                };
            X.addLoadListener((e => {
                try {
                    J.push(U(e.contentDocument))
                } catch (e) {
                    console.warn(e)
                }
            }));
            var q = () => {
                Ft(), J.push(U(document)), Ht = !0
            };
            return "interactive" === document.readyState || "complete" === document.readyState ? q() : (J.push(Se("DOMContentLoaded", (() => {
                Lt({
                    type: Pe.DomContentLoaded,
                    data: {}
                }), "DOMContentLoaded" === M && q()
            }))), J.push(Se("load", (() => {
                Lt({
                    type: Pe.Load,
                    data: {}
                }), "load" === M && q()
            }), window))), () => {
                J.forEach((e => e())), z.destroy(), Ht = !1, $e = void 0
            }
        } catch (e) {
            console.warn(e)
        }
    }
    Kt.addCustomEvent = (e, t) => {
        if (!Ht) throw new Error("please add custom event after start recording");
        Lt({
            type: Pe.Custom,
            data: {
                tag: e,
                payload: t
            }
        })
    }, Kt.freezePage = () => {
        st.forEach((e => e.freeze()))
    }, Kt.takeFullSnapshot = e => {
        if (!Ht) throw new Error("please take full snapshot after start recording");
        Ft(e)
    }, Kt.mirror = zt, (jt = Xt || (Xt = {}))[jt.NotStarted = 0] = "NotStarted", jt[jt.Running = 1] = "Running", jt[jt.Stopped = 2] = "Stopped";
    var Jt, Ut = Object.defineProperty,
        qt = (e, t, r) => ((e, t, r) => t in e ? Ut(e, t, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: r
        }) : e[t] = r)(e, "symbol" != typeof t ? t + "" : t, r),
        Qt = Object.defineProperty,
        $t = (e, t, r) => ((e, t, r) => t in e ? Qt(e, t, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: r
        }) : e[t] = r)(e, "symbol" != typeof t ? t + "" : t, r),
        er = Object.defineProperty,
        tr = (e, t, r) => ((e, t, r) => t in e ? er(e, t, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: r
        }) : e[t] = r)(e, "symbol" != typeof t ? t + "" : t, r),
        rr = {
            Node: ["childNodes", "parentNode", "parentElement", "textContent"],
            ShadowRoot: ["host", "styleSheets"],
            Element: ["shadowRoot", "querySelector", "querySelectorAll"],
            MutationObserver: []
        },
        nr = {
            Node: ["contains", "getRootNode"],
            ShadowRoot: ["getSelection"],
            Element: [],
            MutationObserver: ["constructor"]
        },
        or = {},
        ar = () => !!globalThis.Zone;

    function ir(e) {
        if (or[e]) return or[e];
        var t = globalThis[e],
            r = t.prototype,
            n = e in rr ? rr[e] : void 0,
            o = Boolean(n && n.every((e => {
                var t, n;
                return Boolean(null == (n = null == (t = Object.getOwnPropertyDescriptor(r, e)) ? void 0 : t.get) ? void 0 : n.toString().includes("[native code]"))
            }))),
            a = e in nr ? nr[e] : void 0,
            i = Boolean(a && a.every((e => {
                var t;
                return "function" == typeof r[e] && (null == (t = r[e]) ? void 0 : t.toString().includes("[native code]"))
            })));
        if (o && i && !ar()) return or[e] = t.prototype, t.prototype;
        try {
            var s = document.createElement("iframe");
            document.body.appendChild(s);
            var l = s.contentWindow;
            if (!l) return t.prototype;
            var c = l[e].prototype;
            return document.body.removeChild(s), c ? or[e] = c : r
        } catch (e) {
            return r
        }
    }
    var sr = {};

    function lr(e, t, r) {
        var n, o = "".concat(e, ".").concat(String(r));
        if (sr[o]) return sr[o].call(t);
        var a = ir(e),
            i = null == (n = Object.getOwnPropertyDescriptor(a, r)) ? void 0 : n.get;
        return i ? (sr[o] = i, i.call(t)) : t[r]
    }
    var cr = {};

    function dr(e, t, r) {
        var n = "".concat(e, ".").concat(String(r));
        if (cr[n]) return cr[n].bind(t);
        var o = ir(e)[r];
        return "function" != typeof o ? t[r] : (cr[n] = o, o.bind(t))
    }
    var ur = {
        childNodes: function(e) {
            return lr("Node", e, "childNodes")
        },
        parentNode: function(e) {
            return lr("Node", e, "parentNode")
        },
        parentElement: function(e) {
            return lr("Node", e, "parentElement")
        },
        textContent: function(e) {
            return lr("Node", e, "textContent")
        },
        contains: function(e, t) {
            return dr("Node", e, "contains")(t)
        },
        getRootNode: function(e) {
            return dr("Node", e, "getRootNode")()
        },
        host: function(e) {
            return e && "host" in e ? lr("ShadowRoot", e, "host") : null
        },
        styleSheets: function(e) {
            return e.styleSheets
        },
        shadowRoot: function(e) {
            return e && "shadowRoot" in e ? lr("Element", e, "shadowRoot") : null
        },
        querySelector: function(e, t) {
            return lr("Element", e, "querySelector")(t)
        },
        querySelectorAll: function(e, t) {
            return lr("Element", e, "querySelectorAll")(t)
        },
        mutationObserver: function() {
            return ir("MutationObserver").constructor
        }
    };
    class hr {
        constructor() {
            tr(this, "idNodeMap", new Map), tr(this, "nodeMetaMap", new WeakMap)
        }
        getId(e) {
            var t;
            if (!e) return -1;
            var r = null == (t = this.getMeta(e)) ? void 0 : t.id;
            return null != r ? r : -1
        }
        getNode(e) {
            return this.idNodeMap.get(e) || null
        }
        getIds() {
            return Array.from(this.idNodeMap.keys())
        }
        getMeta(e) {
            return this.nodeMetaMap.get(e) || null
        }
        removeNodeFromMap(e) {
            var t = this.getId(e);
            this.idNodeMap.delete(t), e.childNodes && e.childNodes.forEach((e => this.removeNodeFromMap(e)))
        }
        has(e) {
            return this.idNodeMap.has(e)
        }
        hasNode(e) {
            return this.nodeMetaMap.has(e)
        }
        add(e, t) {
            var r = t.id;
            this.idNodeMap.set(r, e), this.nodeMetaMap.set(e, t)
        }
        replace(e, t) {
            var r = this.getNode(e);
            if (r) {
                var n = this.nodeMetaMap.get(r);
                n && this.nodeMetaMap.set(t, n)
            }
            this.idNodeMap.set(e, t)
        }
        reset() {
            this.idNodeMap = new Map, this.nodeMetaMap = new WeakMap
        }
    }

    function pr(e, t, r) {
        if (!e) return !1;
        if (e.nodeType !== e.ELEMENT_NODE) return !!r && pr(ur.parentNode(e), t, r);
        for (var n = e.classList.length; n--;) {
            var o = e.classList[n];
            if (t.test(o)) return !0
        }
        return !!r && pr(ur.parentNode(e), t, r)
    }
    class mr {
        constructor() {
            __publicField22(this, "parentElement", null), __publicField22(this, "parentNode", null), __publicField22(this, "ownerDocument"), __publicField22(this, "firstChild", null), __publicField22(this, "lastChild", null), __publicField22(this, "previousSibling", null), __publicField22(this, "nextSibling", null), __publicField22(this, "ELEMENT_NODE", 1), __publicField22(this, "TEXT_NODE", 3), __publicField22(this, "nodeType"), __publicField22(this, "nodeName"), __publicField22(this, "RRNodeType")
        }
        get childNodes() {
            for (var e = [], t = this.firstChild; t;) e.push(t), t = t.nextSibling;
            return e
        }
        contains(e) {
            if (!(e instanceof mr)) return !1;
            if (e.ownerDocument !== this.ownerDocument) return !1;
            if (e === this) return !0;
            for (; e.parentNode;) {
                if (e.parentNode === this) return !0;
                e = e.parentNode
            }
            return !1
        }
        appendChild(e) {
            throw new Error("RRDomException: Failed to execute 'appendChild' on 'RRNode': This RRNode type does not support this method.")
        }
        insertBefore(e, t) {
            throw new Error("RRDomException: Failed to execute 'insertBefore' on 'RRNode': This RRNode type does not support this method.")
        }
        removeChild(e) {
            throw new Error("RRDomException: Failed to execute 'removeChild' on 'RRNode': This RRNode type does not support this method.")
        }
        toString() {
            return "RRNode"
        }
    }
    var fr = {
            Node: ["childNodes", "parentNode", "parentElement", "textContent"],
            ShadowRoot: ["host", "styleSheets"],
            Element: ["shadowRoot", "querySelector", "querySelectorAll"],
            MutationObserver: []
        },
        gr = {
            Node: ["contains", "getRootNode"],
            ShadowRoot: ["getSelection"],
            Element: [],
            MutationObserver: ["constructor"]
        },
        vr = {},
        yr = () => !!globalThis.Zone;

    function Ir(e) {
        if (vr[e]) return vr[e];
        var t = globalThis[e],
            r = t.prototype,
            n = e in fr ? fr[e] : void 0,
            o = Boolean(n && n.every((e => {
                var t, n;
                return Boolean(null == (n = null == (t = Object.getOwnPropertyDescriptor(r, e)) ? void 0 : t.get) ? void 0 : n.toString().includes("[native code]"))
            }))),
            a = e in gr ? gr[e] : void 0,
            i = Boolean(a && a.every((e => {
                var t;
                return "function" == typeof r[e] && (null == (t = r[e]) ? void 0 : t.toString().includes("[native code]"))
            })));
        if (o && i && !yr()) return vr[e] = t.prototype, t.prototype;
        try {
            var s = document.createElement("iframe");
            document.body.appendChild(s);
            var l = s.contentWindow;
            if (!l) return t.prototype;
            var c = l[e].prototype;
            return document.body.removeChild(s), c ? vr[e] = c : r
        } catch (e) {
            return r
        }
    }
    var br = {};

    function Cr(e, t, r) {
        var n, o = "".concat(e, ".").concat(String(r));
        if (br[o]) return br[o].call(t);
        var a = Ir(e),
            i = null == (n = Object.getOwnPropertyDescriptor(a, r)) ? void 0 : n.get;
        return i ? (br[o] = i, i.call(t)) : t[r]
    }
    var Sr = {};

    function wr(e, t, r) {
        var n = "".concat(e, ".").concat(String(r));
        if (Sr[n]) return Sr[n].bind(t);
        var o = Ir(e)[r];
        return "function" != typeof o ? t[r] : (Sr[n] = o, o.bind(t))
    }
    var Nr = {
        childNodes: function(e) {
            return Cr("Node", e, "childNodes")
        },
        parentNode: function(e) {
            return Cr("Node", e, "parentNode")
        },
        parentElement: function(e) {
            return Cr("Node", e, "parentElement")
        },
        textContent: function(e) {
            return Cr("Node", e, "textContent")
        },
        contains: function(e, t) {
            return wr("Node", e, "contains")(t)
        },
        getRootNode: function(e) {
            return wr("Node", e, "getRootNode")()
        },
        host: function(e) {
            return e && "host" in e ? Cr("ShadowRoot", e, "host") : null
        },
        styleSheets: function(e) {
            return e.styleSheets
        },
        shadowRoot: function(e) {
            return e && "shadowRoot" in e ? Cr("Element", e, "shadowRoot") : null
        },
        querySelector: function(e, t) {
            return Cr("Element", e, "querySelector")(t)
        },
        querySelectorAll: function(e, t) {
            return Cr("Element", e, "querySelectorAll")(t)
        },
        mutationObserver: function() {
            return Ir("MutationObserver").constructor
        }
    };
    var Mr = "Please stop import mirror directly. Instead of that,\r\nnow you can use replayer.getMirror() to access the mirror instance of a replayer,\r\nor you can use record.mirror to access the mirror instance during recording.",
        Ar = {
            map: {},
            getId: () => (console.error(Mr), -1),
            getNode: () => (console.error(Mr), null),
            removeNodeFromMap() {
                console.error(Mr)
            },
            has: () => (console.error(Mr), !1),
            reset() {
                console.error(Mr)
            }
        };
    "undefined" != typeof window && window.Proxy && window.Reflect && (Ar = new Proxy(Ar, {
        get: (e, t, r) => ("map" === t && console.error(Mr), Reflect.get(e, t, r))
    }));
    var kr = Date.now;

    function Tr(e) {
        return e ? e.nodeType === e.ELEMENT_NODE ? e : Nr.parentElement(e) : null
    }
    /[1-9][0-9]{12}/.test(Date.now().toString()) || (kr = () => (new Date).getTime());

    function Rr(e) {
        var t, r = null;
        return "getRootNode" in e && (null == (t = Nr.getRootNode(e)) ? void 0 : t.nodeType) === Node.DOCUMENT_FRAGMENT_NODE && Nr.host(Nr.getRootNode(e)) && (r = Nr.host(Nr.getRootNode(e))), r
    }

    function Er(e) {
        for (var t, r = e; t = Rr(r);) r = t;
        return r
    }

    function Or(e) {
        var t = e.ownerDocument;
        if (!t) return !1;
        var r = Er(e);
        return Nr.contains(t, r)
    }
    for (var xr = Object.freeze(Object.defineProperty({
            __proto__: null,
            StyleSheetMirror: class {
                constructor() {
                    $t(this, "id", 1), $t(this, "styleIDMap", new WeakMap), $t(this, "idStyleMap", new Map)
                }
                getId(e) {
                    var t;
                    return null !== (t = this.styleIDMap.get(e)) && void 0 !== t ? t : -1
                }
                has(e) {
                    return this.styleIDMap.has(e)
                }
                add(e, t) {
                    return this.has(e) ? this.getId(e) : (r = void 0 === t ? this.id++ : t, this.styleIDMap.set(e, r), this.idStyleMap.set(r, e), r);
                    var r
                }
                getStyle(e) {
                    return this.idStyleMap.get(e) || null
                }
                reset() {
                    this.styleIDMap = new WeakMap, this.idStyleMap = new Map, this.id = 1
                }
                generateId() {
                    return this.id++
                }
            },
            get _mirror() {
                return Ar
            },
            closestElementOfNode: Tr,
            getBaseDimension: function e(t, r) {
                var n, o, a = null == (o = null == (n = t.ownerDocument) ? void 0 : n.defaultView) ? void 0 : o.frameElement;
                if (!a || a === r) return {
                    x: 0,
                    y: 0,
                    relativeScale: 1,
                    absoluteScale: 1
                };
                var i = a.getBoundingClientRect(),
                    s = e(a, r),
                    l = i.height / a.clientHeight;
                return {
                    x: i.x * s.relativeScale + s.x,
                    y: i.y * s.relativeScale + s.y,
                    relativeScale: l,
                    absoluteScale: s.absoluteScale * l
                }
            },
            getNestedRule: function e(t, r) {
                var n = t[r[0]];
                return 1 === r.length ? n : e(n.cssRules[r[1]].cssRules, r.slice(2))
            },
            getPositionsAndIndex: function(e) {
                var t = [...e],
                    r = t.pop();
                return {
                    positions: t,
                    index: r
                }
            },
            getRootShadowHost: Er,
            getShadowHost: Rr,
            getWindowHeight: function() {
                return window.innerHeight || document.documentElement && document.documentElement.clientHeight || document.body && document.body.clientHeight
            },
            getWindowScroll: function(e) {
                var t, r, n, o, a = e.document;
                return {
                    left: a.scrollingElement ? a.scrollingElement.scrollLeft : void 0 !== e.pageXOffset ? e.pageXOffset : a.documentElement.scrollLeft || (null == a ? void 0 : a.body) && (null == (t = Nr.parentElement(a.body)) ? void 0 : t.scrollLeft) || (null == (r = null == a ? void 0 : a.body) ? void 0 : r.scrollLeft) || 0,
                    top: a.scrollingElement ? a.scrollingElement.scrollTop : void 0 !== e.pageYOffset ? e.pageYOffset : (null == a ? void 0 : a.documentElement.scrollTop) || (null == a ? void 0 : a.body) && (null == (n = Nr.parentElement(a.body)) ? void 0 : n.scrollTop) || (null == (o = null == a ? void 0 : a.body) ? void 0 : o.scrollTop) || 0
                }
            },
            getWindowWidth: function() {
                return window.innerWidth || document.documentElement && document.documentElement.clientWidth || document.body && document.body.clientWidth
            },
            hasShadowRoot: function(e) {
                return !!e && (e instanceof mr && "shadowRoot" in e ? Boolean(e.shadowRoot) : Boolean(Nr.shadowRoot(e)))
            },
            hookSetter: function e(t, r, n, o) {
                var a = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : window,
                    i = a.Object.getOwnPropertyDescriptor(t, r);
                return a.Object.defineProperty(t, r, o ? n : {
                    set(e) {
                        setTimeout((() => {
                            n.set.call(this, e)
                        }), 0), i && i.set && i.set.call(this, e)
                    }
                }), () => e(t, r, i || {}, !0)
            },
            inDom: function(e) {
                var t = e.ownerDocument;
                return !!t && (Nr.contains(t, e) || Or(e))
            },
            isAncestorRemoved: function e(t, r) {
                if (o = (n = t) && "host" in n && "mode" in n && ur.host(n) || null, Boolean(o && "shadowRoot" in o && ur.shadowRoot(o) === n)) return !1;
                var n, o, a = r.getId(t);
                if (!r.has(a)) return !0;
                var i = Nr.parentNode(t);
                return (!i || i.nodeType !== t.DOCUMENT_NODE) && (!i || e(i, r))
            },
            isBlocked: function(e, t, r, n) {
                if (!e) return !1;
                var o = Tr(e);
                if (!o) return !1;
                try {
                    if ("string" == typeof t) {
                        if (o.classList.contains(t)) return !0;
                        if (n && null !== o.closest("." + t)) return !0
                    } else if (pr(o, t, n)) return !0
                } catch (e) {}
                if (r) {
                    if (o.matches(r)) return !0;
                    if (n && null !== o.closest(r)) return !0
                }
                return !1
            },
            isIgnored: function(e, t, r) {
                return !("TITLE" !== e.tagName || !r.headTitleMutations) || -2 === t.getId(e)
            },
            isSerialized: function(e, t) {
                return -1 !== t.getId(e)
            },
            isSerializedIframe: function(e, t) {
                return Boolean("IFRAME" === e.nodeName && t.getMeta(e))
            },
            isSerializedStylesheet: function(e, t) {
                return Boolean("LINK" === e.nodeName && e.nodeType === e.ELEMENT_NODE && e.getAttribute && "stylesheet" === e.getAttribute("rel") && t.getMeta(e))
            },
            iterateResolveTree: function e(t, r) {
                r(t.value);
                for (var n = t.children.length - 1; n >= 0; n--) e(t.children[n], r)
            },
            legacy_isTouchEvent: function(e) {
                return Boolean(e.changedTouches)
            },
            get nowTimestamp() {
                return kr
            },
            on: function(e, t) {
                var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : document,
                    n = {
                        capture: !0,
                        passive: !0
                    };
                return r.addEventListener(e, t, n), () => r.removeEventListener(e, t, n)
            },
            patch: function(e, t, r) {
                try {
                    if (!(t in e)) return () => {};
                    var n = e[t],
                        o = r(n);
                    return "function" == typeof o && (o.prototype = o.prototype || {}, Object.defineProperties(o, {
                        __rrweb_original__: {
                            enumerable: !1,
                            value: n
                        }
                    })), e[t] = o, () => {
                        e[t] = n
                    }
                } catch (e) {
                    return () => {}
                }
            },
            polyfill: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : window;
                "NodeList" in e && !e.NodeList.prototype.forEach && (e.NodeList.prototype.forEach = Array.prototype.forEach), "DOMTokenList" in e && !e.DOMTokenList.prototype.forEach && (e.DOMTokenList.prototype.forEach = Array.prototype.forEach)
            },
            queueToResolveTrees: function(e) {
                var t = {},
                    r = (e, r) => {
                        var n = {
                            value: e,
                            parent: r,
                            children: []
                        };
                        return t[e.node.id] = n, n
                    },
                    n = [];
                for (var o of e) {
                    var {
                        nextId: a,
                        parentId: i
                    } = o;
                    if (a && a in t) {
                        var s = t[a];
                        if (s.parent) {
                            var l = s.parent.children.indexOf(s);
                            s.parent.children.splice(l, 0, r(o, s.parent))
                        } else {
                            var c = n.indexOf(s);
                            n.splice(c, 0, r(o, null))
                        }
                    } else if (i in t) {
                        var d = t[i];
                        d.children.push(r(o, d))
                    } else n.push(r(o, null))
                }
                return n
            },
            shadowHostInDom: Or,
            throttle: function(e, t) {
                var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                    n = null,
                    o = 0;
                return function() {
                    for (var a = arguments.length, i = new Array(a), s = 0; s < a; s++) i[s] = arguments[s];
                    var l = Date.now();
                    o || !1 !== r.leading || (o = l);
                    var c = t - (l - o),
                        d = this;
                    c <= 0 || c > t ? (n && (clearTimeout(n), n = null), o = l, e.apply(d, i)) : n || !1 === r.trailing || (n = setTimeout((() => {
                        o = !1 === r.leading ? 0 : Date.now(), n = null, e.apply(d, i)
                    }), c))
                }
            },
            uniqueTextMutations: function(e) {
                for (var t = new Set, r = [], n = e.length; n--;) {
                    var o = e[n];
                    t.has(o.id) || (r.push(o), t.add(o.id))
                }
                return r
            }
        }, Symbol.toStringTag, {
            value: "Module"
        })), Dr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", Lr = "undefined" == typeof Uint8Array ? [] : new Uint8Array(256), Fr = 0; Fr < 64; Fr++) Lr[Dr.charCodeAt(Fr)] = Fr;
    var Br;
    "undefined" != typeof window && window.Blob && new Blob([(e => Uint8Array.from(atob(e), (e => e.charCodeAt(0))))("KGZ1bmN0aW9uKCkgewogICJ1c2Ugc3RyaWN0IjsKICB2YXIgY2hhcnMgPSAiQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODkrLyI7CiAgdmFyIGxvb2t1cCA9IHR5cGVvZiBVaW50OEFycmF5ID09PSAidW5kZWZpbmVkIiA/IFtdIDogbmV3IFVpbnQ4QXJyYXkoMjU2KTsKICBmb3IgKHZhciBpID0gMDsgaSA8IGNoYXJzLmxlbmd0aDsgaSsrKSB7CiAgICBsb29rdXBbY2hhcnMuY2hhckNvZGVBdChpKV0gPSBpOwogIH0KICB2YXIgZW5jb2RlID0gZnVuY3Rpb24oYXJyYXlidWZmZXIpIHsKICAgIHZhciBieXRlcyA9IG5ldyBVaW50OEFycmF5KGFycmF5YnVmZmVyKSwgaTIsIGxlbiA9IGJ5dGVzLmxlbmd0aCwgYmFzZTY0ID0gIiI7CiAgICBmb3IgKGkyID0gMDsgaTIgPCBsZW47IGkyICs9IDMpIHsKICAgICAgYmFzZTY0ICs9IGNoYXJzW2J5dGVzW2kyXSA+PiAyXTsKICAgICAgYmFzZTY0ICs9IGNoYXJzWyhieXRlc1tpMl0gJiAzKSA8PCA0IHwgYnl0ZXNbaTIgKyAxXSA+PiA0XTsKICAgICAgYmFzZTY0ICs9IGNoYXJzWyhieXRlc1tpMiArIDFdICYgMTUpIDw8IDIgfCBieXRlc1tpMiArIDJdID4+IDZdOwogICAgICBiYXNlNjQgKz0gY2hhcnNbYnl0ZXNbaTIgKyAyXSAmIDYzXTsKICAgIH0KICAgIGlmIChsZW4gJSAzID09PSAyKSB7CiAgICAgIGJhc2U2NCA9IGJhc2U2NC5zdWJzdHJpbmcoMCwgYmFzZTY0Lmxlbmd0aCAtIDEpICsgIj0iOwogICAgfSBlbHNlIGlmIChsZW4gJSAzID09PSAxKSB7CiAgICAgIGJhc2U2NCA9IGJhc2U2NC5zdWJzdHJpbmcoMCwgYmFzZTY0Lmxlbmd0aCAtIDIpICsgIj09IjsKICAgIH0KICAgIHJldHVybiBiYXNlNjQ7CiAgfTsKICBjb25zdCBsYXN0QmxvYk1hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7CiAgY29uc3QgdHJhbnNwYXJlbnRCbG9iTWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTsKICBhc3luYyBmdW5jdGlvbiBnZXRUcmFuc3BhcmVudEJsb2JGb3Iod2lkdGgsIGhlaWdodCwgZGF0YVVSTE9wdGlvbnMpIHsKICAgIGNvbnN0IGlkID0gYCR7d2lkdGh9LSR7aGVpZ2h0fWA7CiAgICBpZiAoIk9mZnNjcmVlbkNhbnZhcyIgaW4gZ2xvYmFsVGhpcykgewogICAgICBpZiAodHJhbnNwYXJlbnRCbG9iTWFwLmhhcyhpZCkpIHJldHVybiB0cmFuc3BhcmVudEJsb2JNYXAuZ2V0KGlkKTsKICAgICAgY29uc3Qgb2Zmc2NyZWVuID0gbmV3IE9mZnNjcmVlbkNhbnZhcyh3aWR0aCwgaGVpZ2h0KTsKICAgICAgb2Zmc2NyZWVuLmdldENvbnRleHQoIjJkIik7CiAgICAgIGNvbnN0IGJsb2IgPSBhd2FpdCBvZmZzY3JlZW4uY29udmVydFRvQmxvYihkYXRhVVJMT3B0aW9ucyk7CiAgICAgIGNvbnN0IGFycmF5QnVmZmVyID0gYXdhaXQgYmxvYi5hcnJheUJ1ZmZlcigpOwogICAgICBjb25zdCBiYXNlNjQgPSBlbmNvZGUoYXJyYXlCdWZmZXIpOwogICAgICB0cmFuc3BhcmVudEJsb2JNYXAuc2V0KGlkLCBiYXNlNjQpOwogICAgICByZXR1cm4gYmFzZTY0OwogICAgfSBlbHNlIHsKICAgICAgcmV0dXJuICIiOwogICAgfQogIH0KICBjb25zdCB3b3JrZXIgPSBzZWxmOwogIHdvcmtlci5vbm1lc3NhZ2UgPSBhc3luYyBmdW5jdGlvbihlKSB7CiAgICBpZiAoIk9mZnNjcmVlbkNhbnZhcyIgaW4gZ2xvYmFsVGhpcykgewogICAgICBjb25zdCB7IGlkLCBiaXRtYXAsIHdpZHRoLCBoZWlnaHQsIGRhdGFVUkxPcHRpb25zIH0gPSBlLmRhdGE7CiAgICAgIGNvbnN0IHRyYW5zcGFyZW50QmFzZTY0ID0gZ2V0VHJhbnNwYXJlbnRCbG9iRm9yKAogICAgICAgIHdpZHRoLAogICAgICAgIGhlaWdodCwKICAgICAgICBkYXRhVVJMT3B0aW9ucwogICAgICApOwogICAgICBjb25zdCBvZmZzY3JlZW4gPSBuZXcgT2Zmc2NyZWVuQ2FudmFzKHdpZHRoLCBoZWlnaHQpOwogICAgICBjb25zdCBjdHggPSBvZmZzY3JlZW4uZ2V0Q29udGV4dCgiMmQiKTsKICAgICAgY3R4LmRyYXdJbWFnZShiaXRtYXAsIDAsIDApOwogICAgICBiaXRtYXAuY2xvc2UoKTsKICAgICAgY29uc3QgYmxvYiA9IGF3YWl0IG9mZnNjcmVlbi5jb252ZXJ0VG9CbG9iKGRhdGFVUkxPcHRpb25zKTsKICAgICAgY29uc3QgdHlwZSA9IGJsb2IudHlwZTsKICAgICAgY29uc3QgYXJyYXlCdWZmZXIgPSBhd2FpdCBibG9iLmFycmF5QnVmZmVyKCk7CiAgICAgIGNvbnN0IGJhc2U2NCA9IGVuY29kZShhcnJheUJ1ZmZlcik7CiAgICAgIGlmICghbGFzdEJsb2JNYXAuaGFzKGlkKSAmJiBhd2FpdCB0cmFuc3BhcmVudEJhc2U2NCA9PT0gYmFzZTY0KSB7CiAgICAgICAgbGFzdEJsb2JNYXAuc2V0KGlkLCBiYXNlNjQpOwogICAgICAgIHJldHVybiB3b3JrZXIucG9zdE1lc3NhZ2UoeyBpZCB9KTsKICAgICAgfQogICAgICBpZiAobGFzdEJsb2JNYXAuZ2V0KGlkKSA9PT0gYmFzZTY0KSByZXR1cm4gd29ya2VyLnBvc3RNZXNzYWdlKHsgaWQgfSk7CiAgICAgIHdvcmtlci5wb3N0TWVzc2FnZSh7CiAgICAgICAgaWQsCiAgICAgICAgdHlwZSwKICAgICAgICBiYXNlNjQsCiAgICAgICAgd2lkdGgsCiAgICAgICAgaGVpZ2h0CiAgICAgIH0pOwogICAgICBsYXN0QmxvYk1hcC5zZXQoaWQsIGJhc2U2NCk7CiAgICB9IGVsc2UgewogICAgICByZXR1cm4gd29ya2VyLnBvc3RNZXNzYWdlKHsgaWQ6IGUuZGF0YS5pZCB9KTsKICAgIH0KICB9Owp9KSgpOwovLyMgc291cmNlTWFwcGluZ1VSTD1pbWFnZS1iaXRtYXAtZGF0YS11cmwtd29ya2VyLUlKcEM3Z19iLmpzLm1hcAo=")], {
        type: "text/javascript;charset=utf-8"
    });
    try {
        if (2 !== Array.from([1], (e => 2 * e))[0]) {
            var Zr = document.createElement("iframe");
            document.body.appendChild(Zr), Array.from = (null == (Jt = Zr.contentWindow) ? void 0 : Jt.Array.from) || Array.from, document.body.removeChild(Zr)
        }
    } catch (e) {
        console.debug("Unable to override Array.from", e)
    }
    new hr,
    function(e) {
        e[e.NotStarted = 0] = "NotStarted", e[e.Running = 1] = "Running", e[e.Stopped = 2] = "Stopped"
    }(Br || (Br = {}));
    class _r {
        constructor(e) {
            qt(this, "fileName"), qt(this, "functionName"), qt(this, "lineNumber"), qt(this, "columnNumber"), this.fileName = e.fileName || "", this.functionName = e.functionName || "", this.lineNumber = e.lineNumber, this.columnNumber = e.columnNumber
        }
        toString() {
            var e = this.lineNumber || "",
                t = this.columnNumber || "";
            return this.functionName ? "".concat(this.functionName, " (").concat(this.fileName, ":").concat(e, ":").concat(t, ")") : "".concat(this.fileName, ":").concat(e, ":").concat(t)
        }
    }
    var Yr = /(^|@)\S+:\d+/,
        Wr = /^\s*at .*(\S+:\d+|\(native\))/m,
        Gr = /^(eval@)?(\[native code])?$/,
        Vr = {
            parse: function(e) {
                return e ? void 0 !== e.stacktrace || void 0 !== e["opera#sourceloc"] ? this.parseOpera(e) : e.stack && e.stack.match(Wr) ? this.parseV8OrIE(e) : e.stack ? this.parseFFOrSafari(e) : (console.warn("[console-record-plugin]: Failed to parse error object:", e), []) : []
            },
            extractLocation: function(e) {
                if (-1 === e.indexOf(":")) return [e];
                var t = /(.+?)(?::(\d+))?(?::(\d+))?$/.exec(e.replace(/[()]/g, ""));
                if (!t) throw new Error("Cannot parse given url: ".concat(e));
                return [t[1], t[2] || void 0, t[3] || void 0]
            },
            parseV8OrIE: function(e) {
                return e.stack.split("\n").filter((function(e) {
                    return !!e.match(Wr)
                }), this).map((function(e) {
                    e.indexOf("(eval ") > -1 && (e = e.replace(/eval code/g, "eval").replace(/(\(eval at [^()]*)|(\),.*$)/g, ""));
                    var t = e.replace(/^\s+/, "").replace(/\(eval code/g, "("),
                        r = t.match(/ (\((.+):(\d+):(\d+)\)$)/),
                        n = (t = r ? t.replace(r[0], "") : t).split(/\s+/).slice(1),
                        o = this.extractLocation(r ? r[1] : n.pop()),
                        a = n.join(" ") || void 0,
                        i = ["eval", "<anonymous>"].indexOf(o[0]) > -1 ? void 0 : o[0];
                    return new _r({
                        functionName: a,
                        fileName: i,
                        lineNumber: o[1],
                        columnNumber: o[2]
                    })
                }), this)
            },
            parseFFOrSafari: function(e) {
                return e.stack.split("\n").filter((function(e) {
                    return !e.match(Gr)
                }), this).map((function(e) {
                    if (e.indexOf(" > eval") > -1 && (e = e.replace(/ line (\d+)(?: > eval line \d+)* > eval:\d+:\d+/g, ":$1")), -1 === e.indexOf("@") && -1 === e.indexOf(":")) return new _r({
                        functionName: e
                    });
                    var t = /((.*".+"[^@]*)?[^@]*)(?:@)/,
                        r = e.match(t),
                        n = r && r[1] ? r[1] : void 0,
                        o = this.extractLocation(e.replace(t, ""));
                    return new _r({
                        functionName: n,
                        fileName: o[0],
                        lineNumber: o[1],
                        columnNumber: o[2]
                    })
                }), this)
            },
            parseOpera: function(e) {
                return !e.stacktrace || e.message.indexOf("\n") > -1 && e.message.split("\n").length > e.stacktrace.split("\n").length ? this.parseOpera9(e) : e.stack ? this.parseOpera11(e) : this.parseOpera10(e)
            },
            parseOpera9: function(e) {
                for (var t = /Line (\d+).*script (?:in )?(\S+)/i, r = e.message.split("\n"), n = [], o = 2, a = r.length; o < a; o += 2) {
                    var i = t.exec(r[o]);
                    i && n.push(new _r({
                        fileName: i[2],
                        lineNumber: parseFloat(i[1])
                    }))
                }
                return n
            },
            parseOpera10: function(e) {
                for (var t = /Line (\d+).*script (?:in )?(\S+)(?:: In function (\S+))?$/i, r = e.stacktrace.split("\n"), n = [], o = 0, a = r.length; o < a; o += 2) {
                    var i = t.exec(r[o]);
                    i && n.push(new _r({
                        functionName: i[3] || void 0,
                        fileName: i[2],
                        lineNumber: parseFloat(i[1])
                    }))
                }
                return n
            },
            parseOpera11: function(e) {
                return e.stack.split("\n").filter((function(e) {
                    return !!e.match(Yr) && !e.match(/^Error created at/)
                }), this).map((function(e) {
                    var t = e.split("@"),
                        r = this.extractLocation(t.pop()),
                        n = (t.shift() || "").replace(/<anonymous function(: (\w+))?>/, "$2").replace(/\([^)]*\)/g, "") || void 0;
                    return new _r({
                        functionName: n,
                        fileName: r[0],
                        lineNumber: r[1],
                        columnNumber: r[2]
                    })
                }), this)
            }
        };

    function Hr(e) {
        if (!e || !e.outerHTML) return "";
        for (var t = ""; e.parentElement;) {
            var r = e.localName;
            if (!r) break;
            r = r.toLowerCase();
            var n = e.parentElement,
                o = [];
            if (n.children && n.children.length > 0)
                for (var a = 0; a < n.children.length; a++) {
                    var i = n.children[a];
                    i.localName && i.localName.toLowerCase && i.localName.toLowerCase() === r && o.push(i)
                }
            o.length > 1 && (r += ":eq(".concat(o.indexOf(e), ")")), t = r + (t ? ">" + t : ""), e = n
        }
        return t
    }

    function Pr(e) {
        return "[object Object]" === Object.prototype.toString.call(e)
    }

    function Xr(e, t) {
        if (0 === t) return !0;
        var r = Object.keys(e);
        for (var n of r)
            if (Pr(e[n]) && Xr(e[n], t - 1)) return !0;
        return !1
    }

    function jr(e, t) {
        var r = {
            numOfKeysLimit: 50,
            depthOfLimit: 4
        };
        Object.assign(r, t);
        var n = [],
            o = [];
        return JSON.stringify(e, (function(e, t) {
            if (n.length > 0) {
                var a = n.indexOf(this);
                ~a ? n.splice(a + 1) : n.push(this), ~a ? o.splice(a, 1 / 0, e) : o.push(e), ~n.indexOf(t) && (t = n[0] === t ? "[Circular ~]" : "[Circular ~." + o.slice(0, n.indexOf(t)).join(".") + "]")
            } else n.push(t);
            if (null === t) return t;
            if (void 0 === t) return "undefined";
            if (function(e) {
                    if (Pr(e) && Object.keys(e).length > r.numOfKeysLimit) return !0;
                    if ("function" == typeof e) return !0;
                    if (Pr(e) && Xr(e, r.depthOfLimit)) return !0;
                    return !1
                }(t)) return function(e) {
                var t = e.toString();
                r.stringLengthLimit && t.length > r.stringLengthLimit && (t = "".concat(t.slice(0, r.stringLengthLimit), "..."));
                return t
            }(t);
            if ("bigint" == typeof t) return t.toString() + "n";
            if (t instanceof Event) {
                var i = {};
                for (var s in t) {
                    var l = t[s];
                    Array.isArray(l) ? i[s] = Hr(l.length ? l[0] : null) : i[s] = l
                }
                return i
            }
            return t instanceof Node ? t instanceof HTMLElement ? t ? t.outerHTML : "" : t.nodeName : t instanceof Error ? t.stack ? t.stack + "\nEnd of stack for Error object" : t.name + ": " + t.message : t
        }))
    }
    var zr = {
        level: ["assert", "clear", "count", "countReset", "debug", "dir", "dirxml", "error", "group", "groupCollapsed", "groupEnd", "info", "log", "table", "time", "timeEnd", "timeLog", "trace", "warn"],
        lengthThreshold: 1e3,
        logger: "console"
    };

    function Kr(e, t, r) {
        var n, o = r ? Object.assign({}, zr, r) : zr,
            a = o.logger;
        if (!a) return () => {};
        n = "string" == typeof a ? t[a] : a;
        var i = 0,
            s = !1,
            l = [];
        if (o.level.includes("error")) {
            var c = t => {
                var r = t.message,
                    n = t.error,
                    a = Vr.parse(n).map((e => e.toString())),
                    i = [jr(r, o.stringifyOptions)];
                e({
                    level: "error",
                    trace: a,
                    payload: i
                })
            };
            t.addEventListener("error", c), l.push((() => {
                t.removeEventListener("error", c)
            }));
            var d = t => {
                var r, n;
                t.reason instanceof Error ? (r = t.reason, n = [jr("Uncaught (in promise) ".concat(r.name, ": ").concat(r.message), o.stringifyOptions)]) : (r = new Error, n = [jr("Uncaught (in promise)", o.stringifyOptions), jr(t.reason, o.stringifyOptions)]);
                var a = Vr.parse(r).map((e => e.toString()));
                e({
                    level: "error",
                    trace: a,
                    payload: n
                })
            };
            t.addEventListener("unhandledrejection", d), l.push((() => {
                t.removeEventListener("unhandledrejection", d)
            }))
        }
        for (var u of o.level) l.push(h(n, u));
        return () => {
            l.forEach((e => e()))
        };

        function h(t, r) {
            var n = this;
            return t[r] ? xr.patch(t, r, (t => function() {
                for (var a = arguments.length, l = new Array(a), c = 0; c < a; c++) l[c] = arguments[c];
                if (t.apply(n, l), !("assert" === r && l[0] || s)) {
                    s = !0;
                    try {
                        var d = Vr.parse(new Error).map((e => e.toString())).splice(1),
                            u = ("assert" === r ? l.slice(1) : l).map((e => jr(e, o.stringifyOptions)));
                        ++i < o.lengthThreshold ? e({
                            level: r,
                            trace: d,
                            payload: u
                        }) : i === o.lengthThreshold && e({
                            level: "warn",
                            trace: [],
                            payload: [jr("The number of log records reached the threshold.")]
                        })
                    } catch (e) {
                        t("rrweb logger error:", e, ...l)
                    } finally {
                        s = !1
                    }
                }
            })) : () => {}
        }
    }
    var Jr = e => ({
            name: "rrweb/console@1",
            observer: Kr,
            options: e
        }),
        Ur = "undefined" != typeof window ? window : void 0,
        qr = "undefined" != typeof globalThis ? globalThis : Ur,
        Qr = Array.prototype.forEach,
        $r = null == qr ? void 0 : qr.navigator;
    null == qr || qr.document, null == qr || qr.location, null == qr || qr.fetch, null != qr && qr.XMLHttpRequest && "withCredentials" in new qr.XMLHttpRequest && qr.XMLHttpRequest, null == qr || qr.AbortController, null == $r || $r.userAgent;
    var en, tn = null != Ur ? Ur : {};
    ! function(e) {
        e.GZipJS = "gzip-js", e.Base64 = "base64"
    }(en || (en = {}));
    var rn = Array.isArray,
        nn = Object.prototype,
        on = nn.hasOwnProperty,
        an = nn.toString,
        sn = rn || function(e) {
            return "[object Array]" === an.call(e)
        },
        ln = e => "function" == typeof e,
        cn = e => e === Object(e) && !sn(e),
        dn = e => void 0 === e,
        un = e => "[object String]" == an.call(e),
        hn = e => null === e,
        pn = e => dn(e) || hn(e),
        mn = e => "[object Boolean]" === an.call(e),
        fn = e => e instanceof Document,
        gn = e => e instanceof FormData,
        vn = e => {
            var t = {
                _log: function(t) {
                    if (Ur && tn.POSTHOG_DEBUG && !dn(Ur.console) && Ur.console) {
                        for (var r = ("__rrweb_original__" in Ur.console[t] ? Ur.console[t].__rrweb_original__ : Ur.console[t]), n = arguments.length, o = new Array(n > 1 ? n - 1 : 0), a = 1; a < n; a++) o[a - 1] = arguments[a];
                        r(e, ...o)
                    }
                },
                info: function() {
                    for (var e = arguments.length, r = new Array(e), n = 0; n < e; n++) r[n] = arguments[n];
                    t._log("log", ...r)
                },
                warn: function() {
                    for (var e = arguments.length, r = new Array(e), n = 0; n < e; n++) r[n] = arguments[n];
                    t._log("warn", ...r)
                },
                error: function() {
                    for (var e = arguments.length, r = new Array(e), n = 0; n < e; n++) r[n] = arguments[n];
                    t._log("error", ...r)
                },
                critical: function() {
                    for (var t = arguments.length, r = new Array(t), n = 0; n < t; n++) r[n] = arguments[n];
                    console.error(e, ...r)
                },
                uninitializedWarning: e => {
                    t.error("You must initialize PostHog before calling ".concat(e))
                },
                createLogger: t => vn("".concat(e, " ").concat(t))
            };
            return t
        },
        yn = vn("[PostHog.js]").createLogger,
        In = {};

    function bn(e, t, r) {
        if (!pn(e)) {
            if (sn(e)) return function(e, t, r) {
                if (sn(e))
                    if (Qr && e.forEach === Qr) e.forEach(t, r);
                    else if ("length" in e && e.length === +e.length)
                    for (var n = 0, o = e.length; n < o; n++)
                        if (n in e && t.call(r, e[n], n) === In) return
            }(e, t, r);
            if (gn(e)) {
                for (var n of e.entries())
                    if (t.call(r, n[1], n[0]) === In) return
            } else
                for (var o in e)
                    if (on.call(e, o) && t.call(r, e[o], o) === In) return
        }
    }
    var Cn = function(e) {
            var t, r, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "&",
                o = [];
            return bn(e, (function(e, n) {
                dn(e) || dn(n) || "undefined" === n || (t = encodeURIComponent(e instanceof File ? e.name : e.toString()), r = encodeURIComponent(n), o[o.length] = r + "=" + t)
            })), o.join(n)
        },
        Sn = {
            initiatorTypes: ["audio", "beacon", "body", "css", "early-hint", "embed", "fetch", "frame", "iframe", "icon", "image", "img", "input", "link", "navigation", "object", "ping", "script", "track", "video", "xmlhttprequest"],
            maskRequestFn: e => e,
            recordHeaders: !1,
            recordBody: !1,
            recordInitialRequests: !1,
            recordPerformance: !1,
            performanceEntryTypeToObserve: ["first-input", "navigation", "paint", "resource"],
            payloadSizeLimitBytes: 1e6,
            payloadHostDenyList: [".lr-ingest.io", ".ingest.sentry.io", ".clarity.ms", "analytics.google.com"]
        };

    function wn(e, t, r) {
        try {
            if (!(t in e)) return () => {};
            var n = e[t],
                o = r(n);
            return ln(o) && (o.prototype = o.prototype || {}, Object.defineProperties(o, {
                __posthog_wrapped__: {
                    enumerable: !1,
                    value: !0
                }
            })), e[t] = o, () => {
                e[t] = n
            }
        } catch (e) {
            return () => {}
        }
    }

    function Nn(e, t) {
        var r, n = function(e) {
                try {
                    return "string" == typeof e ? new URL(e).hostname : "url" in e ? new URL(e.url).hostname : e.hostname
                } catch (e) {
                    return null
                }
            }(e),
            o = {
                hostname: n,
                isHostDenied: !1
            };
        if (null === (r = t.payloadHostDenyList) || void 0 === r || !r.length || null == n || !n.trim().length) return o;
        for (var a of t.payloadHostDenyList)
            if (n.endsWith(a)) return {
                hostname: n,
                isHostDenied: !0
            };
        return o
    }
    var Mn = yn("[Recorder]"),
        An = e => "navigation" === e.entryType,
        kn = e => "resource" === e.entryType;

    function Tn(e, t) {
        for (var r = e.length - 1; r >= 0; r -= 1)
            if (t(e[r])) return e[r]
    }

    function Rn(e, t, r) {
        if (r.recordInitialRequests) {
            var n = t.performance.getEntries().filter((e => An(e) || kn(e) && r.initiatorTypes.includes(e.initiatorType)));
            e({
                requests: n.flatMap((e => Bn({
                    entry: e,
                    method: void 0,
                    status: void 0,
                    networkRequest: {},
                    isInitial: !0
                }))),
                isInitial: !0
            })
        }
        var o = new t.PerformanceObserver((t => {
                var n = t.getEntries().filter((e => An(e) || kn(e) && r.initiatorTypes.includes(e.initiatorType) && (e => !r.recordBody && !r.recordHeaders || "xmlhttprequest" !== e.initiatorType && "fetch" !== e.initiatorType)(e)));
                e({
                    requests: n.flatMap((e => Bn({
                        entry: e,
                        method: void 0,
                        status: void 0,
                        networkRequest: {}
                    })))
                })
            })),
            a = PerformanceObserver.supportedEntryTypes.filter((e => r.performanceEntryTypeToObserve.includes(e)));
        return o.observe({
            entryTypes: a
        }), () => {
            o.disconnect()
        }
    }

    function En(e, t) {
        return !!t && (mn(t) || t[e])
    }

    function On(e) {
        var {
            type: t,
            recordBody: r,
            headers: n
        } = e;

        function o(e) {
            var t = Object.keys(n).find((e => "content-type" === e.toLowerCase())),
                r = t && n[t];
            return e.some((e => null == r ? void 0 : r.includes(e)))
        }
        if (!r) return !1;
        if (mn(r)) return !0;
        if (sn(r)) return o(r);
        var a = r[t];
        return mn(a) ? a : o(a)
    }

    function xn(e, t, r, n, o) {
        return Dn.apply(this, arguments)
    }

    function Dn() {
        return Dn = o((function*(e, t, r, n, o) {
            var a = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 0;
            if (a > 10) return Mn.warn("Failed to get performance entry for request", {
                url: r,
                initiatorType: t
            }), null;
            var i = Tn(e.performance.getEntriesByName(r), (e => kn(e) && e.initiatorType === t && (dn(n) || e.startTime >= n) && (dn(o) || e.startTime <= o)));
            return i || (yield new Promise((e => setTimeout(e, 50 * a))), xn(e, t, r, n, o, a + 1))
        })), Dn.apply(this, arguments)
    }

    function Ln(e) {
        var {
            body: t,
            options: r,
            url: n
        } = e;
        if (pn(t)) return null;
        var {
            hostname: o,
            isHostDenied: a
        } = Nn(n, r);
        if (a) return o + " is in deny list";
        if (un(t)) return t;
        if (fn(t)) return t.textContent;
        if (gn(t)) return Cn(t);
        if (cn(t)) try {
            return JSON.stringify(t)
        } catch (e) {
            return "[SessionReplay] Failed to stringify response object"
        }
        return "[SessionReplay] Cannot read body of type " + toString.call(t)
    }
    var Fn = e => !hn(e) && ("navigation" === e.entryType || "resource" === e.entryType);

    function Bn(e) {
        var {
            entry: t,
            method: n,
            status: o,
            networkRequest: a,
            isInitial: i,
            start: s,
            end: l,
            url: c,
            initiatorType: d
        } = e;
        s = t ? t.startTime : s, l = t ? t.responseEnd : l;
        var u = Math.floor(Date.now() - performance.now()),
            h = Math.floor(u + (s || 0)),
            p = [r(r({}, t ? t.toJSON() : {
                name: c
            }), {}, {
                startTime: dn(s) ? void 0 : Math.round(s),
                endTime: dn(l) ? void 0 : Math.round(l),
                timeOrigin: u,
                timestamp: h,
                method: n,
                initiatorType: d || (t ? t.initiatorType : void 0),
                status: o,
                requestHeaders: a.requestHeaders,
                requestBody: a.requestBody,
                responseHeaders: a.responseHeaders,
                responseBody: a.responseBody,
                isInitial: i
            })];
        if (Fn(t))
            for (var m of t.serverTiming || []) p.push({
                timeOrigin: u,
                timestamp: h,
                startTime: Math.round(t.startTime),
                name: m.name,
                duration: m.duration,
                entryType: "serverTiming"
            });
        return p
    }
    var Zn = ["video/", "audio/"];

    function _n(e) {
        return new Promise(((t, r) => {
            var n = setTimeout((() => t("[SessionReplay] Timeout while trying to read body")), 500);
            try {
                e.clone().text().then((e => t(e)), (e => r(e))).finally((() => clearTimeout(n)))
            } catch (e) {
                clearTimeout(n), t("[SessionReplay] Failed to read body")
            }
        }))
    }

    function Yn() {
        return (Yn = o((function*(e) {
            var {
                r: t,
                options: r,
                url: n
            } = e, {
                hostname: o,
                isHostDenied: a
            } = Nn(n, r);
            return a ? Promise.resolve(o + " is in deny list") : _n(t)
        }))).apply(this, arguments)
    }

    function Wn() {
        return (Wn = o((function*(e) {
            var {
                r: t,
                options: r,
                url: n
            } = e, o = function(e) {
                var t, {
                    r: r,
                    options: n,
                    url: o
                } = e;
                if ("chunked" === r.headers.get("Transfer-Encoding")) return "Chunked Transfer-Encoding is not supported";
                var a = null === (t = r.headers.get("Content-Type")) || void 0 === t ? void 0 : t.toLowerCase(),
                    i = Zn.some((e => null == a ? void 0 : a.startsWith(e)));
                if (a && i) return "Content-Type ".concat(a, " is not supported");
                var {
                    hostname: s,
                    isHostDenied: l
                } = Nn(o, n);
                return l ? s + " is in deny list" : null
            }({
                r: t,
                options: r,
                url: n
            });
            return hn(o) ? _n(t) : Promise.resolve(o)
        }))).apply(this, arguments)
    }

    function Gn(e, t, r) {
        if (!r.initiatorTypes.includes("fetch")) return () => {};
        var n = En("request", r.recordHeaders),
            a = En("response", r.recordHeaders),
            i = wn(t, "fetch", (i => function() {
                var s = o((function*(o, s) {
                    var l, c, d, u = new Request(o, s),
                        h = {};
                    try {
                        var p = {};
                        u.headers.forEach(((e, t) => {
                            p[t] = e
                        })), n && (h.requestHeaders = p), On({
                            type: "request",
                            headers: p,
                            url: o,
                            recordBody: r.recordBody
                        }) && (h.requestBody = yield function(e) {
                            return Yn.apply(this, arguments)
                        }({
                            r: u,
                            options: r,
                            url: o
                        })), c = t.performance.now(), l = yield i(u), d = t.performance.now();
                        var m = {};
                        return l.headers.forEach(((e, t) => {
                            m[t] = e
                        })), a && (h.responseHeaders = m), On({
                            type: "response",
                            headers: m,
                            url: o,
                            recordBody: r.recordBody
                        }) && (h.responseBody = yield function(e) {
                            return Wn.apply(this, arguments)
                        }({
                            r: l,
                            options: r,
                            url: o
                        })), l
                    } finally {
                        xn(t, "fetch", u.url, c, d).then((t => {
                            var r, n = Bn({
                                entry: t,
                                method: u.method,
                                status: null === (r = l) || void 0 === r ? void 0 : r.status,
                                networkRequest: h,
                                start: c,
                                end: d,
                                url: u.url,
                                initiatorType: "fetch"
                            });
                            e({
                                requests: n
                            })
                        })).catch((() => {}))
                    }
                }));
                return function(e, t) {
                    return s.apply(this, arguments)
                }
            }()));
        return () => {
            i()
        }
    }
    var Vn = null;

    function Hn(e, t, n) {
        if (!("performance" in t)) return () => {};
        if (Vn) return Mn.warn("Network observer already initialised, doing nothing"), () => {};
        var o = n ? Object.assign({}, Sn, n) : Sn,
            a = t => {
                var n = [];
                t.requests.forEach((e => {
                    var t = o.maskRequestFn(e);
                    t && n.push(t)
                })), n.length > 0 && e(r(r({}, t), {}, {
                    requests: n
                }))
            },
            i = Rn(a, t, o),
            s = () => {},
            l = () => {};
        return (o.recordHeaders || o.recordBody) && (s = function(e, t, r) {
            if (!r.initiatorTypes.includes("xmlhttprequest")) return () => {};
            var n = En("request", r.recordHeaders),
                o = En("response", r.recordHeaders),
                a = wn(t.XMLHttpRequest.prototype, "open", (a => function(i, s) {
                    var l, c, d = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
                        u = arguments.length > 3 ? arguments[3] : void 0,
                        h = arguments.length > 4 ? arguments[4] : void 0,
                        p = this,
                        m = new Request(s),
                        f = {},
                        g = {},
                        v = p.setRequestHeader.bind(p);
                    p.setRequestHeader = (e, t) => (g[e] = t, v(e, t)), n && (f.requestHeaders = g);
                    var y = p.send.bind(p);
                    p.send = e => (On({
                        type: "request",
                        headers: g,
                        url: s,
                        recordBody: r.recordBody
                    }) && (f.requestBody = Ln({
                        body: e,
                        options: r,
                        url: s
                    })), l = t.performance.now(), y(e)), p.addEventListener("readystatechange", (() => {
                        if (p.readyState === p.DONE) {
                            c = t.performance.now();
                            var n = {};
                            p.getAllResponseHeaders().trim().split(/[\r\n]+/).forEach((e => {
                                var t = e.split(": "),
                                    r = t.shift(),
                                    o = t.join(": ");
                                r && (n[r] = o)
                            })), o && (f.responseHeaders = n), On({
                                type: "response",
                                headers: n,
                                url: s,
                                recordBody: r.recordBody
                            }) && (f.responseBody = Ln({
                                body: p.response,
                                options: r,
                                url: s
                            })), xn(t, "xmlhttprequest", m.url, l, c).then((t => {
                                var r = Bn({
                                    entry: t,
                                    method: i,
                                    status: null == p ? void 0 : p.status,
                                    networkRequest: f,
                                    start: l,
                                    end: c,
                                    url: s.toString(),
                                    initiatorType: "xmlhttprequest"
                                });
                                e({
                                    requests: r
                                })
                            })).catch((() => {}))
                        }
                    })), a.call(p, i, s, d, u, h)
                }));
            return () => {
                a()
            }
        }(a, t, o), l = Gn(a, t, o)), Vn = () => {
            i(), s(), l()
        }
    }
    var Pn = "rrweb/network@1",
        Xn = e => ({
            name: Pn,
            observer: Hn,
            options: e
        });
    tn.__PosthogExtensions__ = tn.__PosthogExtensions__ || {}, tn.__PosthogExtensions__.rrwebPlugins = {
        getRecordConsolePlugin: Jr,
        getRecordNetworkPlugin: Xn
    }, tn.__PosthogExtensions__.rrweb = {
        record: Kt,
        version: "v2"
    }, tn.rrweb = {
        record: Kt,
        version: "v2"
    }, tn.rrwebConsoleRecord = {
        getRecordConsolePlugin: Jr
    }, tn.getRecordNetworkPlugin = Xn, e.NETWORK_PLUGIN_NAME = Pn, e.default = Kt, e.findLast = Tn, e.getRecordNetworkPlugin = Xn, Object.defineProperty(e, "__esModule", {
        value: !0
    })
}({});
//# sourceMappingURL=recorder.js.map