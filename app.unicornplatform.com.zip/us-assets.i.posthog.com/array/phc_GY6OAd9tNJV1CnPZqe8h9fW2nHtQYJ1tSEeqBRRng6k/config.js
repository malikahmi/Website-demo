(function() {
    window._POSTHOG_REMOTE_CONFIG = window._POSTHOG_REMOTE_CONFIG || {};
    window._POSTHOG_REMOTE_CONFIG['phc_GY6OAd9tNJV1CnPZqe8h9fW2nHtQYJ1tSEeqBRRng6k'] = {
        config: {
            "token": "phc_GY6OAd9tNJV1CnPZqe8h9fW2nHtQYJ1tSEeqBRRng6k",
            "supportedCompression": ["gzip", "gzip-js"],
            "hasFeatureFlags": true,
            "captureDeadClicks": false,
            "capturePerformance": {
                "network_timing": true,
                "web_vitals": false,
                "web_vitals_allowed_metrics": null
            },
            "autocapture_opt_out": false,
            "autocaptureExceptions": false,
            "analytics": {
                "endpoint": "/i/v0/e/"
            },
            "elementsChainAsString": true,
            "sessionRecording": false,
            "quotaLimited": ["recordings"],
            "heatmaps": false,
            "surveys": [],
            "defaultIdentifiedOnly": true
        },
        siteApps: []
    }
})();