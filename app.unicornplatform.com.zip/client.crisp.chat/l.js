/**
 * crisp-client
 * @version v2.17.0 293f389
 * @author Crisp IM SAS
 * @date 1/23/2025
 */
(function() {
    try {
        new(function() {
            function t() {
                var t, i = this;
                try {
                    this.ns = "CrispLoader", this.n = {
                        warn: function(t, i) {},
                        error: function(t, i) {},
                        info: function(t, i) {},
                        log: function(t, i) {},
                        debug: function(t, i) {}
                    }, this.s = !1, this.f = "crisp-client", this.y = "client.crisp.chat", this.w = "client.relay.crisp.chat", this.v = "stream.relay.crisp.chat", this.x = "293f389", this.on = "production", this.fn = "https:", this._n = "https://crisp.chat", this.fs = "https://go.crisp.chat", this.ms = "https://image.crisp.chat", this.ws = "https://game.crisp.chat", this.$s = "".concat(this.fn, "//").concat(this.w), this._e = "".concat(this.fn, "//").concat(this.v), this.io = "".concat(this.fn, "//").concat(this.y), this.do = [{
                        urls: ["stun:stun.media.crisp.chat:3478", "stun:stun.media.crisp.chat:3479"]
                    }, {
                        urls: ["turn:turn.media.crisp.chat:3478?transport=udp", "turn:turn.media.crisp.chat:3478?transport=tcp", "turn:turn.media.crisp.chat:3479?transport=udp", "turn:turn.media.crisp.chat:3479?transport=tcp", "turns:turn.media.crisp.chat:443?transport=tcp"],
                        username: "client_9F9kh",
                        credential: "DPCEHTqUb7jiJ2mvnzcUmFV4mKK6c8jntUXo4gC8tYCbHTocuy9YJiCxpQ4tmG3p"
                    }], this._a = !0, this.el = {
                        domains: ["pages.dev", "workers.dev"],
                        agents: ["Trident", "Googlebot", "Bingbot", "Slurp", "DuckDuckBot", "Baiduspider", "YandexBot", "GTmetrix", "Lighthouse", "Acunetix", "Ahrefs", "SemrushBot", "SiteAuditBot", "SplitSignalBot", "HeadlessChrome"],
                        engines: [{
                            element: "head link[rel='icon'][type='image/x-icon'][href^='https://sellpass.io']"
                        }, {
                            element: "head script[src*='/cdn.sellix.io/']"
                        }, {
                            element: "head link[rel='preconnect'][href^='https://cdn.sellix.io/']"
                        }, {
                            element: "head link[rel='preconnect'][href^='https://api.sellsn.io']"
                        }, {
                            element: "head link[rel='author'][href^='https://ereemby.com/']"
                        }, {
                            element: "body script[src$='/aiz-core.js']"
                        }]
                    }, this.tp = "static/javascripts", this.ip = "static/stylesheets", this.np = "$__CRISP_INSTANCE", this.sp = "$__CRISP_INCLUDED", this.ep = 100, this.rp = 3e4, this.op = 1e3, this.cp = 280, this.hp = 320, this.ap = 420, this.up = [{
                        pattern: /edg(?:e)?\/([0-9\.]+)/,
                        versions: {
                            support: 18,
                            legacy: 117
                        }
                    }, {
                        pattern: /chrom(?:e|ium)\/([0-9\.]+)/,
                        versions: {
                            support: 54,
                            legacy: 117
                        }
                    }, {
                        pattern: /firefox\/([0-9\.]+)/,
                        versions: {
                            support: 54,
                            legacy: 65
                        }
                    }, {
                        pattern: /opr\/([0-9\.]+)/,
                        versions: {
                            support: 41,
                            legacy: 103
                        }
                    }, {
                        pattern: /version\/([0-9\.]+)(?: mobile\/(?:[^\s]+))? safari\//,
                        versions: {
                            support: 12,
                            legacy: 14
                        }
                    }, {
                        pattern: /android ([0-9\.]+)/,
                        versions: {
                            support: 5,
                            legacy: 10
                        }
                    }], this.lp = /(?:http\:|https\:)?\/\/[^\/]+\/l\/([a-zA-Z0-9\-_]+)\.js/i, this.dp(), !0 === window[this.sp] || void 0 !== window[this.np] && "function" == typeof window[this.np].__init || !0 !== this.pp() || (window[this.sp] = !0, "interactive" === document.readyState || "complete" === document.readyState ? this.init() : (t = document.onreadystatechange || function() {}, window.addEventListener("DOMContentLoaded", function() {
                        i.init()
                    }), document.onreadystatechange = function() {
                        "function" == typeof t && t(), "interactive" !== document.readyState && "complete" !== document.readyState || setTimeout(function() {
                            i.init()
                        }, i.op)
                    }), this.fp())
                } catch (t) {}
            }
            var i = t.prototype;
            return i.init = function() {
                var i, n, s = this,
                    e = "init";
                try {
                    this._p || !0 === this.mp || this.yp(), this._p && !0 !== this.mp && (this.mp = !0, (i = document.createElement("div")).id = "crisp-loader", document.getElementsByTagName("body")[0].appendChild(i), n = function() {
                        return "none" === window.getComputedStyle(i).getPropertyValue("display")
                    }, function t() {
                        s.wp = setTimeout(function() {
                            s.wp = null, s.vp -= s.ep, void 0 !== window[s.np] && "function" == typeof window[s.np].__init && !0 === n() ? (s.n.info("".concat(s.ns, ".").concat(e), "Dependencies loaded"), i.parentNode.removeChild(i), window[s.np].__init({
                                dollar_crisp: window[s.np],
                                project_name: s.f,
                                url_go: s.fs,
                                url_image: s.ms,
                                url_game: s.ws,
                                url_relay_client: s.$s,
                                url_relay_stream: s._e,
                                url_website: s._n,
                                url_assets: s.io,
                                rtc_ice: s.do,
                                socket_affinity: s._a,
                                client_environment: s.on,
                                website_domain: s.Ip,
                                website_id: s._p,
                                token_id: s.gp,
                                cookie_expire: s.Ji,
                                cookie_domain: s.Cp,
                                page_url: s.Rp,
                                page_domain: s.Ep,
                                browser_useragent: s.Sp,
                                browser_timezone: s.bp,
                                browser_capabilities: s.Pp,
                                browser_locales: s.Dp,
                                ready_trigger: s.Op,
                                path_javascripts: s.tp,
                                path_stylesheets: s.ip,
                                include_mode: s.Tp,
                                runtime_configuration: s.Np,
                                reset_handler: function() {
                                    s.reset()
                                }
                            })) : 0 < s.vp ? t() : s.n.error("".concat(s.ns, ".").concat(e), "Could not load dependencies")
                        }, s.ep)
                    }())
                } catch (t) {}
            }, i.reset = function() {
                try {
                    null !== this.wp && clearTimeout(this.wp), this.dp(), this.init()
                } catch (t) {}
            }, i.fp = function() {
                try {
                    this.kp("dns-prefetch", this.$s), this.kp("preconnect", this.io), this.Kp(), this.jp()
                } catch (t) {}
            }, i.kp = function(t, i) {
                try {
                    var n = document.createElement("link");
                    n.setAttribute("href", i), n.setAttribute("rel", t), n.setAttribute("crossorigin", ""), this.Ap(n), document.getElementsByTagName("head")[0].appendChild(n)
                } catch (t) {}
            }, i.Kp = function() {
                try {
                    var t = document.createElement("script");
                    t.src = ["".concat(this.io, "/"), "".concat(this.tp, "/"), "client.js?".concat(this.x)].join(""), t.type = "text/javascript", t.async = !0, this.Ap(t), document.getElementsByTagName("head")[0].appendChild(t)
                } catch (t) {}
            }, i.jp = function() {
                try {
                    var t = this.Tp,
                        i = document.createElement("link");
                    i.href = ["".concat(this.io, "/"), "".concat(this.ip, "/"), "client_".concat(t, ".css?").concat(this.x)].join(""), i.type = "text/css", i.rel = "stylesheet", this.Ap(i), document.getElementsByTagName("head")[0].appendChild(i)
                } catch (t) {}
            }, i.dp = function() {
                this.xp(), this.yp(), this.Bp(), this.Gp()
            }, i.xp = function() {
                this.mp = !1, this.wp = null, this.vp = this.rp, this.Ip = document.domain, this.Rp = document.location.href, this.Ep = document.location.hostname, this.Sp = window.navigator.userAgent, this.bp = (new Date).getTimezoneOffset(), this.Dp = this.Up(), this.Tp = this.Lp()
            }, i.yp = function() {
                "string" == typeof CRISP_WEBSITE_ID && CRISP_WEBSITE_ID ? this._p = CRISP_WEBSITE_ID : this._p = this.Mp(), "string" == typeof CRISP_TOKEN_ID && CRISP_TOKEN_ID ? this.gp = CRISP_TOKEN_ID : "number" == typeof CRISP_TOKEN_ID && CRISP_TOKEN_ID ? this.gp = CRISP_TOKEN_ID.toString() : this.gp = null, "number" == typeof CRISP_COOKIE_EXPIRE && 0 < CRISP_COOKIE_EXPIRE ? this.Ji = CRISP_COOKIE_EXPIRE : this.Ji = null, "string" == typeof CRISP_COOKIE_DOMAIN && CRISP_COOKIE_DOMAIN ? this.Cp = CRISP_COOKIE_DOMAIN : this.Cp = null, "function" == typeof CRISP_READY_TRIGGER ? this.Op = CRISP_READY_TRIGGER : this.Op = {}, "object" == typeof CRISP_RUNTIME_CONFIG ? this.Np = CRISP_RUNTIME_CONFIG : this.Np = {}, "object" == typeof CRISP_INCLUDE_ATTRS ? this.Yp = CRISP_INCLUDE_ATTRS : this.Yp = {}
            }, i.Bp = function() {
                try {
                    this.Pp = [], "function" == typeof window.MutationObserver && "function" == typeof JSON.stringify && this.Pp.push("browsing"), ("function" == typeof window.RTCPeerConnection && "object" == typeof navigator.mediaDevices && "https:" === document.location.protocol && (window.innerWidth || 0) >= this.hp && (window.innerHeight || 0) >= this.ap || !0 === this.s) && this.Pp.push("call")
                } catch (t) {}
            }, i.Gp = function() {
                var t;
                try {
                    this.Np.locale && (-1 !== (t = this.Dp.indexOf(this.Np.locale)) && this.Dp.splice(t, 1), this.Dp.unshift(this.Np.locale))
                } catch (t) {}
            }, i.Ap = function(t) {
                try {
                    for (var i in this.Yp) this.Yp.hasOwnProperty(i) && t.setAttribute(i, this.Yp[i])
                } catch (t) {}
            }, i.Mp = function() {
                var t = null;
                try {
                    for (var i = document.querySelectorAll("script[src]"), n = 0; n < i.length; n++) {
                        var s = this.lp.exec(i[n].src);
                        if (s && "string" == typeof s[1]) {
                            t = s[1];
                            break
                        }
                    }
                } catch (t) {} finally {
                    return t
                }
            }, i.Lp = function() {
                var t = "default";
                try {
                    var i = (navigator.userAgent || "").toLowerCase(),
                        n = (navigator.appVersion || "").toLowerCase(),
                        s = !1,
                        e = !1; - 1 === i.indexOf("opera mini/") && -1 === i.indexOf("msie") && -1 === n.indexOf("trident/") || (s = e = !0);
                    for (var r = 0; r < this.up.length; r++) {
                        var o = this.up[r],
                            c = i.match(o.pattern),
                            h = null != c && c[1] ? parseInt(c[1], 10) : -1;
                        if (!isNaN(h) && 1 <= h) {
                            var a = o.versions.support,
                                u = o.versions.legacy;
                            h < a && (e = !0), h <= u && (s = !0);
                            break
                        }
                    }!0 === e ? t = null : !0 === s && (t = "legacy")
                } catch (t) {} finally {
                    return t
                }
            }, i.pp = function() {
                var t = !0;
                try {
                    (window.innerWidth && window.innerWidth < this.cp || !this.Tp || !0 !== this.zp() || !0 === this.Fp(this.Ep) || !0 === this.Xp(this.Sp) || !0 === this.Hp() || !window.WebSocket || window.__nativePerformance && window.__nativePromise) && (t = !1)
                } catch (t) {} finally {
                    return t
                }
            }, i.zp = function() {
                var t, i, n = !1;
                try {
                    !0 === navigator.cookieEnabled ? n = !0 : window.localStorage && "function" == typeof window.localStorage.setItem && "function" == typeof window.localStorage.getItem && "function" == typeof window.localStorage.removeItem && (t = "".concat((new Date).getTime()), i = "crisp-client/loader/storage/check", window.localStorage.setItem(i, t), n = window.localStorage.getItem(i) === t)
                } catch (t) {} finally {
                    return n
                }
            }, i.Fp = function() {
                var t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : "",
                    i = !1;
                try {
                    if (t)
                        for (var n = 0; n < this.el.domains.length; n++) {
                            var s = this.el.domains[n],
                                e = ".".concat(s);
                            if (t === s || t.slice(-1 * e.length) === e) {
                                i = !0;
                                break
                            }
                        }
                } catch (t) {} finally {
                    return i
                }
            }, i.Xp = function() {
                var t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : "",
                    i = !1;
                try {
                    if (t)
                        for (var n = 0; n < this.el.agents.length; n++)
                            if (-1 !== t.indexOf(this.el.agents[n])) {
                                i = !0;
                                break
                            }
                } catch (t) {} finally {
                    return i
                }
            }, i.Hp = function() {
                var t = !1;
                try {
                    for (var i = 0; i < this.el.engines.length; i++) {
                        var n = this.el.engines[i],
                            s = !1;
                        if (!0 === (s = n.element ? !!document.querySelector(n.element) : s)) {
                            t = !0;
                            break
                        }
                    }
                } catch (t) {} finally {
                    return t
                }
            }, i.Up = function() {
                var t = [];
                try {
                    for (var i, n = 0 < (null === (i = navigator.languages) || void 0 === i ? void 0 : i.length) ? navigator.languages : [navigator.language || navigator.userLanguage], s = 0; s < n.length; s++) n[s] && t.push(n[s])
                } catch (t) {} finally {
                    return t
                }
            }, t
        }())
    } catch (t) {}
})();